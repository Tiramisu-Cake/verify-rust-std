Func (loc "verified/lib.rs(139,1-228,2)", Regular, [("T", (true)); ("F", (true)); ("'__20", (false)); ("'__21", (false)); ("'__22", (false))], Some (ConstructedTypeExpr (loc "verified/lib.rs(143,2)", "fn_outcome", [ManifestTypeExpr (loc "verified/lib.rs(143,2)", StructType ("std_tuple_0_", []))])), "small_sort_general_with_scratch", [
  (ConstTypeExpr (loc "verified/lib.rs(140,5-6)", RustRefTypeExpr (loc "verified/lib.rs(140,5-6)", IdentTypeExpr (loc "verified/lib.rs(140,5-6)", None, "'__20"), Mutable, SliceTypeExpr (loc "verified/lib.rs(140,5-6)", IdentTypeExpr (loc "verified/lib.rs(140,5-6)", None, "T")))), "v");
  (ConstTypeExpr (loc "verified/lib.rs(141,5-12)", RustRefTypeExpr (loc "verified/lib.rs(141,5-12)", IdentTypeExpr (loc "verified/lib.rs(141,5-12)", None, "'__21"), Mutable, SliceTypeExpr (loc "verified/lib.rs(141,5-12)", StructTypeExpr (loc "verified/lib.rs(141,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(141,5-12)", None, "T")])))), "scratch");
  (ConstTypeExpr (loc "verified/lib.rs(142,5-12)", RustRefTypeExpr (loc "verified/lib.rs(142,5-12)", IdentTypeExpr (loc "verified/lib.rs(142,5-12)", None, "'__22"), Mutable, IdentTypeExpr (loc "verified/lib.rs(142,5-12)", None, "F"))), "is_less")
], false, (None, None), Some ((Sep (loc "verified/lib.rs(139,1-143,2)", Sep (loc "verified/lib.rs(139,1-143,2)", CallExpr (loc "verified/lib.rs(139,1-143,2)", "thread_token", [], [], [VarPat (loc "verified/lib.rs(139,1-143,2)", "_t")], Static), Operation (loc "verified/lib.rs(139,1-143,2)", Eq, [Var (loc "verified/lib.rs(139,1-143,2)", "_t"); Var (loc "verified/lib.rs(139,1-143,2)", "currentThread")])), Sep (loc "verified/lib.rs(140,5-6)", Sep (loc "verified/lib.rs(140,5-6)", CallExpr (loc "verified/lib.rs(140,5-6)", "array", [IdentTypeExpr (loc "verified/lib.rs(140,5-6)", None, "T")], [], [
  LitPat (CastExpr (loc "verified/lib.rs(140,5-6)", PtrTypeExpr (loc "verified/lib.rs(140,5-6)", IdentTypeExpr (loc "verified/lib.rs(140,5-6)", None, "T")), CallExpr (loc "verified/lib.rs(140,5-6)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(140,5-6)", ManifestTypeExpr (loc "verified/lib.rs(140,5-6)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(140,5-6)", "v")))], Static)));
  LitPat (CallExpr (loc "verified/lib.rs(140,5-6)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(140,5-6)", "v"))], Static));
  VarPat (loc "verified/lib.rs(140,5-6)", "_v0_v")
], Static), CallExpr (loc "verified/lib.rs(140,5-6)", "foreach", [], [], [
  LitPat (Var (loc "verified/lib.rs(140,5-6)", "_v0_v"));
  LitPat (CallExpr (loc "verified/lib.rs(140,5-6)", "own", [IdentTypeExpr (loc "verified/lib.rs(140,5-6)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(140,5-6)", "_t"))], Static))
], Static)), Sep (loc "verified/lib.rs(141,5-12)", Sep (loc "verified/lib.rs(141,5-12)", CallExpr (loc "verified/lib.rs(141,5-12)", "array", [
  StructTypeExpr (loc "verified/lib.rs(141,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(141,5-12)", None, "T")])
], [], [
  LitPat (CastExpr (loc "verified/lib.rs(141,5-12)", PtrTypeExpr (loc "verified/lib.rs(141,5-12)", StructTypeExpr (loc "verified/lib.rs(141,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(141,5-12)", None, "T")])), CallExpr (loc "verified/lib.rs(141,5-12)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(141,5-12)", ManifestTypeExpr (loc "verified/lib.rs(141,5-12)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(141,5-12)", "scratch")))], Static)));
  LitPat (CallExpr (loc "verified/lib.rs(141,5-12)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(141,5-12)", "scratch"))], Static));
  VarPat (loc "verified/lib.rs(141,5-12)", "_v0_scratch")
], Static), CallExpr (loc "verified/lib.rs(141,5-12)", "foreach", [], [], [
  LitPat (Var (loc "verified/lib.rs(141,5-12)", "_v0_scratch"));
  LitPat (CallExpr (loc "verified/lib.rs(141,5-12)", "own", [
    StructTypeExpr (loc "verified/lib.rs(141,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(141,5-12)", None, "T")])
  ], [], [LitPat (Var (loc "verified/lib.rs(141,5-12)", "_t"))], Static))
], Static)), Sep (loc "verified/lib.rs(142,5-12)", Sep (loc "verified/lib.rs(142,5-12)", PointsTo (loc "verified/lib.rs(142,5-12)", Deref (loc "verified/lib.rs(142,5-12)", Var (loc "verified/lib.rs(142,5-12)", "is_less")), "RegularPointsTo", VarPat (loc "verified/lib.rs(142,5-12)", "_v0_is_less")), ExprCallExpr (loc "verified/lib.rs(142,5-12)", TypePredExpr (loc "verified/lib.rs(142,5-12)", IdentTypeExpr (loc "verified/lib.rs(142,5-12)", None, "F"), "own"), [LitPat (Var (loc "verified/lib.rs(142,5-12)", "_t")); LitPat (Var (loc "verified/lib.rs(142,5-12)", "_v0_is_less"))])), Sep (loc "verified/lib.rs(139,1-143,2)", CoefAsn (loc "verified/lib.rs(139,1-143,2)", VarPat (loc "verified/lib.rs(139,1-143,2)", "_q___20"), CallExpr (loc "verified/lib.rs(139,1-143,2)", "lifetime_token", [], [], [
  LitPat (CallExpr (loc "verified/lib.rs(139,1-143,2)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(139,1-143,2)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(139,1-143,2)", None, "'__20"))))], Static))
], Static)), Sep (loc "verified/lib.rs(139,1-143,2)", CoefAsn (loc "verified/lib.rs(139,1-143,2)", VarPat (loc "verified/lib.rs(139,1-143,2)", "_q___21"), CallExpr (loc "verified/lib.rs(139,1-143,2)", "lifetime_token", [], [], [
  LitPat (CallExpr (loc "verified/lib.rs(139,1-143,2)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(139,1-143,2)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(139,1-143,2)", None, "'__21"))))], Static))
], Static)), CoefAsn (loc "verified/lib.rs(139,1-143,2)", VarPat (loc "verified/lib.rs(139,1-143,2)", "_q___22"), CallExpr (loc "verified/lib.rs(139,1-143,2)", "lifetime_token", [], [], [
  LitPat (CallExpr (loc "verified/lib.rs(139,1-143,2)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(139,1-143,2)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(139,1-143,2)", None, "'__22"))))], Static))
], Static)))))))), ("outcome", SwitchExpr (loc "verified/lib.rs(139,1-143,2)", Var (loc "verified/lib.rs(139,1-143,2)", "outcome"), [
  SwitchExprClause (loc "verified/lib.rs(139,1-143,2)", "returning", ["result"], Sep (loc "verified/lib.rs(139,1-143,2)", CallExpr (loc "verified/lib.rs(139,1-143,2)", "thread_token", [], [], [LitPat (Var (loc "verified/lib.rs(139,1-143,2)", "_t"))], Static), Sep (loc "verified/lib.rs(139,1-143,2)", CoefAsn (loc "verified/lib.rs(139,1-143,2)", LitPat (Var (loc "verified/lib.rs(139,1-143,2)", "_q___20")), CallExpr (loc "verified/lib.rs(139,1-143,2)", "lifetime_token", [], [], [
    LitPat (CallExpr (loc "verified/lib.rs(139,1-143,2)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(139,1-143,2)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(139,1-143,2)", None, "'__20"))))], Static))
  ], Static)), Sep (loc "verified/lib.rs(139,1-143,2)", CoefAsn (loc "verified/lib.rs(139,1-143,2)", LitPat (Var (loc "verified/lib.rs(139,1-143,2)", "_q___21")), CallExpr (loc "verified/lib.rs(139,1-143,2)", "lifetime_token", [], [], [
    LitPat (CallExpr (loc "verified/lib.rs(139,1-143,2)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(139,1-143,2)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(139,1-143,2)", None, "'__21"))))], Static))
  ], Static)), Sep (loc "verified/lib.rs(139,1-143,2)", CoefAsn (loc "verified/lib.rs(139,1-143,2)", LitPat (Var (loc "verified/lib.rs(139,1-143,2)", "_q___22")), CallExpr (loc "verified/lib.rs(139,1-143,2)", "lifetime_token", [], [], [
    LitPat (CallExpr (loc "verified/lib.rs(139,1-143,2)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(139,1-143,2)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(139,1-143,2)", None, "'__22"))))], Static))
  ], Static)), Sep (loc "verified/lib.rs(140,5-6)", Sep (loc "verified/lib.rs(140,5-6)", CallExpr (loc "verified/lib.rs(140,5-6)", "array", [IdentTypeExpr (loc "verified/lib.rs(140,5-6)", None, "T")], [], [
    LitPat (CastExpr (loc "verified/lib.rs(140,5-6)", PtrTypeExpr (loc "verified/lib.rs(140,5-6)", IdentTypeExpr (loc "verified/lib.rs(140,5-6)", None, "T")), CallExpr (loc "verified/lib.rs(140,5-6)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(140,5-6)", ManifestTypeExpr (loc "verified/lib.rs(140,5-6)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(140,5-6)", "v")))], Static)));
    LitPat (CallExpr (loc "verified/lib.rs(140,5-6)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(140,5-6)", "v"))], Static));
    VarPat (loc "verified/lib.rs(140,5-6)", "_v1_v")
  ], Static), CallExpr (loc "verified/lib.rs(140,5-6)", "foreach", [], [], [
    LitPat (Var (loc "verified/lib.rs(140,5-6)", "_v1_v"));
    LitPat (CallExpr (loc "verified/lib.rs(140,5-6)", "own", [IdentTypeExpr (loc "verified/lib.rs(140,5-6)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(140,5-6)", "_t"))], Static))
  ], Static)), Sep (loc "verified/lib.rs(141,5-12)", Sep (loc "verified/lib.rs(141,5-12)", CallExpr (loc "verified/lib.rs(141,5-12)", "array", [
    StructTypeExpr (loc "verified/lib.rs(141,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(141,5-12)", None, "T")])
  ], [], [
    LitPat (CastExpr (loc "verified/lib.rs(141,5-12)", PtrTypeExpr (loc "verified/lib.rs(141,5-12)", StructTypeExpr (loc "verified/lib.rs(141,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(141,5-12)", None, "T")])), CallExpr (loc "verified/lib.rs(141,5-12)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(141,5-12)", ManifestTypeExpr (loc "verified/lib.rs(141,5-12)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(141,5-12)", "scratch")))], Static)));
    LitPat (CallExpr (loc "verified/lib.rs(141,5-12)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(141,5-12)", "scratch"))], Static));
    VarPat (loc "verified/lib.rs(141,5-12)", "_v1_scratch")
  ], Static), CallExpr (loc "verified/lib.rs(141,5-12)", "foreach", [], [], [
    LitPat (Var (loc "verified/lib.rs(141,5-12)", "_v1_scratch"));
    LitPat (CallExpr (loc "verified/lib.rs(141,5-12)", "own", [
      StructTypeExpr (loc "verified/lib.rs(141,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(141,5-12)", None, "T")])
    ], [], [LitPat (Var (loc "verified/lib.rs(141,5-12)", "_t"))], Static))
  ], Static)), Sep (loc "verified/lib.rs(142,5-12)", Sep (loc "verified/lib.rs(142,5-12)", PointsTo (loc "verified/lib.rs(142,5-12)", Deref (loc "verified/lib.rs(142,5-12)", Var (loc "verified/lib.rs(142,5-12)", "is_less")), "RegularPointsTo", VarPat (loc "verified/lib.rs(142,5-12)", "_v1_is_less")), ExprCallExpr (loc "verified/lib.rs(142,5-12)", TypePredExpr (loc "verified/lib.rs(142,5-12)", IdentTypeExpr (loc "verified/lib.rs(142,5-12)", None, "F"), "own"), [LitPat (Var (loc "verified/lib.rs(142,5-12)", "_t")); LitPat (Var (loc "verified/lib.rs(142,5-12)", "_v1_is_less"))])), True (loc "verified/lib.rs(143,2)")))))))));
  SwitchExprClause (loc "verified/lib.rs(139,1-143,2)", "unwinding", [], Sep (loc "verified/lib.rs(139,1-143,2)", CallExpr (loc "verified/lib.rs(139,1-143,2)", "thread_token", [], [], [LitPat (Var (loc "verified/lib.rs(139,1-143,2)", "_t"))], Static), Sep (loc "verified/lib.rs(139,1-143,2)", CoefAsn (loc "verified/lib.rs(139,1-143,2)", LitPat (Var (loc "verified/lib.rs(139,1-143,2)", "_q___20")), CallExpr (loc "verified/lib.rs(139,1-143,2)", "lifetime_token", [], [], [
    LitPat (CallExpr (loc "verified/lib.rs(139,1-143,2)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(139,1-143,2)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(139,1-143,2)", None, "'__20"))))], Static))
  ], Static)), Sep (loc "verified/lib.rs(139,1-143,2)", CoefAsn (loc "verified/lib.rs(139,1-143,2)", LitPat (Var (loc "verified/lib.rs(139,1-143,2)", "_q___21")), CallExpr (loc "verified/lib.rs(139,1-143,2)", "lifetime_token", [], [], [
    LitPat (CallExpr (loc "verified/lib.rs(139,1-143,2)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(139,1-143,2)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(139,1-143,2)", None, "'__21"))))], Static))
  ], Static)), Sep (loc "verified/lib.rs(139,1-143,2)", CoefAsn (loc "verified/lib.rs(139,1-143,2)", LitPat (Var (loc "verified/lib.rs(139,1-143,2)", "_q___22")), CallExpr (loc "verified/lib.rs(139,1-143,2)", "lifetime_token", [], [], [
    LitPat (CallExpr (loc "verified/lib.rs(139,1-143,2)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(139,1-143,2)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(139,1-143,2)", None, "'__22"))))], Static))
  ], Static)), Sep (loc "verified/lib.rs(140,5-6)", Sep (loc "verified/lib.rs(140,5-6)", CallExpr (loc "verified/lib.rs(140,5-6)", "array", [IdentTypeExpr (loc "verified/lib.rs(140,5-6)", None, "T")], [], [
    LitPat (CastExpr (loc "verified/lib.rs(140,5-6)", PtrTypeExpr (loc "verified/lib.rs(140,5-6)", IdentTypeExpr (loc "verified/lib.rs(140,5-6)", None, "T")), CallExpr (loc "verified/lib.rs(140,5-6)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(140,5-6)", ManifestTypeExpr (loc "verified/lib.rs(140,5-6)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(140,5-6)", "v")))], Static)));
    LitPat (CallExpr (loc "verified/lib.rs(140,5-6)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(140,5-6)", "v"))], Static));
    VarPat (loc "verified/lib.rs(140,5-6)", "_v1_v")
  ], Static), CallExpr (loc "verified/lib.rs(140,5-6)", "foreach", [], [], [
    LitPat (Var (loc "verified/lib.rs(140,5-6)", "_v1_v"));
    LitPat (CallExpr (loc "verified/lib.rs(140,5-6)", "own", [IdentTypeExpr (loc "verified/lib.rs(140,5-6)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(140,5-6)", "_t"))], Static))
  ], Static)), Sep (loc "verified/lib.rs(141,5-12)", Sep (loc "verified/lib.rs(141,5-12)", CallExpr (loc "verified/lib.rs(141,5-12)", "array", [
    StructTypeExpr (loc "verified/lib.rs(141,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(141,5-12)", None, "T")])
  ], [], [
    LitPat (CastExpr (loc "verified/lib.rs(141,5-12)", PtrTypeExpr (loc "verified/lib.rs(141,5-12)", StructTypeExpr (loc "verified/lib.rs(141,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(141,5-12)", None, "T")])), CallExpr (loc "verified/lib.rs(141,5-12)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(141,5-12)", ManifestTypeExpr (loc "verified/lib.rs(141,5-12)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(141,5-12)", "scratch")))], Static)));
    LitPat (CallExpr (loc "verified/lib.rs(141,5-12)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(141,5-12)", "scratch"))], Static));
    VarPat (loc "verified/lib.rs(141,5-12)", "_v1_scratch")
  ], Static), CallExpr (loc "verified/lib.rs(141,5-12)", "foreach", [], [], [
    LitPat (Var (loc "verified/lib.rs(141,5-12)", "_v1_scratch"));
    LitPat (CallExpr (loc "verified/lib.rs(141,5-12)", "own", [
      StructTypeExpr (loc "verified/lib.rs(141,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(141,5-12)", None, "T")])
    ], [], [LitPat (Var (loc "verified/lib.rs(141,5-12)", "_t"))], Static))
  ], Static)), Sep (loc "verified/lib.rs(142,5-12)", Sep (loc "verified/lib.rs(142,5-12)", PointsTo (loc "verified/lib.rs(142,5-12)", Deref (loc "verified/lib.rs(142,5-12)", Var (loc "verified/lib.rs(142,5-12)", "is_less")), "RegularPointsTo", VarPat (loc "verified/lib.rs(142,5-12)", "_v1_is_less")), ExprCallExpr (loc "verified/lib.rs(142,5-12)", TypePredExpr (loc "verified/lib.rs(142,5-12)", IdentTypeExpr (loc "verified/lib.rs(142,5-12)", None, "F"), "own"), [LitPat (Var (loc "verified/lib.rs(142,5-12)", "_t")); LitPat (Var (loc "verified/lib.rs(142,5-12)", "_v1_is_less"))])), EmpAsn (loc "verified/lib.rs(139,1-143,2)")))))))))
], None)))), false, Some (([
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(143,2)", StructType ("std_tuple_0_", []))), "$_0", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(144,9-12)", Int (Unsigned, PtrRank)))), "len", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(144,15-16)", InferredTypeExpr (loc "verified/lib.rs(144,15-16)"), Shared, SliceTypeExpr (loc "verified/lib.rs(144,15-16)", IdentTypeExpr (loc "verified/lib.rs(144,15-16)", None, "T")))), "$_5", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(145,5-147,6)", StructType ("std_tuple_0_", [])))), "$_6", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(145,8-27)", Bool)), "$_7", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(145,8-22)", Int (Unsigned, PtrRank))), "$_8", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(145,28-147,6)", UnionType ("std_empty_"))), "$_9", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", PtrTypeExpr (loc "verified/lib.rs(151,9-15)", IdentTypeExpr (loc "verified/lib.rs(151,9-15)", None, "T")))), "v_base", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (PtrTypeExpr (loc "verified/lib.rs(151,18-41)", IdentTypeExpr (loc "verified/lib.rs(151,18-41)", None, "T"))), "$_11", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (PtrTypeExpr (loc "verified/lib.rs(151,18-31)", SliceTypeExpr (loc "verified/lib.rs(151,18-31)", IdentTypeExpr (loc "verified/lib.rs(151,18-31)", None, "T")))), "$_12", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (PtrTypeExpr (loc "verified/lib.rs(151,18-31)", SliceTypeExpr (loc "verified/lib.rs(151,18-31)", IdentTypeExpr (loc "verified/lib.rs(151,18-31)", None, "T")))), "$_13", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(153,8-16)", Bool)), "$_14", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(153,8-11)", Int (Unsigned, PtrRank))), "$_15", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(154,9-40)", StructType ("std_tuple_0_", [])))), "$_16", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(155,9-40)", StructType ("std_tuple_0_", [])))), "$_17", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(156,9-40)", StructType ("std_tuple_0_", [])))), "$_18", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(157,9-40)", StructType ("std_tuple_0_", [])))), "$_19", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(158,9-40)", StructType ("std_tuple_0_", [])))), "$_20", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(159,9-40)", StructType ("std_tuple_0_", [])))), "$_21", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(160,9-40)", StructType ("std_tuple_0_", [])))), "$_22", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(161,9-40)", StructType ("std_tuple_0_", [])))), "$_23", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(162,9-40)", StructType ("std_tuple_0_", [])))), "$_24", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(163,9-40)", StructType ("std_tuple_0_", [])))), "$_25", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(164,9-40)", StructType ("std_tuple_0_", [])))), "$_26", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(165,9-40)", StructType ("std_tuple_0_", [])))), "$_27", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(166,9-40)", StructType ("std_tuple_0_", [])))), "$_28", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(167,9-40)", StructType ("std_tuple_0_", [])))), "$_29", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(168,9-40)", StructType ("std_tuple_0_", [])))), "$_30", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(169,9-40)", StructType ("std_tuple_0_", [])))), "$_31", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(170,9-40)", StructType ("std_tuple_0_", [])))), "$_32", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(171,9-213,42)", StructType ("std_tuple_0_", [])))), "$_33", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(172,1-32)", StructType ("std_tuple_0_", [])))), "$_34", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(173,13-44)", StructType ("std_tuple_0_", [])))), "$_35", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(174,13-44)", StructType ("std_tuple_0_", [])))), "$_36", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(175,13-44)", StructType ("std_tuple_0_", [])))), "$_37", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(176,13-44)", StructType ("std_tuple_0_", [])))), "$_38", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(177,13-44)", StructType ("std_tuple_0_", [])))), "$_39", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(178,13-44)", StructType ("std_tuple_0_", [])))), "$_40", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(179,13-44)", StructType ("std_tuple_0_", [])))), "$_41", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(180,13-44)", StructType ("std_tuple_0_", [])))), "$_42", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(181,13-44)", StructType ("std_tuple_0_", [])))), "$_43", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(182,13-44)", StructType ("std_tuple_0_", [])))), "$_44", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(183,13-44)", StructType ("std_tuple_0_", [])))), "$_45", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(184,13-44)", StructType ("std_tuple_0_", [])))), "$_46", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(185,13-44)", StructType ("std_tuple_0_", [])))), "$_47", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(186,13-44)", StructType ("std_tuple_0_", [])))), "$_48", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(187,13-44)", StructType ("std_tuple_0_", [])))), "$_49", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(188,13-44)", StructType ("std_tuple_0_", [])))), "$_50", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(189,13-44)", StructType ("std_tuple_0_", [])))), "$_51", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(190,13-44)", StructType ("std_tuple_0_", [])))), "$_52", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(191,1-32)", StructType ("std_tuple_0_", [])))), "$_53", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(210,17-19)", Bool))), "c1", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(211,13-44)", StructType ("std_tuple_0_", [])))), "$_63", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(212,13-44)", StructType ("std_tuple_0_", [])))), "$_64", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(213,9-40)", StructType ("std_tuple_0_", [])))), "$_65", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(214,9-40)", StructType ("std_tuple_0_", [])))), "$_66", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(215,9-40)", StructType ("std_tuple_0_", [])))), "$_67", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(216,9-40)", StructType ("std_tuple_0_", [])))), "$_68", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(217,9-40)", StructType ("std_tuple_0_", [])))), "$_69", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(218,9-40)", StructType ("std_tuple_0_", [])))), "$_70", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(219,9-40)", StructType ("std_tuple_0_", [])))), "$_71", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(220,9-40)", StructType ("std_tuple_0_", [])))), "$_72", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(221,9-40)", StructType ("std_tuple_0_", [])))), "$_73", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(222,9-40)", StructType ("std_tuple_0_", [])))), "$_74", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(223,9-40)", StructType ("std_tuple_0_", [])))), "$_75", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(224,9-40)", StructType ("std_tuple_0_", [])))), "$_76", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(225,9-40)", StructType ("std_tuple_0_", [])))), "$_77", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", ManifestTypeExpr (loc "verified/lib.rs(226,9-40)", StructType ("std_tuple_0_", [])))), "$_78", None, (ref (false), ref (None)))]);
  LabelStmt (loc "verified/lib.rs(144,15-16)", "0");
  ExprStmt (AssignExpr (loc "verified/lib.rs(144,15-16)", Var (loc "verified/lib.rs(144,15-16)", "$_5"), Mutation, CallExpr (loc "verified/lib.rs(144,15-16)", "fn_outcome_result", [], [], [
    LitPat (CallExpr (loc "verified/lib.rs(144,15-16)", "create_slice_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(144,15-16)", Deref (loc "verified/lib.rs(144,15-16)", Var (loc "verified/lib.rs(144,15-16)", "v"))))], Static))
  ], Static)));
  ExprStmt (AssignExpr (loc "verified/lib.rs(144,15-22)", Var (loc "verified/lib.rs(144,15-22)", "len"), Initialization, CallExpr (loc "verified/lib.rs(144,17-22)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(144,17-22)", "$_5"))], Static)));
  SwitchStmt (loc "verified/lib.rs(145,8-22)", CallExpr (loc "verified/lib.rs(145,8-22)", "std::mem::size_of", [IdentTypeExpr (loc "verified/lib.rs(145,8-22)", None, "T")], [], [], Static), [
    SwitchStmtClause (loc "verified/lib.rs(145,8-22)", CallExpr (loc "verified/lib.rs(145,8-22)", "returning", [], [], [LitPat (Var (loc "verified/lib.rs(145,8-22)", "__result"))], Static), [ExprStmt (AssignExpr (loc "verified/lib.rs(145,8-22)", Var (loc "verified/lib.rs(145,8-22)", "$_8"), Mutation, Var (loc "verified/lib.rs(145,8-22)", "__result")))]);
    SwitchStmtClause (loc "verified/lib.rs(145,8-22)", CallExpr (loc "verified/lib.rs(145,8-22)", "unwinding", [], [], [], Static), [ReturnStmt (loc "verified/lib.rs(145,8-22)", Some (CallExpr (loc "verified/lib.rs(145,8-22)", "unwinding", [], [], [], Static)))])
  ]);
  ExprStmt (AssignExpr (loc "verified/lib.rs(145,8-27)", Var (loc "verified/lib.rs(145,8-27)", "$_7"), Mutation, Operation (loc "verified/lib.rs(145,8-27)", Eq, [Var (loc "verified/lib.rs(145,8-27)", "$_8"); CastExpr (loc "verified/lib.rs(145,26-27)", ManifestTypeExpr (loc "verified/lib.rs(145,26-27)", Int (Unsigned, PtrRank)), IntLit (loc "verified/lib.rs(145,26-27)", big_int_of_string "0", true, false, LLSuffix))])));
  IfStmt (loc "verified/lib.rs(145,8-27)", Var (loc "verified/lib.rs(145,8-27)", "$_7"), [GotoStmt (loc "verified/lib.rs(145,8-27)", "3")], [GotoStmt (loc "verified/lib.rs(145,8-27)", "4")]);
  LabelStmt (loc "verified/lib.rs(151,18-19)", "4");
  ExprStmt (AssignExpr (loc "verified/lib.rs(151,18-19)", Var (loc "verified/lib.rs(151,18-19)", "$_13"), Mutation, AddressOf (loc "verified/lib.rs(151,18-19)", Deref (loc "verified/lib.rs(151,18-19)", Var (loc "verified/lib.rs(151,18-19)", "v")))));
  ExprStmt (AssignExpr (loc "verified/lib.rs(151,18-31)", Var (loc "verified/lib.rs(151,18-31)", "$_12"), Mutation, Var (loc "verified/lib.rs(151,18-31)", "$_13")));
  ExprStmt (AssignExpr (loc "verified/lib.rs(151,18-41)", Var (loc "verified/lib.rs(151,18-41)", "$_11"), Mutation, CastExpr (loc "verified/lib.rs(151,18-41)", PtrTypeExpr (loc "verified/lib.rs(151,18-41)", IdentTypeExpr (loc "verified/lib.rs(151,18-41)", None, "T")), Var (loc "verified/lib.rs(151,18-41)", "$_12"))));
  ExprStmt (AssignExpr (loc "verified/lib.rs(151,18-41)", Var (loc "verified/lib.rs(151,18-41)", "v_base"), Initialization, Var (loc "verified/lib.rs(151,18-41)", "$_11")));
  ExprStmt (AssignExpr (loc "verified/lib.rs(153,8-11)", Var (loc "verified/lib.rs(153,8-11)", "$_15"), Mutation, Var (loc "verified/lib.rs(153,8-11)", "len")));
  ExprStmt (AssignExpr (loc "verified/lib.rs(153,8-16)", Var (loc "verified/lib.rs(153,8-16)", "$_14"), Mutation, Operation (loc "verified/lib.rs(153,8-16)", Ge, [Var (loc "verified/lib.rs(153,8-16)", "$_15"); CastExpr (loc "verified/lib.rs(153,15-16)", ManifestTypeExpr (loc "verified/lib.rs(153,15-16)", Int (Unsigned, PtrRank)), IntLit (loc "verified/lib.rs(153,15-16)", big_int_of_string "8", true, false, LLSuffix))])));
  IfStmt (loc "verified/lib.rs(153,8-16)", Var (loc "verified/lib.rs(153,8-16)", "$_14"), [GotoStmt (loc "verified/lib.rs(153,8-16)", "5")], [GotoStmt (loc "verified/lib.rs(153,8-16)", "6")]);
  LabelStmt (loc "verified/lib.rs(153,5-227,6)", "6");
  GotoStmt (loc "verified/lib.rs(153,5-227,6)", "62");
  LabelStmt (loc "verified/lib.rs(154,9-155,1)", "5");
  PureStmt (loc "verified/lib.rs(154,9-155,1)", ExprStmt (CallExpr (loc "verified/lib.rs(154,37-38)", "produce_type_interp", [IdentTypeExpr (loc "verified/lib.rs(154,35-36)", None, "T")], [], [], Static)));
  PureStmt (loc "verified/lib.rs(155,9-156,1)", ExprStmt (CallExpr (loc "verified/lib.rs(155,37-38)", "produce_type_interp", [IdentTypeExpr (loc "verified/lib.rs(155,35-36)", None, "F")], [], [], Static)));
  PureStmt (loc "verified/lib.rs(156,9-157,1)", Assert (loc "verified/lib.rs(156,13-19)", CallExpr (loc "verified/lib.rs(156,20-32)", "thread_token", [], [], [VarPat (loc "verified/lib.rs(156,34-35)", "t")], Static)));
  PureStmt (loc "verified/lib.rs(157,9-158,1)", Assert (loc "verified/lib.rs(157,13-19)", Operation (loc "verified/lib.rs(157,22-24)", Eq, [Var (loc "verified/lib.rs(157,20-21)", "t"); Var (loc "verified/lib.rs(157,25-38)", "currentThread")])));
  PureStmt (loc "verified/lib.rs(158,9-159,1)", Assert (loc "verified/lib.rs(158,13-19)", PointsTo (loc "verified/lib.rs(158,34-37)", ReadArray (loc "verified/lib.rs(158,26-27)", Var (loc "verified/lib.rs(158,20-26)", "v_base"), SliceExpr (loc "verified/lib.rs(158,27-29)", None, Some (LitPat (Var (loc "verified/lib.rs(158,29-32)", "len"))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(158,39-49)", "source_all"))));
  PureStmt (loc "verified/lib.rs(159,9-160,1)", Assert (loc "verified/lib.rs(159,13-19)", CallExpr (loc "verified/lib.rs(159,20-27)", "foreach", [], [], [
    LitPat (Var (loc "verified/lib.rs(159,28-38)", "source_all"));
    LitPat (CallExpr (loc "verified/lib.rs(159,48-49)", "own", [IdentTypeExpr (loc "verified/lib.rs(159,46-47)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(159,49-50)", "t"))], Static))
  ], Static)));
  PureStmt (loc "verified/lib.rs(160,9-161,1)", DeclStmt (loc "verified/lib.rs(160,13-16)", [
    (loc "verified/lib.rs(160,17-24)", None, "mu_base", Some (CastExpr (loc "verified/lib.rs(160,70-72)", PtrTypeExpr (loc "verified/lib.rs(160,73-74)", ConstructedTypeExpr (loc "verified/lib.rs(160,74-95)", "std::mem::MaybeUninit", [IdentTypeExpr (loc "verified/lib.rs(160,96-97)", None, "T")])), CallExpr (loc "verified/lib.rs(160,27-49)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(160,58-60)", IdentTypeExpr (loc "verified/lib.rs(160,61-68)", None, "pointer"), Var (loc "verified/lib.rs(160,50-57)", "scratch")))], Static))), (ref (false), ref (None)))
  ]));
  PureStmt (loc "verified/lib.rs(161,9-162,1)", DeclStmt (loc "verified/lib.rs(161,13-16)", [
    (loc "verified/lib.rs(161,17-28)", None, "scratch_len", Some (CallExpr (loc "verified/lib.rs(161,31-38)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(161,39-46)", "scratch"))], Static)), (ref (false), ref (None)))
  ]));
  PureStmt (loc "verified/lib.rs(162,9-163,1)", Assert (loc "verified/lib.rs(162,13-19)", PointsTo (loc "verified/lib.rs(162,43-46)", ReadArray (loc "verified/lib.rs(162,27-28)", Var (loc "verified/lib.rs(162,20-27)", "mu_base"), SliceExpr (loc "verified/lib.rs(162,28-30)", None, Some (LitPat (Var (loc "verified/lib.rs(162,30-41)", "scratch_len"))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(162,48-54)", "mu_all"))));
  PureStmt (loc "verified/lib.rs(163,9-164,1)", Assert (loc "verified/lib.rs(163,13-19)", CallExpr (loc "verified/lib.rs(163,20-27)", "foreach", [], [], [
    LitPat (Var (loc "verified/lib.rs(163,28-34)", "mu_all"));
    LitPat (CallExpr (loc "verified/lib.rs(163,67-68)", "own", [
      ConstructedTypeExpr (loc "verified/lib.rs(163,42-63)", "std::mem::MaybeUninit", [IdentTypeExpr (loc "verified/lib.rs(163,64-65)", None, "T")])
    ], [], [LitPat (Var (loc "verified/lib.rs(163,68-69)", "t"))], Static))
  ], Static)));
  PureStmt (loc "verified/lib.rs(164,9-165,1)", Assert (loc "verified/lib.rs(164,13-19)", PointsTo (loc "verified/lib.rs(164,29-32)", Deref (loc "verified/lib.rs(164,20-21)", Var (loc "verified/lib.rs(164,21-28)", "is_less")), "RegularPointsTo", VarPat (loc "verified/lib.rs(164,34-45)", "less_before"))));
  PureStmt (loc "verified/lib.rs(165,9-166,1)", Assert (loc "verified/lib.rs(165,13-19)", ExprCallExpr (loc "verified/lib.rs(165,27-28)", TypePredExpr (loc "verified/lib.rs(165,23-24)", IdentTypeExpr (loc "verified/lib.rs(165,21-22)", None, "F"), "own"), [LitPat (Var (loc "verified/lib.rs(165,28-29)", "t")); LitPat (Var (loc "verified/lib.rs(165,31-42)", "less_before"))])));
  PureStmt (loc "verified/lib.rs(166,9-167,1)", ExprStmt (CallExpr (loc "verified/lib.rs(166,29-30)", "array_split", [IdentTypeExpr (loc "verified/lib.rs(166,27-28)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(166,30-36)", "v_base")); LitPat (IntLit (loc "verified/lib.rs(166,38-39)", big_int_of_string "4", true, false, NoLSuffix))], Static)));
  PureStmt (loc "verified/lib.rs(167,9-168,1)", ExprStmt (CallExpr (loc "verified/lib.rs(167,13-26)", "foreach_split", [], [], [
    LitPat (Var (loc "verified/lib.rs(167,27-37)", "source_all"));
    LitPat (CallExpr (loc "verified/lib.rs(167,47-48)", "own", [IdentTypeExpr (loc "verified/lib.rs(167,45-46)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(167,48-49)", "t"))], Static));
    LitPat (IntLit (loc "verified/lib.rs(167,52-53)", big_int_of_string "4", true, false, NoLSuffix))
  ], Static)));
  PureStmt (loc "verified/lib.rs(168,9-169,1)", Assert (loc "verified/lib.rs(168,13-19)", PointsTo (loc "verified/lib.rs(168,32-35)", ReadArray (loc "verified/lib.rs(168,26-27)", Var (loc "verified/lib.rs(168,20-26)", "v_base"), SliceExpr (loc "verified/lib.rs(168,27-29)", None, Some (LitPat (IntLit (loc "verified/lib.rs(168,29-30)", big_int_of_string "4", true, false, NoLSuffix))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(168,37-47)", "first_four"))));
  PureStmt (loc "verified/lib.rs(169,9-170,1)", ExprStmt (CallExpr (loc "verified/lib.rs(169,41-42)", "interior_pointer_limits", [IdentTypeExpr (loc "verified/lib.rs(169,39-40)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(169,42-48)", "v_base")); LitPat (IntLit (loc "verified/lib.rs(169,50-51)", big_int_of_string "4", true, false, NoLSuffix)); LitPat (IntLit (loc "verified/lib.rs(169,53-54)", big_int_of_string "1", true, false, NoLSuffix))], Static)));
  PureStmt (loc "verified/lib.rs(170,9-171,1)", DeclStmt (loc "verified/lib.rs(170,13-16)", [(loc "verified/lib.rs(170,17-22)", None, "cmp_k", Some (CallExpr (loc "verified/lib.rs(170,25-39)", "begin_lifetime", [], [], [], Static)), (ref (false), ref (None)))]));
  GotoStmt (loc "verified/lib.rs(172,1-30)", "bh0");
  LabelStmt (loc "verified/lib.rs(172,1-30)", "bh0");
  BlockStmt (loc "verified/lib.rs(172,1-30)", [], [
    BlockStmt (loc "verified/lib.rs(172,1-30)", [
      TypeWithTypeidDecl (loc "verified/lib.rs(172,5-12)", "'cmp", CallExpr (loc "verified/lib.rs(172,5-12)", "typeid_of_lft", [], [], [LitPat (Var (loc "verified/lib.rs(172,20-25)", "cmp_k"))], Static))
    ], [
      ExprStmt (CallExpr (loc "verified/lib.rs(212,13-213,1)", "#strict_lft_binding_scope", [IdentTypeExpr (loc "verified/lib.rs(212,13-213,1)", None, "'cmp")], [], [], Static));
      DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(210,22-29)", InferredTypeExpr (loc "verified/lib.rs(210,22-29)"), Mutable, IdentTypeExpr (loc "verified/lib.rs(210,22-29)", None, "F"))), "$_55", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(139,1-228,2)", [
        (loc "verified/lib.rs(139,1-228,2)", Some (StructTypeExpr (loc "verified/lib.rs(210,22-93)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(210,22-93)", InferredTypeExpr (loc "verified/lib.rs(210,22-93)"), Shared, IdentTypeExpr (loc "verified/lib.rs(210,22-93)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(210,22-93)", InferredTypeExpr (loc "verified/lib.rs(210,22-93)"), Shared, IdentTypeExpr (loc "verified/lib.rs(210,22-93)", None, "T"))])), "$_56", None, (ref (false), ref (None)))
      ]);
      DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(210,67-82)", InferredTypeExpr (loc "verified/lib.rs(210,67-82)"), Shared, IdentTypeExpr (loc "verified/lib.rs(210,67-82)", None, "T"))), "$_57", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", RustRefTypeExpr (loc "verified/lib.rs(210,67-82)", InferredTypeExpr (loc "verified/lib.rs(210,67-82)"), Shared, IdentTypeExpr (loc "verified/lib.rs(210,67-82)", None, "T")))), "$_58", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", PtrTypeExpr (loc "verified/lib.rs(210,69-82)", IdentTypeExpr (loc "verified/lib.rs(210,69-82)", None, "T")))), "$_59", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (PtrTypeExpr (loc "verified/lib.rs(210,69-75)", IdentTypeExpr (loc "verified/lib.rs(210,69-75)", None, "T"))), "$_60", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(210,84-92)", InferredTypeExpr (loc "verified/lib.rs(210,84-92)"), Shared, IdentTypeExpr (loc "verified/lib.rs(210,84-92)", None, "T"))), "$_61", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(139,1-228,2)", [(loc "verified/lib.rs(139,1-228,2)", Some (ConstTypeExpr (loc "verified/lib.rs(139,1-228,2)", RustRefTypeExpr (loc "verified/lib.rs(210,84-92)", InferredTypeExpr (loc "verified/lib.rs(210,84-92)"), Shared, IdentTypeExpr (loc "verified/lib.rs(210,84-92)", None, "T")))), "$_62", None, (ref (false), ref (None)))]);
      LabelStmt (loc "verified/lib.rs(172,1-30)", "bh0");
      GotoStmt (loc "verified/lib.rs(172,1-32)", "24");
      LabelStmt (loc "verified/lib.rs(173,13-174,1)", "24");
      PureStmt (loc "verified/lib.rs(173,13-174,1)", ExprStmt (CallExpr (loc "verified/lib.rs(173,44-45)", "split_four_owned_cells", [IdentTypeExpr (loc "verified/lib.rs(173,42-43)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(173,45-51)", "v_base")); LitPat (Var (loc "verified/lib.rs(173,53-54)", "t"))], Static)));
      PureStmt (loc "verified/lib.rs(174,13-175,1)", ExprStmt (CallExpr (loc "verified/lib.rs(174,47-48)", "close_full_borrow_content", [IdentTypeExpr (loc "verified/lib.rs(174,45-46)", None, "T")], [], [
        LitPat (Var (loc "verified/lib.rs(174,48-49)", "t"));
        LitPat (Operation (loc "verified/lib.rs(174,58-59)", Add, [Var (loc "verified/lib.rs(174,51-57)", "v_base"); IntLit (loc "verified/lib.rs(174,60-61)", big_int_of_string "1", true, false, NoLSuffix)]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(175,13-176,1)", ExprStmt (CallExpr (loc "verified/lib.rs(175,47-48)", "close_full_borrow_content", [IdentTypeExpr (loc "verified/lib.rs(175,45-46)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(175,48-49)", "t")); LitPat (Var (loc "verified/lib.rs(175,51-57)", "v_base"))], Static)));
      PureStmt (loc "verified/lib.rs(176,13-177,1)", ExprStmt (CallExpr (loc "verified/lib.rs(176,17-23)", "borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(176,24-29)", "cmp_k"));
        LitPat (ExprCallExpr (loc "verified/lib.rs(176,54-55)", TypePredExpr (loc "verified/lib.rs(176,34-35)", IdentTypeExpr (loc "verified/lib.rs(176,32-33)", None, "T"), "full_borrow_content"), [
          LitPat (Var (loc "verified/lib.rs(176,55-56)", "t"));
          LitPat (Operation (loc "verified/lib.rs(176,65-66)", Add, [Var (loc "verified/lib.rs(176,58-64)", "v_base"); IntLit (loc "verified/lib.rs(176,67-68)", big_int_of_string "1", true, false, NoLSuffix)]))
        ]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(177,13-178,1)", ExprStmt (CallExpr (loc "verified/lib.rs(177,17-23)", "borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(177,24-29)", "cmp_k"));
        LitPat (ExprCallExpr (loc "verified/lib.rs(177,54-55)", TypePredExpr (loc "verified/lib.rs(177,34-35)", IdentTypeExpr (loc "verified/lib.rs(177,32-33)", None, "T"), "full_borrow_content"), [LitPat (Var (loc "verified/lib.rs(177,55-56)", "t")); LitPat (Var (loc "verified/lib.rs(177,58-64)", "v_base"))]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(178,13-179,1)", ExprStmt (CallExpr (loc "verified/lib.rs(178,39-40)", "share_full_borrow", [IdentTypeExpr (loc "verified/lib.rs(178,37-38)", None, "T")], [], [
        LitPat (Var (loc "verified/lib.rs(178,40-45)", "cmp_k"));
        LitPat (Var (loc "verified/lib.rs(178,47-48)", "t"));
        LitPat (Operation (loc "verified/lib.rs(178,57-58)", Add, [Var (loc "verified/lib.rs(178,50-56)", "v_base"); IntLit (loc "verified/lib.rs(178,59-60)", big_int_of_string "1", true, false, NoLSuffix)]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(179,13-180,1)", ExprStmt (CallExpr (loc "verified/lib.rs(179,39-40)", "share_full_borrow", [IdentTypeExpr (loc "verified/lib.rs(179,37-38)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(179,40-45)", "cmp_k")); LitPat (Var (loc "verified/lib.rs(179,47-48)", "t")); LitPat (Var (loc "verified/lib.rs(179,50-56)", "v_base"))], Static)));
      PureStmt (loc "verified/lib.rs(180,13-181,1)", DeclStmt (loc "verified/lib.rs(180,17-20)", [
        (loc "verified/lib.rs(180,21-29)", None, "left_ref", Some (CallExpr (loc "verified/lib.rs(180,32-45)", "precreate_ref", [], [], [
          LitPat (Operation (loc "verified/lib.rs(180,53-54)", Add, [Var (loc "verified/lib.rs(180,46-52)", "v_base"); IntLit (loc "verified/lib.rs(180,55-56)", big_int_of_string "1", true, false, NoLSuffix)]))
        ], Static)), (ref (false), ref (None)))
      ]));
      PureStmt (loc "verified/lib.rs(181,13-182,1)", DeclStmt (loc "verified/lib.rs(181,17-20)", [
        (loc "verified/lib.rs(181,21-30)", None, "right_ref", Some (CallExpr (loc "verified/lib.rs(181,33-46)", "precreate_ref", [], [], [LitPat (Var (loc "verified/lib.rs(181,47-53)", "v_base"))], Static)), (ref (false), ref (None)))
      ]));
      PureStmt (loc "verified/lib.rs(182,13-183,1)", ExprStmt (CallExpr (loc "verified/lib.rs(182,36-37)", "init_ref_share", [IdentTypeExpr (loc "verified/lib.rs(182,34-35)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(182,37-42)", "cmp_k")); LitPat (Var (loc "verified/lib.rs(182,44-45)", "t")); LitPat (Var (loc "verified/lib.rs(182,47-55)", "left_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(183,13-184,1)", ExprStmt (CallExpr (loc "verified/lib.rs(183,36-37)", "init_ref_share", [IdentTypeExpr (loc "verified/lib.rs(183,34-35)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(183,37-42)", "cmp_k")); LitPat (Var (loc "verified/lib.rs(183,44-45)", "t")); LitPat (Var (loc "verified/lib.rs(183,47-56)", "right_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(184,13-185,1)", ExprStmt (CallExpr (loc "verified/lib.rs(184,41-42)", "close_ref_own", [IdentTypeExpr (loc "verified/lib.rs(184,33-37)", None, "'cmp"); IdentTypeExpr (loc "verified/lib.rs(184,39-40)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(184,42-50)", "left_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(185,13-186,1)", ExprStmt (CallExpr (loc "verified/lib.rs(185,41-42)", "close_ref_own", [IdentTypeExpr (loc "verified/lib.rs(185,33-37)", None, "'cmp"); IdentTypeExpr (loc "verified/lib.rs(185,39-40)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(185,42-51)", "right_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(186,13-187,1)", Close (loc "verified/lib.rs(186,17-22)", None, "std_tuple_2__own", [RustRefTypeExpr (loc "verified/lib.rs(186,25-26)", IdentTypeExpr (loc "verified/lib.rs(186,25-26)", None, "'cmp"), Shared, IdentTypeExpr (loc "verified/lib.rs(186,31-32)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(186,34-35)", IdentTypeExpr (loc "verified/lib.rs(186,34-35)", None, "'cmp"), Shared, IdentTypeExpr (loc "verified/lib.rs(186,40-41)", None, "T"))], [], [
        LitPat (Var (loc "verified/lib.rs(186,48-49)", "t"));
        LitPat (CastExpr (loc "verified/lib.rs(186,51-63)", StructTypeExpr (loc "verified/lib.rs(186,51-63)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(186,66-67)", IdentTypeExpr (loc "verified/lib.rs(186,66-67)", None, "'cmp"), Shared, IdentTypeExpr (loc "verified/lib.rs(186,72-73)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(186,75-76)", IdentTypeExpr (loc "verified/lib.rs(186,75-76)", None, "'cmp"), Shared, IdentTypeExpr (loc "verified/lib.rs(186,81-82)", None, "T"))]), InitializerList (loc "verified/lib.rs(186,51-63)", [(Some ((loc "verified/lib.rs(186,86-87)", "0")), Var (loc "verified/lib.rs(186,89-97)", "left_ref")); (Some ((loc "verified/lib.rs(186,99-100)", "1")), Var (loc "verified/lib.rs(186,102-111)", "right_ref"))])))
      ], None));
      PureStmt (loc "verified/lib.rs(187,13-188,1)", ExprStmt (CallExpr (loc "verified/lib.rs(187,17-33)", "open_frac_borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(187,34-39)", "cmp_k"));
        LitPat (CallExpr (loc "verified/lib.rs(187,41-57)", "ref_initialized_", [], [], [LitPat (Var (loc "verified/lib.rs(187,58-66)", "left_ref"))], Static));
        LitPat (Operation (loc "verified/lib.rs(187,70-71)", Div, [IntLit (loc "verified/lib.rs(187,69-70)", big_int_of_string "1", true, false, NoLSuffix); IntLit (loc "verified/lib.rs(187,71-72)", big_int_of_string "4", true, false, NoLSuffix)]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(188,13-189,1)", Open (loc "verified/lib.rs(188,17-21)", None, "ref_initialized_", [IdentTypeExpr (loc "verified/lib.rs(188,57-58)", None, "T")], [LitPat (Var (loc "verified/lib.rs(188,60-68)", "left_ref"))], [], Some (VarPat (loc "verified/lib.rs(188,24-37)", "left_fraction"))));
      PureStmt (loc "verified/lib.rs(189,13-190,1)", ExprStmt (CallExpr (loc "verified/lib.rs(189,17-33)", "open_frac_borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(189,34-39)", "cmp_k"));
        LitPat (CallExpr (loc "verified/lib.rs(189,41-57)", "ref_initialized_", [], [], [LitPat (Var (loc "verified/lib.rs(189,58-67)", "right_ref"))], Static));
        LitPat (Operation (loc "verified/lib.rs(189,71-72)", Div, [IntLit (loc "verified/lib.rs(189,70-71)", big_int_of_string "1", true, false, NoLSuffix); IntLit (loc "verified/lib.rs(189,72-73)", big_int_of_string "4", true, false, NoLSuffix)]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(190,13-191,1)", Open (loc "verified/lib.rs(190,17-21)", None, "ref_initialized_", [IdentTypeExpr (loc "verified/lib.rs(190,58-59)", None, "T")], [LitPat (Var (loc "verified/lib.rs(190,61-70)", "right_ref"))], [], Some (VarPat (loc "verified/lib.rs(190,24-38)", "right_fraction"))));
      NoopStmt (loc "verified/lib.rs(191,1-209,18)");
      ExprStmt (AssignExpr (loc "verified/lib.rs(210,22-29)", Var (loc "verified/lib.rs(210,22-29)", "$_55"), Mutation, AddressOf (loc "verified/lib.rs(210,22-29)", Deref (loc "verified/lib.rs(210,22-29)", Var (loc "verified/lib.rs(210,22-29)", "is_less")))));
      ExprStmt (AssignExpr (loc "verified/lib.rs(210,69-75)", Var (loc "verified/lib.rs(210,69-75)", "$_60"), Mutation, Var (loc "verified/lib.rs(210,69-75)", "v_base")));
      ExprStmt (AssignExpr (loc "verified/lib.rs(210,69-82)", Var (loc "verified/lib.rs(210,69-82)", "$_59"), Initialization, Operation (loc "verified/lib.rs(210,76-82)", Add, [Var (loc "verified/lib.rs(210,76-82)", "$_60"); CastExpr (loc "verified/lib.rs(210,80-81)", ManifestTypeExpr (loc "verified/lib.rs(210,80-81)", Int (Unsigned, PtrRank)), IntLit (loc "verified/lib.rs(210,80-81)", big_int_of_string "1", true, false, LLSuffix))])));
      ExprStmt (AssignExpr (loc "verified/lib.rs(210,67-82)", Var (loc "verified/lib.rs(210,67-82)", "$_58"), Initialization, CallExpr (loc "verified/lib.rs(210,67-82)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(210,67-82)", "create_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(210,67-82)", Deref (loc "verified/lib.rs(210,67-82)", Var (loc "verified/lib.rs(210,67-82)", "$_59"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(210,67-82)", Var (loc "verified/lib.rs(210,67-82)", "$_57"), Mutation, CallExpr (loc "verified/lib.rs(210,67-82)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(210,67-82)", "reborrow_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(210,67-82)", Deref (loc "verified/lib.rs(210,67-82)", Var (loc "verified/lib.rs(210,67-82)", "$_58"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(210,84-92)", Var (loc "verified/lib.rs(210,84-92)", "$_62"), Initialization, CallExpr (loc "verified/lib.rs(210,84-92)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(210,84-92)", "create_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(210,84-92)", Deref (loc "verified/lib.rs(210,84-92)", Var (loc "verified/lib.rs(210,84-92)", "v_base"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(210,84-92)", Var (loc "verified/lib.rs(210,84-92)", "$_61"), Mutation, CallExpr (loc "verified/lib.rs(210,84-92)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(210,84-92)", "reborrow_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(210,84-92)", Deref (loc "verified/lib.rs(210,84-92)", Var (loc "verified/lib.rs(210,84-92)", "$_62"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(210,22-93)", Select (loc "verified/lib.rs(210,22-93)", Var (loc "verified/lib.rs(210,22-93)", "$_56"), "0"), Mutation, Var (loc "verified/lib.rs(210,22-93)", "$_57")));
      ExprStmt (AssignExpr (loc "verified/lib.rs(210,22-93)", Select (loc "verified/lib.rs(210,22-93)", Var (loc "verified/lib.rs(210,22-93)", "$_56"), "1"), Mutation, Var (loc "verified/lib.rs(210,22-93)", "$_61")));
      ExprStmt (CallExpr (loc "verified/lib.rs(210,22-93)", "#register_type_projection_equality", [
        ProjectionTypeExpr (loc "verified/lib.rs(210,22-93)", IdentTypeExpr (loc "verified/lib.rs(210,35-36)", None, "F"), "std::ops::FnOnce", [
          StructTypeExpr (loc "verified/lib.rs(210,38-39)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(210,39-40)", IdentTypeExpr (loc "verified/lib.rs(210,39-40)", None, "'cmp"), Shared, IdentTypeExpr (loc "verified/lib.rs(210,45-46)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(210,48-49)", IdentTypeExpr (loc "verified/lib.rs(210,48-49)", None, "'cmp"), Shared, IdentTypeExpr (loc "verified/lib.rs(210,54-55)", None, "T"))])
        ], "Output");
        ManifestTypeExpr (loc "verified/lib.rs(210,22-93)", Bool)
      ], [], [], Static));
      SwitchStmt (loc "verified/lib.rs(210,22-93)", CallExpr (loc "verified/lib.rs(210,22-93)", "std::ops::FnMut::call_mut", [
        IdentTypeExpr (loc "verified/lib.rs(210,35-36)", None, "F");
        StructTypeExpr (loc "verified/lib.rs(210,38-39)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(210,39-40)", IdentTypeExpr (loc "verified/lib.rs(210,39-40)", None, "'cmp"), Shared, IdentTypeExpr (loc "verified/lib.rs(210,45-46)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(210,48-49)", IdentTypeExpr (loc "verified/lib.rs(210,48-49)", None, "'cmp"), Shared, IdentTypeExpr (loc "verified/lib.rs(210,54-55)", None, "T"))]);
        IdentTypeExpr (loc "verified/lib.rs(210,58-62)", None, "'cmp")
      ], [], [LitPat (Var (loc "verified/lib.rs(210,22-93)", "$_55")); LitPat (Var (loc "verified/lib.rs(210,22-93)", "$_56"))], Static), [
        SwitchStmtClause (loc "verified/lib.rs(210,22-93)", CallExpr (loc "verified/lib.rs(210,22-93)", "returning", [], [], [LitPat (Var (loc "verified/lib.rs(210,22-93)", "__result"))], Static), [ExprStmt (AssignExpr (loc "verified/lib.rs(210,22-93)", Var (loc "verified/lib.rs(210,22-93)", "c1"), Initialization, Var (loc "verified/lib.rs(210,22-93)", "__result")))]);
        SwitchStmtClause (loc "verified/lib.rs(210,22-93)", CallExpr (loc "verified/lib.rs(210,22-93)", "unwinding", [], [], [], Static), [
          PureStmt (loc "verified/lib.rs(195,19-24)", Close (loc "verified/lib.rs(195,19-24)", None, "comparison_debt", [IdentTypeExpr (loc "verified/lib.rs(195,43-44)", None, "T")], [], [
            LitPat (Var (loc "verified/lib.rs(195,46-47)", "t"));
            LitPat (Var (loc "verified/lib.rs(195,49-54)", "cmp_k"));
            LitPat (Operation (loc "verified/lib.rs(195,63-64)", Add, [Var (loc "verified/lib.rs(195,56-62)", "v_base"); IntLit (loc "verified/lib.rs(195,65-66)", big_int_of_string "1", true, false, NoLSuffix)]));
            LitPat (Var (loc "verified/lib.rs(195,68-74)", "v_base"));
            LitPat (Var (loc "verified/lib.rs(195,76-84)", "left_ref"));
            LitPat (Var (loc "verified/lib.rs(195,86-95)", "right_ref"));
            LitPat (Var (loc "verified/lib.rs(195,97-110)", "left_fraction"));
            LitPat (Var (loc "verified/lib.rs(195,112-126)", "right_fraction"))
          ], None));
          GotoStmt (loc "verified/lib.rs(210,22-93)", "#native_c1_first_unwind_epilogue")
        ])
      ]);
      PureStmt (loc "verified/lib.rs(211,13-212,1)", Close (loc "verified/lib.rs(211,17-22)", None, "comparison_debt", [IdentTypeExpr (loc "verified/lib.rs(211,41-42)", None, "T")], [], [
        LitPat (Var (loc "verified/lib.rs(211,44-45)", "t"));
        LitPat (Var (loc "verified/lib.rs(211,47-52)", "cmp_k"));
        LitPat (Operation (loc "verified/lib.rs(211,61-62)", Add, [Var (loc "verified/lib.rs(211,54-60)", "v_base"); IntLit (loc "verified/lib.rs(211,63-64)", big_int_of_string "1", true, false, NoLSuffix)]));
        LitPat (Var (loc "verified/lib.rs(211,66-72)", "v_base"));
        LitPat (Var (loc "verified/lib.rs(211,74-82)", "left_ref"));
        LitPat (Var (loc "verified/lib.rs(211,84-93)", "right_ref"));
        LitPat (Var (loc "verified/lib.rs(211,95-108)", "left_fraction"));
        LitPat (Var (loc "verified/lib.rs(211,110-124)", "right_fraction"))
      ], None))
    ], loc "verified/lib.rs(212,13-213,1)", ref ([]));
    NoopStmt (loc "verified/lib.rs(212,13-213,1)");
    GotoStmt (loc "verified/lib.rs(213,9-40)", "48")
  ], loc "verified/lib.rs(213,9-10)", ref ([]));
  LabelStmt (loc "verified/lib.rs(214,9-215,1)", "48");
  PureStmt (loc "verified/lib.rs(214,9-215,1)", ExprStmt (CallExpr (loc "verified/lib.rs(214,30-31)", "recover_pair", [IdentTypeExpr (loc "verified/lib.rs(214,28-29)", None, "T")], [], [
    LitPat (Operation (loc "verified/lib.rs(214,38-39)", Add, [Var (loc "verified/lib.rs(214,31-37)", "v_base"); IntLit (loc "verified/lib.rs(214,40-41)", big_int_of_string "1", true, false, NoLSuffix)]));
    LitPat (Var (loc "verified/lib.rs(214,43-49)", "v_base"))
  ], Static)));
  PureStmt (loc "verified/lib.rs(215,9-216,1)", ExprStmt (CallExpr (loc "verified/lib.rs(215,39-40)", "join_four_owned_cells", [IdentTypeExpr (loc "verified/lib.rs(215,37-38)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(215,40-46)", "v_base")); LitPat (Var (loc "verified/lib.rs(215,48-49)", "t"))], Static)));
  PureStmt (loc "verified/lib.rs(216,9-217,1)", Assert (loc "verified/lib.rs(216,13-19)", PointsTo (loc "verified/lib.rs(216,32-35)", ReadArray (loc "verified/lib.rs(216,26-27)", Var (loc "verified/lib.rs(216,20-26)", "v_base"), SliceExpr (loc "verified/lib.rs(216,27-29)", None, Some (LitPat (IntLit (loc "verified/lib.rs(216,29-30)", big_int_of_string "4", true, false, NoLSuffix))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(216,37-50)", "first_current"))));
  PureStmt (loc "verified/lib.rs(217,9-218,1)", ExprStmt (CallExpr (loc "verified/lib.rs(217,28-29)", "array_join", [IdentTypeExpr (loc "verified/lib.rs(217,26-27)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(217,29-35)", "v_base"))], Static)));
  PureStmt (loc "verified/lib.rs(218,9-219,1)", ExprStmt (CallExpr (loc "verified/lib.rs(218,13-27)", "foreach_append", [], [], [
    LitPat (Var (loc "verified/lib.rs(218,28-41)", "first_current"));
    LitPat (CallExpr (loc "verified/lib.rs(218,43-47)", "drop", [], [], [LitPat (IntLit (loc "verified/lib.rs(218,48-49)", big_int_of_string "4", true, false, NoLSuffix)); LitPat (Var (loc "verified/lib.rs(218,51-61)", "source_all"))], Static))
  ], Static)));
  PureStmt (loc "verified/lib.rs(219,9-220,1)", Assert (loc "verified/lib.rs(219,13-19)", PointsTo (loc "verified/lib.rs(219,34-37)", ReadArray (loc "verified/lib.rs(219,26-27)", Var (loc "verified/lib.rs(219,20-26)", "v_base"), SliceExpr (loc "verified/lib.rs(219,27-29)", None, Some (LitPat (Var (loc "verified/lib.rs(219,29-32)", "len"))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(219,39-53)", "source_current"))));
  PureStmt (loc "verified/lib.rs(220,9-221,1)", Assert (loc "verified/lib.rs(220,13-19)", CallExpr (loc "verified/lib.rs(220,20-27)", "foreach", [], [], [
    LitPat (Var (loc "verified/lib.rs(220,28-42)", "source_current"));
    LitPat (CallExpr (loc "verified/lib.rs(220,52-53)", "own", [IdentTypeExpr (loc "verified/lib.rs(220,50-51)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(220,53-54)", "t"))], Static))
  ], Static)));
  PureStmt (loc "verified/lib.rs(221,9-222,1)", Assert (loc "verified/lib.rs(221,13-19)", PointsTo (loc "verified/lib.rs(221,43-46)", ReadArray (loc "verified/lib.rs(221,27-28)", Var (loc "verified/lib.rs(221,20-27)", "mu_base"), SliceExpr (loc "verified/lib.rs(221,28-30)", None, Some (LitPat (Var (loc "verified/lib.rs(221,30-41)", "scratch_len"))))), "RegularPointsTo", LitPat (Var (loc "verified/lib.rs(221,47-53)", "mu_all")))));
  PureStmt (loc "verified/lib.rs(222,9-223,1)", Assert (loc "verified/lib.rs(222,13-19)", CallExpr (loc "verified/lib.rs(222,20-27)", "foreach", [], [], [
    LitPat (Var (loc "verified/lib.rs(222,28-34)", "mu_all"));
    LitPat (CallExpr (loc "verified/lib.rs(222,67-68)", "own", [
      ConstructedTypeExpr (loc "verified/lib.rs(222,42-63)", "std::mem::MaybeUninit", [IdentTypeExpr (loc "verified/lib.rs(222,64-65)", None, "T")])
    ], [], [LitPat (Var (loc "verified/lib.rs(222,68-69)", "t"))], Static))
  ], Static)));
  PureStmt (loc "verified/lib.rs(223,9-224,1)", Assert (loc "verified/lib.rs(223,13-19)", PointsTo (loc "verified/lib.rs(223,29-32)", Deref (loc "verified/lib.rs(223,20-21)", Var (loc "verified/lib.rs(223,21-28)", "is_less")), "RegularPointsTo", VarPat (loc "verified/lib.rs(223,34-46)", "less_current"))));
  PureStmt (loc "verified/lib.rs(224,9-225,1)", Assert (loc "verified/lib.rs(224,13-19)", ExprCallExpr (loc "verified/lib.rs(224,27-28)", TypePredExpr (loc "verified/lib.rs(224,23-24)", IdentTypeExpr (loc "verified/lib.rs(224,21-22)", None, "F"), "own"), [LitPat (Var (loc "verified/lib.rs(224,28-29)", "t")); LitPat (Var (loc "verified/lib.rs(224,31-43)", "less_current"))])));
  PureStmt (loc "verified/lib.rs(225,9-226,1)", Leak (loc "verified/lib.rs(225,13-17)", CallExpr (loc "verified/lib.rs(225,34-35)", "type_interp", [IdentTypeExpr (loc "verified/lib.rs(225,32-33)", None, "T")], [], [], Static)));
  PureStmt (loc "verified/lib.rs(226,9-227,1)", Leak (loc "verified/lib.rs(226,13-17)", CallExpr (loc "verified/lib.rs(226,34-35)", "type_interp", [IdentTypeExpr (loc "verified/lib.rs(226,32-33)", None, "F")], [], [], Static)));
  GotoStmt (loc "verified/lib.rs(153,5-227,6)", "62");
  LabelStmt (loc "verified/lib.rs(210,22-93)", "#native_c1_first_unwind_epilogue");
  PureStmt (loc "verified/lib.rs(196,36-37)", ExprStmt (CallExpr (loc "verified/lib.rs(196,36-37)", "recover_pair", [IdentTypeExpr (loc "verified/lib.rs(196,34-35)", None, "T")], [], [
    LitPat (Operation (loc "verified/lib.rs(196,44-45)", Add, [Var (loc "verified/lib.rs(196,37-43)", "v_base"); IntLit (loc "verified/lib.rs(196,46-47)", big_int_of_string "1", true, false, NoLSuffix)]));
    LitPat (Var (loc "verified/lib.rs(196,49-55)", "v_base"))
  ], Static)));
  PureStmt (loc "verified/lib.rs(197,45-46)", ExprStmt (CallExpr (loc "verified/lib.rs(197,45-46)", "join_four_owned_cells", [IdentTypeExpr (loc "verified/lib.rs(197,43-44)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(197,46-52)", "v_base")); LitPat (Var (loc "verified/lib.rs(197,54-55)", "t"))], Static)));
  PureStmt (loc "verified/lib.rs(198,19-25)", Assert (loc "verified/lib.rs(198,19-25)", PointsTo (loc "verified/lib.rs(198,38-41)", ReadArray (loc "verified/lib.rs(198,32-33)", Var (loc "verified/lib.rs(198,26-32)", "v_base"), SliceExpr (loc "verified/lib.rs(198,33-35)", None, Some (LitPat (IntLit (loc "verified/lib.rs(198,35-36)", big_int_of_string "4", true, false, NoLSuffix))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(198,43-56)", "first_current"))));
  PureStmt (loc "verified/lib.rs(199,34-35)", ExprStmt (CallExpr (loc "verified/lib.rs(199,34-35)", "array_join", [IdentTypeExpr (loc "verified/lib.rs(199,32-33)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(199,35-41)", "v_base"))], Static)));
  PureStmt (loc "verified/lib.rs(200,19-33)", ExprStmt (CallExpr (loc "verified/lib.rs(200,19-33)", "foreach_append", [], [], [
    LitPat (Var (loc "verified/lib.rs(200,34-47)", "first_current"));
    LitPat (CallExpr (loc "verified/lib.rs(200,49-53)", "drop", [], [], [LitPat (IntLit (loc "verified/lib.rs(200,54-55)", big_int_of_string "4", true, false, NoLSuffix)); LitPat (Var (loc "verified/lib.rs(200,57-67)", "source_all"))], Static))
  ], Static)));
  PureStmt (loc "verified/lib.rs(201,19-25)", Assert (loc "verified/lib.rs(201,19-25)", PointsTo (loc "verified/lib.rs(201,40-43)", ReadArray (loc "verified/lib.rs(201,32-33)", Var (loc "verified/lib.rs(201,26-32)", "v_base"), SliceExpr (loc "verified/lib.rs(201,33-35)", None, Some (LitPat (Var (loc "verified/lib.rs(201,35-38)", "len"))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(201,45-59)", "source_current"))));
  PureStmt (loc "verified/lib.rs(202,19-25)", Assert (loc "verified/lib.rs(202,19-25)", CallExpr (loc "verified/lib.rs(202,26-33)", "foreach", [], [], [
    LitPat (Var (loc "verified/lib.rs(202,34-48)", "source_current"));
    LitPat (CallExpr (loc "verified/lib.rs(202,58-59)", "own", [IdentTypeExpr (loc "verified/lib.rs(202,56-57)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(202,59-60)", "t"))], Static))
  ], Static)));
  PureStmt (loc "verified/lib.rs(203,19-25)", Assert (loc "verified/lib.rs(203,19-25)", PointsTo (loc "verified/lib.rs(203,49-52)", ReadArray (loc "verified/lib.rs(203,33-34)", Var (loc "verified/lib.rs(203,26-33)", "mu_base"), SliceExpr (loc "verified/lib.rs(203,34-36)", None, Some (LitPat (Var (loc "verified/lib.rs(203,36-47)", "scratch_len"))))), "RegularPointsTo", LitPat (Var (loc "verified/lib.rs(203,53-59)", "mu_all")))));
  PureStmt (loc "verified/lib.rs(204,19-25)", Assert (loc "verified/lib.rs(204,19-25)", CallExpr (loc "verified/lib.rs(204,26-33)", "foreach", [], [], [
    LitPat (Var (loc "verified/lib.rs(204,34-40)", "mu_all"));
    LitPat (CallExpr (loc "verified/lib.rs(204,73-74)", "own", [
      ConstructedTypeExpr (loc "verified/lib.rs(204,48-69)", "std::mem::MaybeUninit", [IdentTypeExpr (loc "verified/lib.rs(204,70-71)", None, "T")])
    ], [], [LitPat (Var (loc "verified/lib.rs(204,74-75)", "t"))], Static))
  ], Static)));
  PureStmt (loc "verified/lib.rs(205,19-25)", Assert (loc "verified/lib.rs(205,19-25)", PointsTo (loc "verified/lib.rs(205,35-38)", Deref (loc "verified/lib.rs(205,26-27)", Var (loc "verified/lib.rs(205,27-34)", "is_less")), "RegularPointsTo", VarPat (loc "verified/lib.rs(205,40-52)", "less_current"))));
  PureStmt (loc "verified/lib.rs(206,19-25)", Assert (loc "verified/lib.rs(206,19-25)", ExprCallExpr (loc "verified/lib.rs(206,33-34)", TypePredExpr (loc "verified/lib.rs(206,29-30)", IdentTypeExpr (loc "verified/lib.rs(206,27-28)", None, "F"), "own"), [LitPat (Var (loc "verified/lib.rs(206,34-35)", "t")); LitPat (Var (loc "verified/lib.rs(206,37-49)", "less_current"))])));
  PureStmt (loc "verified/lib.rs(207,19-23)", Leak (loc "verified/lib.rs(207,19-23)", CallExpr (loc "verified/lib.rs(207,40-41)", "type_interp", [IdentTypeExpr (loc "verified/lib.rs(207,38-39)", None, "T")], [], [], Static)));
  PureStmt (loc "verified/lib.rs(208,19-23)", Leak (loc "verified/lib.rs(208,19-23)", CallExpr (loc "verified/lib.rs(208,40-41)", "type_interp", [IdentTypeExpr (loc "verified/lib.rs(208,38-39)", None, "F")], [], [], Static)));
  Assert (loc "verified/lib.rs(210,22-93)", False (loc "verified/lib.rs(210,22-93)"));
  ReturnStmt (loc "verified/lib.rs(210,22-93)", Some (CallExpr (loc "verified/lib.rs(210,22-93)", "unwinding", [], [], [], Static)));
  LabelStmt (loc "verified/lib.rs(228,2)", "62");
  GotoStmt (loc "verified/lib.rs(228,2)", "63");
  LabelStmt (loc "verified/lib.rs(228,2)", "3");
  GotoStmt (loc "verified/lib.rs(228,2)", "63");
  LabelStmt (loc "verified/lib.rs(228,2)", "63");
  ReturnStmt (loc "verified/lib.rs(228,2)", Some (CallExpr (loc "verified/lib.rs(228,2)", "returning", [], [], [LitPat (Var (loc "verified/lib.rs(228,2)", "$_0"))], Static)))
], loc "verified/lib.rs(228,1-2)")), false, [])