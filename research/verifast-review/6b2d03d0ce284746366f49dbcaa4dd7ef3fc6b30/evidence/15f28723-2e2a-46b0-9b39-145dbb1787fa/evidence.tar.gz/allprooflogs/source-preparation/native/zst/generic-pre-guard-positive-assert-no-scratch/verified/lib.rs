#![allow(dead_code, unused_variables)]
fn small_sort_general_with_scratch<T>(v: &mut [T]) {
    //@ assert std::mem::size_of::<T>() > 0;
    let n = v.len();
    if std::mem::size_of::<T>() == 0 { return; }
    if n >= 8 { //@ assert n >= 8;
    }
}
