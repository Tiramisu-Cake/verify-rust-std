// DRAFT / NOT_RUN. A source-linked internal bounded entry, not the std caller.
// The checked helper definitions below are copied without changed contracts from
// overnight-sort4/capture.py and overnight-callback/{callback-cases.rs,
// join-four-owned-cells.rs}; see C1-CANDIDATE-CARD.md for their exact identities.
#![feature(freeze, rustc_attrs, core_intrinsics)]
#![allow(internal_features, dead_code, unused_variables)]

use std::marker::Freeze;
use std::mem::{size_of, MaybeUninit};

#[unsafe(rustc_allow_lifetime_dependent_specialization)]
pub(crate) trait FreezeMarker {}
impl<T: Freeze> FreezeMarker for T {}



// This function keeps the automatic safe-reference contract. The size guard
// bounds only this internal diagnostic and is not credited to the real caller.
fn small_sort_general_with_scratch<T: FreezeMarker, F: FnMut(&T, &T) -> bool>(
    v: &mut [T],
    scratch: &mut [MaybeUninit<T>],
    is_less: &mut F,
) {
    let len = v.len();
    if size_of::<T>() == 0 {
        return;
    }

    // slice/mod.rs:778, the exact implementation expression of as_mut_ptr.
    // It does not establish binding of the external method call in SmallSort.
    let v_base = v as *mut [T] as *mut T;

    if len >= 8 {
        unsafe {
            let c1 = is_less(&*v_base.add(1), &*v_base);
        }
    }
}
