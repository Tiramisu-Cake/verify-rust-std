#![allow(dead_code, unused_variables)]
use std::mem::MaybeUninit;
fn small_sort_general_with_scratch(v: &mut [()], scratch: &mut [MaybeUninit<()>]) {
    //@ assert false;
}
