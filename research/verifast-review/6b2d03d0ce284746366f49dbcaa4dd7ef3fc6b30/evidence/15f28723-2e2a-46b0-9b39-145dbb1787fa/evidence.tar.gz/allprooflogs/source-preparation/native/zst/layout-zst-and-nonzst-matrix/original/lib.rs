#![allow(dead_code, unused_variables)]
struct Empty;
#[repr(C)] struct EmptyC;
fn main() {
}
