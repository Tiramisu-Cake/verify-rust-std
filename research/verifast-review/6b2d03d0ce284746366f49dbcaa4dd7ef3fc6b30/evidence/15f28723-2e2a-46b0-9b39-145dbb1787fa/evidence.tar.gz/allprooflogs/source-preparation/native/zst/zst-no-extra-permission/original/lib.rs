#![allow(dead_code, unused_variables)]
use std::mem::MaybeUninit;
fn no_permission(v: &mut [()], scratch: &mut [MaybeUninit<()>], p: *mut ()) {
}
