// `slice::as_mut_ptr` returns the data pointer without consuming the elements
// or their ownership. The generated in-out contract requires both on return.
fn read_first(s: &mut [u8]) -> u8 {
    let p = s.as_mut_ptr();
    //@ assert p == s as *mut [u8] as *mut u8;
    if s.len() == 0 {
        return 0;
    }
    //@ open array(p, ?n, ?bs);
    let b = unsafe { *p };
    //@ close array(p, n, bs);
    b
}

// The data pointer is returned even when there is no element to dereference.
fn empty(s: &mut [u8]) {
    if s.len() == 0 {
        let p = s.as_mut_ptr();
        //@ assert p == s as *mut [u8] as *mut u8;
    }
}

// The pointer retains the MaybeUninit element type and the in-out resources.
fn maybe_uninit(s: &mut [std::mem::MaybeUninit<u8>]) {
    let p = s.as_mut_ptr();
    //@ assert p == s as *mut [std::mem::MaybeUninit<u8>] as *mut std::mem::MaybeUninit<u8>;
}
