pub unsafe fn forget_false_normal_post<T>(t: T)



{
    let _ = std::mem::ManuallyDrop::new(t);
}
