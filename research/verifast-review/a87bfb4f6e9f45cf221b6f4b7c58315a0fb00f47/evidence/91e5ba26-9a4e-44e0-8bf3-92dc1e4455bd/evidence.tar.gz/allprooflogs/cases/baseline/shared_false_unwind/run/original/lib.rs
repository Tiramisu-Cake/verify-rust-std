pub unsafe fn new(b: bool)



{
    if b {
        panic!("ManuallyDrop CFG regression");
    }
}

pub unsafe fn shared_cleanup_false_unwind_post<T>(t: T, b: bool)



{
    let _ = std::mem::ManuallyDrop::new(t);
    new(b);
}
