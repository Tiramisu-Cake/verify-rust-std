pub unsafe fn forget<T>(t: T)



{
    let _ = std::mem::ManuallyDrop::new(t);
}
