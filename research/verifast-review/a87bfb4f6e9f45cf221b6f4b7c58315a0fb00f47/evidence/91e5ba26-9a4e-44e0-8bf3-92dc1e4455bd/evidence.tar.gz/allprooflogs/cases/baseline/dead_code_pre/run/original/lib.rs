pub unsafe fn forget_from_dead_precondition<T>(t: T)



{
    let _ = std::mem::ManuallyDrop::new(t);
}
