pub unsafe fn new(b: bool)



{
    if b {
        panic!("ManuallyDrop CFG regression");
    }
}

pub unsafe fn ordinary_caller(b: bool)



{
    new(b);
}

pub unsafe fn shared_cleanup<T>(t: T, b: bool)



{
    let _ = std::mem::ManuallyDrop::new(t);
    new(b);
}
