#![feature(freeze, rustc_attrs, core_intrinsics)]
#![allow(internal_features, dead_code, unused_variables, unreachable_code)]
use core::intrinsics;
use std::marker::Freeze;
use std::mem::{size_of, MaybeUninit};
#[unsafe(rustc_allow_lifetime_dependent_specialization)]
pub(crate) trait FreezeMarker {}
impl<T: Freeze> FreezeMarker for T {}

fn native_slice_pointer_consumer<T>(v: &mut [T], scratch: &mut [MaybeUninit<T>]) {
    let v_base = v.as_mut_ptr();
    let scratch_base = scratch.as_mut_ptr() as *mut T;
    //@ let source_base = strip_pointer_metadata(v as pointer) as *T;
    //@ let mu_base = strip_pointer_metadata(scratch as pointer) as *std::mem::MaybeUninit<T>;
    //@ assert v_base == source_base;
    //@ assert scratch_base == strip_pointer_metadata(scratch as pointer) as *mut T;
    //@ assert source_base[..ptr_len(v)] |-> ?source_current;
    //@ assert foreach(source_current, own::<T>(currentThread));
    //@ assert mu_base[..ptr_len(scratch)] |-> ?mu_current;
    //@ assert foreach(mu_current, own::<std::mem::MaybeUninit<T>>(currentThread));
}
