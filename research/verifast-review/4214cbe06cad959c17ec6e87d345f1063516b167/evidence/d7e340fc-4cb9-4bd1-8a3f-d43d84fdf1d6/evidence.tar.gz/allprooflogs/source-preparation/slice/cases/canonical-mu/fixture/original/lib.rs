#![feature(freeze, rustc_attrs, core_intrinsics)]
#![allow(internal_features, dead_code, unused_variables, unreachable_code)]
use core::intrinsics;
use std::marker::Freeze;
use std::mem::{size_of, MaybeUninit};
#[unsafe(rustc_allow_lifetime_dependent_specialization)]
pub(crate) trait FreezeMarker {}
impl<T: Freeze> FreezeMarker for T {}

fn canonical_slice_as_mut_ptr_mu<T>(slice: &mut [MaybeUninit<T>]) -> *mut MaybeUninit<T> {
    slice as *mut [MaybeUninit<T>] as *mut MaybeUninit<T>
}
