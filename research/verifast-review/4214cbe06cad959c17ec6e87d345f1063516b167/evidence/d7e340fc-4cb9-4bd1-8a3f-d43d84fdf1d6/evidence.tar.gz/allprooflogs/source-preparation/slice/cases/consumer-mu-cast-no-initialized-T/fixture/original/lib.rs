#![feature(freeze, rustc_attrs, core_intrinsics)]
#![allow(internal_features, dead_code, unused_variables, unreachable_code)]
use core::intrinsics;
use std::marker::Freeze;
use std::mem::{size_of, MaybeUninit};
#[unsafe(rustc_allow_lifetime_dependent_specialization)]
pub(crate) trait FreezeMarker {}
impl<T: Freeze> FreezeMarker for T {}

fn native_slice_pointer_consumer<T>(v: &mut [T], scratch: &mut [MaybeUninit<T>]) {
    let _v_base = v.as_mut_ptr();
    let scratch_base = scratch.as_mut_ptr() as *mut T;
    if scratch.len() >= 1 {
    }
}
