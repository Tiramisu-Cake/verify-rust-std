[
  PackageDecl (loc "<dummy location>", "", [], [
    Func (loc "verified/lib.rs(10,1-16,2)", Regular, [("T", (true)); ("'__18", (false)); ("'__19", (false))], Some (ConstructedTypeExpr (loc "verified/lib.rs(10,100)", "fn_outcome", [ManifestTypeExpr (loc "verified/lib.rs(10,100)", StructType ("std_tuple_0_", []))])), "native_slice_pointer_consumer", [
      (ConstTypeExpr (loc "verified/lib.rs(10,37-38)", RustRefTypeExpr (loc "verified/lib.rs(10,37-38)", IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "'__18"), Mutable, SliceTypeExpr (loc "verified/lib.rs(10,37-38)", IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")))), "v");
      (ConstTypeExpr (loc "verified/lib.rs(10,50-57)", RustRefTypeExpr (loc "verified/lib.rs(10,50-57)", IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "'__19"), Mutable, SliceTypeExpr (loc "verified/lib.rs(10,50-57)", StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])))), "scratch");
      (ConstTypeExpr (loc "verified/lib.rs(10,82-91)", PtrTypeExpr (loc "verified/lib.rs(10,82-91)", IdentTypeExpr (loc "verified/lib.rs(10,82-91)", None, "T"))), "unrelated")
    ], false, (None, None), Some ((Sep (loc "verified/lib.rs(10,1-100)", Sep (loc "verified/lib.rs(10,1-100)", CallExpr (loc "verified/lib.rs(10,1-100)", "thread_token", [], [], [VarPat (loc "verified/lib.rs(10,1-100)", "_t")], Static), Operation (loc "verified/lib.rs(10,1-100)", Eq, [Var (loc "verified/lib.rs(10,1-100)", "_t"); Var (loc "verified/lib.rs(10,1-100)", "currentThread")])), Sep (loc "verified/lib.rs(10,37-38)", Sep (loc "verified/lib.rs(10,37-38)", CallExpr (loc "verified/lib.rs(10,37-38)", "array", [IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")], [], [
      LitPat (CastExpr (loc "verified/lib.rs(10,37-38)", PtrTypeExpr (loc "verified/lib.rs(10,37-38)", IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")), CallExpr (loc "verified/lib.rs(10,37-38)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(10,37-38)", ManifestTypeExpr (loc "verified/lib.rs(10,37-38)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(10,37-38)", "v")))], Static)));
      LitPat (CallExpr (loc "verified/lib.rs(10,37-38)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(10,37-38)", "v"))], Static));
      VarPat (loc "verified/lib.rs(10,37-38)", "_v0_v")
    ], Static), CallExpr (loc "verified/lib.rs(10,37-38)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(10,37-38)", "_v0_v"));
      LitPat (CallExpr (loc "verified/lib.rs(10,37-38)", "own", [IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(10,37-38)", "_t"))], Static))
    ], Static)), Sep (loc "verified/lib.rs(10,50-57)", Sep (loc "verified/lib.rs(10,50-57)", CallExpr (loc "verified/lib.rs(10,50-57)", "array", [
      StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])
    ], [], [
      LitPat (CastExpr (loc "verified/lib.rs(10,50-57)", PtrTypeExpr (loc "verified/lib.rs(10,50-57)", StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])), CallExpr (loc "verified/lib.rs(10,50-57)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(10,50-57)", ManifestTypeExpr (loc "verified/lib.rs(10,50-57)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(10,50-57)", "scratch")))], Static)));
      LitPat (CallExpr (loc "verified/lib.rs(10,50-57)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(10,50-57)", "scratch"))], Static));
      VarPat (loc "verified/lib.rs(10,50-57)", "_v0_scratch")
    ], Static), CallExpr (loc "verified/lib.rs(10,50-57)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(10,50-57)", "_v0_scratch"));
      LitPat (CallExpr (loc "verified/lib.rs(10,50-57)", "own", [
        StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])
      ], [], [LitPat (Var (loc "verified/lib.rs(10,50-57)", "_t"))], Static))
    ], Static)), Sep (loc "verified/lib.rs(10,1-100)", CoefAsn (loc "verified/lib.rs(10,1-100)", VarPat (loc "verified/lib.rs(10,1-100)", "_q___18"), CallExpr (loc "verified/lib.rs(10,1-100)", "lifetime_token", [], [], [
      LitPat (CallExpr (loc "verified/lib.rs(10,1-100)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(10,1-100)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(10,1-100)", None, "'__18"))))], Static))
    ], Static)), CoefAsn (loc "verified/lib.rs(10,1-100)", VarPat (loc "verified/lib.rs(10,1-100)", "_q___19"), CallExpr (loc "verified/lib.rs(10,1-100)", "lifetime_token", [], [], [
      LitPat (CallExpr (loc "verified/lib.rs(10,1-100)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(10,1-100)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(10,1-100)", None, "'__19"))))], Static))
    ], Static)))))), ("outcome", SwitchExpr (loc "verified/lib.rs(10,1-100)", Var (loc "verified/lib.rs(10,1-100)", "outcome"), [
      SwitchExprClause (loc "verified/lib.rs(10,1-100)", "returning", ["result"], Sep (loc "verified/lib.rs(10,1-100)", CallExpr (loc "verified/lib.rs(10,1-100)", "thread_token", [], [], [LitPat (Var (loc "verified/lib.rs(10,1-100)", "_t"))], Static), Sep (loc "verified/lib.rs(10,1-100)", CoefAsn (loc "verified/lib.rs(10,1-100)", LitPat (Var (loc "verified/lib.rs(10,1-100)", "_q___18")), CallExpr (loc "verified/lib.rs(10,1-100)", "lifetime_token", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(10,1-100)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(10,1-100)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(10,1-100)", None, "'__18"))))], Static))
      ], Static)), Sep (loc "verified/lib.rs(10,1-100)", CoefAsn (loc "verified/lib.rs(10,1-100)", LitPat (Var (loc "verified/lib.rs(10,1-100)", "_q___19")), CallExpr (loc "verified/lib.rs(10,1-100)", "lifetime_token", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(10,1-100)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(10,1-100)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(10,1-100)", None, "'__19"))))], Static))
      ], Static)), Sep (loc "verified/lib.rs(10,37-38)", Sep (loc "verified/lib.rs(10,37-38)", CallExpr (loc "verified/lib.rs(10,37-38)", "array", [IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")], [], [
        LitPat (CastExpr (loc "verified/lib.rs(10,37-38)", PtrTypeExpr (loc "verified/lib.rs(10,37-38)", IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")), CallExpr (loc "verified/lib.rs(10,37-38)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(10,37-38)", ManifestTypeExpr (loc "verified/lib.rs(10,37-38)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(10,37-38)", "v")))], Static)));
        LitPat (CallExpr (loc "verified/lib.rs(10,37-38)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(10,37-38)", "v"))], Static));
        VarPat (loc "verified/lib.rs(10,37-38)", "_v1_v")
      ], Static), CallExpr (loc "verified/lib.rs(10,37-38)", "foreach", [], [], [
        LitPat (Var (loc "verified/lib.rs(10,37-38)", "_v1_v"));
        LitPat (CallExpr (loc "verified/lib.rs(10,37-38)", "own", [IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(10,37-38)", "_t"))], Static))
      ], Static)), Sep (loc "verified/lib.rs(10,50-57)", Sep (loc "verified/lib.rs(10,50-57)", CallExpr (loc "verified/lib.rs(10,50-57)", "array", [
        StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])
      ], [], [
        LitPat (CastExpr (loc "verified/lib.rs(10,50-57)", PtrTypeExpr (loc "verified/lib.rs(10,50-57)", StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])), CallExpr (loc "verified/lib.rs(10,50-57)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(10,50-57)", ManifestTypeExpr (loc "verified/lib.rs(10,50-57)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(10,50-57)", "scratch")))], Static)));
        LitPat (CallExpr (loc "verified/lib.rs(10,50-57)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(10,50-57)", "scratch"))], Static));
        VarPat (loc "verified/lib.rs(10,50-57)", "_v1_scratch")
      ], Static), CallExpr (loc "verified/lib.rs(10,50-57)", "foreach", [], [], [
        LitPat (Var (loc "verified/lib.rs(10,50-57)", "_v1_scratch"));
        LitPat (CallExpr (loc "verified/lib.rs(10,50-57)", "own", [
          StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])
        ], [], [LitPat (Var (loc "verified/lib.rs(10,50-57)", "_t"))], Static))
      ], Static)), True (loc "verified/lib.rs(10,100)")))))));
      SwitchExprClause (loc "verified/lib.rs(10,1-100)", "unwinding", [], Sep (loc "verified/lib.rs(10,1-100)", CallExpr (loc "verified/lib.rs(10,1-100)", "thread_token", [], [], [LitPat (Var (loc "verified/lib.rs(10,1-100)", "_t"))], Static), Sep (loc "verified/lib.rs(10,1-100)", CoefAsn (loc "verified/lib.rs(10,1-100)", LitPat (Var (loc "verified/lib.rs(10,1-100)", "_q___18")), CallExpr (loc "verified/lib.rs(10,1-100)", "lifetime_token", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(10,1-100)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(10,1-100)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(10,1-100)", None, "'__18"))))], Static))
      ], Static)), Sep (loc "verified/lib.rs(10,1-100)", CoefAsn (loc "verified/lib.rs(10,1-100)", LitPat (Var (loc "verified/lib.rs(10,1-100)", "_q___19")), CallExpr (loc "verified/lib.rs(10,1-100)", "lifetime_token", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(10,1-100)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(10,1-100)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(10,1-100)", None, "'__19"))))], Static))
      ], Static)), Sep (loc "verified/lib.rs(10,37-38)", Sep (loc "verified/lib.rs(10,37-38)", CallExpr (loc "verified/lib.rs(10,37-38)", "array", [IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")], [], [
        LitPat (CastExpr (loc "verified/lib.rs(10,37-38)", PtrTypeExpr (loc "verified/lib.rs(10,37-38)", IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")), CallExpr (loc "verified/lib.rs(10,37-38)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(10,37-38)", ManifestTypeExpr (loc "verified/lib.rs(10,37-38)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(10,37-38)", "v")))], Static)));
        LitPat (CallExpr (loc "verified/lib.rs(10,37-38)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(10,37-38)", "v"))], Static));
        VarPat (loc "verified/lib.rs(10,37-38)", "_v1_v")
      ], Static), CallExpr (loc "verified/lib.rs(10,37-38)", "foreach", [], [], [
        LitPat (Var (loc "verified/lib.rs(10,37-38)", "_v1_v"));
        LitPat (CallExpr (loc "verified/lib.rs(10,37-38)", "own", [IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(10,37-38)", "_t"))], Static))
      ], Static)), Sep (loc "verified/lib.rs(10,50-57)", Sep (loc "verified/lib.rs(10,50-57)", CallExpr (loc "verified/lib.rs(10,50-57)", "array", [
        StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])
      ], [], [
        LitPat (CastExpr (loc "verified/lib.rs(10,50-57)", PtrTypeExpr (loc "verified/lib.rs(10,50-57)", StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])), CallExpr (loc "verified/lib.rs(10,50-57)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(10,50-57)", ManifestTypeExpr (loc "verified/lib.rs(10,50-57)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(10,50-57)", "scratch")))], Static)));
        LitPat (CallExpr (loc "verified/lib.rs(10,50-57)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(10,50-57)", "scratch"))], Static));
        VarPat (loc "verified/lib.rs(10,50-57)", "_v1_scratch")
      ], Static), CallExpr (loc "verified/lib.rs(10,50-57)", "foreach", [], [], [
        LitPat (Var (loc "verified/lib.rs(10,50-57)", "_v1_scratch"));
        LitPat (CallExpr (loc "verified/lib.rs(10,50-57)", "own", [
          StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])
        ], [], [LitPat (Var (loc "verified/lib.rs(10,50-57)", "_t"))], Static))
      ], Static)), EmpAsn (loc "verified/lib.rs(10,1-100)")))))))
    ], None)))), false, Some (([
      DeclStmt (loc "verified/lib.rs(10,1-16,2)", [(loc "verified/lib.rs(10,1-16,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(10,100)", StructType ("std_tuple_0_", []))), "$_0", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(10,1-16,2)", [(loc "verified/lib.rs(10,1-16,2)", Some (ConstTypeExpr (loc "verified/lib.rs(10,1-16,2)", PtrTypeExpr (loc "verified/lib.rs(11,9-15)", IdentTypeExpr (loc "verified/lib.rs(11,9-15)", None, "T")))), "v_base", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(10,1-16,2)", [(loc "verified/lib.rs(10,1-16,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(11,18-19)", InferredTypeExpr (loc "verified/lib.rs(11,18-19)"), Mutable, SliceTypeExpr (loc "verified/lib.rs(11,18-19)", IdentTypeExpr (loc "verified/lib.rs(11,18-19)", None, "T")))), "$_5", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(10,1-16,2)", [
        (loc "verified/lib.rs(10,1-16,2)", Some (ConstTypeExpr (loc "verified/lib.rs(10,1-16,2)", PtrTypeExpr (loc "verified/lib.rs(12,9-22)", StructTypeExpr (loc "verified/lib.rs(12,9-22)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(12,9-22)", None, "T")])))), "_scratch_base", None, (ref (false), ref (None)))
      ]);
      DeclStmt (loc "verified/lib.rs(10,1-16,2)", [
        (loc "verified/lib.rs(10,1-16,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(12,25-32)", InferredTypeExpr (loc "verified/lib.rs(12,25-32)"), Mutable, SliceTypeExpr (loc "verified/lib.rs(12,25-32)", StructTypeExpr (loc "verified/lib.rs(12,25-32)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(12,25-32)", None, "T")])))), "$_7", None, (ref (false), ref (None)))
      ]);
      DeclStmt (loc "verified/lib.rs(10,1-16,2)", [(loc "verified/lib.rs(10,1-16,2)", Some (ConstTypeExpr (loc "verified/lib.rs(10,1-16,2)", ManifestTypeExpr (loc "verified/lib.rs(13,5-36)", StructType ("std_tuple_0_", [])))), "$_8", None, (ref (false), ref (None)))]);
      LabelStmt (loc "verified/lib.rs(11,18-19)", "0");
      ExprStmt (AssignExpr (loc "verified/lib.rs(11,18-19)", Var (loc "verified/lib.rs(11,18-19)", "$_5"), Mutation, AddressOf (loc "verified/lib.rs(11,18-19)", Deref (loc "verified/lib.rs(11,18-19)", Var (loc "verified/lib.rs(11,18-19)", "v")))));
      ExprStmt (AssignExpr (loc "verified/lib.rs(11,18-32)", Var (loc "verified/lib.rs(11,18-32)", "v_base"), Initialization, CastExpr (loc "verified/lib.rs(11,20-32)", PtrTypeExpr (loc "verified/lib.rs(11,20-32)", IdentTypeExpr (loc "verified/lib.rs(11,18-32)", None, "T")), Var (loc "verified/lib.rs(11,20-32)", "$_5"))));
      ExprStmt (AssignExpr (loc "verified/lib.rs(12,25-32)", Var (loc "verified/lib.rs(12,25-32)", "$_7"), Mutation, AddressOf (loc "verified/lib.rs(12,25-32)", Deref (loc "verified/lib.rs(12,25-32)", Var (loc "verified/lib.rs(12,25-32)", "scratch")))));
      ExprStmt (AssignExpr (loc "verified/lib.rs(12,25-45)", Var (loc "verified/lib.rs(12,25-45)", "_scratch_base"), Initialization, CastExpr (loc "verified/lib.rs(12,33-45)", PtrTypeExpr (loc "verified/lib.rs(12,33-45)", StructTypeExpr (loc "verified/lib.rs(12,25-45)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(12,25-45)", None, "T")])), Var (loc "verified/lib.rs(12,33-45)", "$_7"))));
      PureStmt (loc "verified/lib.rs(13,5-15,14)", IfStmt (loc "verified/lib.rs(13,9-11)", Operation (loc "verified/lib.rs(13,23-25)", Neq, [Var (loc "verified/lib.rs(13,13-22)", "unrelated"); Var (loc "verified/lib.rs(13,26-32)", "v_base")]), [
        BlockStmt (loc "verified/lib.rs(13,34-35)", [], [Assert (loc "verified/lib.rs(14,13-19)", PointsTo (loc "verified/lib.rs(14,35-38)", ReadArray (loc "verified/lib.rs(14,29-30)", Var (loc "verified/lib.rs(14,20-29)", "unrelated"), SliceExpr (loc "verified/lib.rs(14,30-32)", None, Some (LitPat (IntLit (loc "verified/lib.rs(14,32-33)", big_int_of_string "1", true, false, NoLSuffix))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(14,40-56)", "unrelated_values")))], loc "verified/lib.rs(15,9-10)", ref ([]))
      ], []));
      ReturnStmt (loc "verified/lib.rs(16,2)", Some (CallExpr (loc "verified/lib.rs(16,2)", "returning", [], [], [LitPat (Var (loc "verified/lib.rs(16,2)", "$_0"))], Static)))
    ], loc "verified/lib.rs(16,1-2)")), false, [])
  ])
]