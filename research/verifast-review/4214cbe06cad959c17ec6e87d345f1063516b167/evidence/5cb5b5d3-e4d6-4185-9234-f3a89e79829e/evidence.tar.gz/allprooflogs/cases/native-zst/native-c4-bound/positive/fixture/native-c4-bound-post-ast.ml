Func (loc "verified/lib.rs(316,1-579,2)", Regular, [("T", (true)); ("F", (true)); ("'__20", (false)); ("'__21", (false)); ("'__22", (false))], Some (ConstructedTypeExpr (loc "verified/lib.rs(320,2)", "fn_outcome", [ManifestTypeExpr (loc "verified/lib.rs(320,2)", StructType ("std_tuple_0_", []))])), "small_sort_general_with_scratch", [
  (ConstTypeExpr (loc "verified/lib.rs(317,5-6)", RustRefTypeExpr (loc "verified/lib.rs(317,5-6)", IdentTypeExpr (loc "verified/lib.rs(317,5-6)", None, "'__20"), Mutable, SliceTypeExpr (loc "verified/lib.rs(317,5-6)", IdentTypeExpr (loc "verified/lib.rs(317,5-6)", None, "T")))), "v");
  (ConstTypeExpr (loc "verified/lib.rs(318,5-12)", RustRefTypeExpr (loc "verified/lib.rs(318,5-12)", IdentTypeExpr (loc "verified/lib.rs(318,5-12)", None, "'__21"), Mutable, SliceTypeExpr (loc "verified/lib.rs(318,5-12)", StructTypeExpr (loc "verified/lib.rs(318,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(318,5-12)", None, "T")])))), "scratch");
  (ConstTypeExpr (loc "verified/lib.rs(319,5-12)", RustRefTypeExpr (loc "verified/lib.rs(319,5-12)", IdentTypeExpr (loc "verified/lib.rs(319,5-12)", None, "'__22"), Mutable, IdentTypeExpr (loc "verified/lib.rs(319,5-12)", None, "F"))), "is_less")
], false, (None, None), Some ((Sep (loc "verified/lib.rs(316,1-320,2)", Sep (loc "verified/lib.rs(316,1-320,2)", CallExpr (loc "verified/lib.rs(316,1-320,2)", "thread_token", [], [], [VarPat (loc "verified/lib.rs(316,1-320,2)", "_t")], Static), Operation (loc "verified/lib.rs(316,1-320,2)", Eq, [Var (loc "verified/lib.rs(316,1-320,2)", "_t"); Var (loc "verified/lib.rs(316,1-320,2)", "currentThread")])), Sep (loc "verified/lib.rs(317,5-6)", Sep (loc "verified/lib.rs(317,5-6)", CallExpr (loc "verified/lib.rs(317,5-6)", "array", [IdentTypeExpr (loc "verified/lib.rs(317,5-6)", None, "T")], [], [
  LitPat (CastExpr (loc "verified/lib.rs(317,5-6)", PtrTypeExpr (loc "verified/lib.rs(317,5-6)", IdentTypeExpr (loc "verified/lib.rs(317,5-6)", None, "T")), CallExpr (loc "verified/lib.rs(317,5-6)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(317,5-6)", ManifestTypeExpr (loc "verified/lib.rs(317,5-6)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(317,5-6)", "v")))], Static)));
  LitPat (CallExpr (loc "verified/lib.rs(317,5-6)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(317,5-6)", "v"))], Static));
  VarPat (loc "verified/lib.rs(317,5-6)", "_v0_v")
], Static), CallExpr (loc "verified/lib.rs(317,5-6)", "foreach", [], [], [
  LitPat (Var (loc "verified/lib.rs(317,5-6)", "_v0_v"));
  LitPat (CallExpr (loc "verified/lib.rs(317,5-6)", "own", [IdentTypeExpr (loc "verified/lib.rs(317,5-6)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(317,5-6)", "_t"))], Static))
], Static)), Sep (loc "verified/lib.rs(318,5-12)", Sep (loc "verified/lib.rs(318,5-12)", CallExpr (loc "verified/lib.rs(318,5-12)", "array", [
  StructTypeExpr (loc "verified/lib.rs(318,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(318,5-12)", None, "T")])
], [], [
  LitPat (CastExpr (loc "verified/lib.rs(318,5-12)", PtrTypeExpr (loc "verified/lib.rs(318,5-12)", StructTypeExpr (loc "verified/lib.rs(318,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(318,5-12)", None, "T")])), CallExpr (loc "verified/lib.rs(318,5-12)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(318,5-12)", ManifestTypeExpr (loc "verified/lib.rs(318,5-12)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(318,5-12)", "scratch")))], Static)));
  LitPat (CallExpr (loc "verified/lib.rs(318,5-12)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(318,5-12)", "scratch"))], Static));
  VarPat (loc "verified/lib.rs(318,5-12)", "_v0_scratch")
], Static), CallExpr (loc "verified/lib.rs(318,5-12)", "foreach", [], [], [
  LitPat (Var (loc "verified/lib.rs(318,5-12)", "_v0_scratch"));
  LitPat (CallExpr (loc "verified/lib.rs(318,5-12)", "own", [
    StructTypeExpr (loc "verified/lib.rs(318,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(318,5-12)", None, "T")])
  ], [], [LitPat (Var (loc "verified/lib.rs(318,5-12)", "_t"))], Static))
], Static)), Sep (loc "verified/lib.rs(319,5-12)", Sep (loc "verified/lib.rs(319,5-12)", PointsTo (loc "verified/lib.rs(319,5-12)", Deref (loc "verified/lib.rs(319,5-12)", Var (loc "verified/lib.rs(319,5-12)", "is_less")), "RegularPointsTo", VarPat (loc "verified/lib.rs(319,5-12)", "_v0_is_less")), ExprCallExpr (loc "verified/lib.rs(319,5-12)", TypePredExpr (loc "verified/lib.rs(319,5-12)", IdentTypeExpr (loc "verified/lib.rs(319,5-12)", None, "F"), "own"), [LitPat (Var (loc "verified/lib.rs(319,5-12)", "_t")); LitPat (Var (loc "verified/lib.rs(319,5-12)", "_v0_is_less"))])), Sep (loc "verified/lib.rs(316,1-320,2)", CoefAsn (loc "verified/lib.rs(316,1-320,2)", VarPat (loc "verified/lib.rs(316,1-320,2)", "_q___20"), CallExpr (loc "verified/lib.rs(316,1-320,2)", "lifetime_token", [], [], [
  LitPat (CallExpr (loc "verified/lib.rs(316,1-320,2)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(316,1-320,2)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(316,1-320,2)", None, "'__20"))))], Static))
], Static)), Sep (loc "verified/lib.rs(316,1-320,2)", CoefAsn (loc "verified/lib.rs(316,1-320,2)", VarPat (loc "verified/lib.rs(316,1-320,2)", "_q___21"), CallExpr (loc "verified/lib.rs(316,1-320,2)", "lifetime_token", [], [], [
  LitPat (CallExpr (loc "verified/lib.rs(316,1-320,2)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(316,1-320,2)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(316,1-320,2)", None, "'__21"))))], Static))
], Static)), CoefAsn (loc "verified/lib.rs(316,1-320,2)", VarPat (loc "verified/lib.rs(316,1-320,2)", "_q___22"), CallExpr (loc "verified/lib.rs(316,1-320,2)", "lifetime_token", [], [], [
  LitPat (CallExpr (loc "verified/lib.rs(316,1-320,2)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(316,1-320,2)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(316,1-320,2)", None, "'__22"))))], Static))
], Static)))))))), ("outcome", SwitchExpr (loc "verified/lib.rs(316,1-320,2)", Var (loc "verified/lib.rs(316,1-320,2)", "outcome"), [
  SwitchExprClause (loc "verified/lib.rs(316,1-320,2)", "returning", ["result"], Sep (loc "verified/lib.rs(316,1-320,2)", CallExpr (loc "verified/lib.rs(316,1-320,2)", "thread_token", [], [], [LitPat (Var (loc "verified/lib.rs(316,1-320,2)", "_t"))], Static), Sep (loc "verified/lib.rs(316,1-320,2)", CoefAsn (loc "verified/lib.rs(316,1-320,2)", LitPat (Var (loc "verified/lib.rs(316,1-320,2)", "_q___20")), CallExpr (loc "verified/lib.rs(316,1-320,2)", "lifetime_token", [], [], [
    LitPat (CallExpr (loc "verified/lib.rs(316,1-320,2)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(316,1-320,2)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(316,1-320,2)", None, "'__20"))))], Static))
  ], Static)), Sep (loc "verified/lib.rs(316,1-320,2)", CoefAsn (loc "verified/lib.rs(316,1-320,2)", LitPat (Var (loc "verified/lib.rs(316,1-320,2)", "_q___21")), CallExpr (loc "verified/lib.rs(316,1-320,2)", "lifetime_token", [], [], [
    LitPat (CallExpr (loc "verified/lib.rs(316,1-320,2)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(316,1-320,2)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(316,1-320,2)", None, "'__21"))))], Static))
  ], Static)), Sep (loc "verified/lib.rs(316,1-320,2)", CoefAsn (loc "verified/lib.rs(316,1-320,2)", LitPat (Var (loc "verified/lib.rs(316,1-320,2)", "_q___22")), CallExpr (loc "verified/lib.rs(316,1-320,2)", "lifetime_token", [], [], [
    LitPat (CallExpr (loc "verified/lib.rs(316,1-320,2)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(316,1-320,2)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(316,1-320,2)", None, "'__22"))))], Static))
  ], Static)), Sep (loc "verified/lib.rs(317,5-6)", Sep (loc "verified/lib.rs(317,5-6)", CallExpr (loc "verified/lib.rs(317,5-6)", "array", [IdentTypeExpr (loc "verified/lib.rs(317,5-6)", None, "T")], [], [
    LitPat (CastExpr (loc "verified/lib.rs(317,5-6)", PtrTypeExpr (loc "verified/lib.rs(317,5-6)", IdentTypeExpr (loc "verified/lib.rs(317,5-6)", None, "T")), CallExpr (loc "verified/lib.rs(317,5-6)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(317,5-6)", ManifestTypeExpr (loc "verified/lib.rs(317,5-6)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(317,5-6)", "v")))], Static)));
    LitPat (CallExpr (loc "verified/lib.rs(317,5-6)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(317,5-6)", "v"))], Static));
    VarPat (loc "verified/lib.rs(317,5-6)", "_v1_v")
  ], Static), CallExpr (loc "verified/lib.rs(317,5-6)", "foreach", [], [], [
    LitPat (Var (loc "verified/lib.rs(317,5-6)", "_v1_v"));
    LitPat (CallExpr (loc "verified/lib.rs(317,5-6)", "own", [IdentTypeExpr (loc "verified/lib.rs(317,5-6)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(317,5-6)", "_t"))], Static))
  ], Static)), Sep (loc "verified/lib.rs(318,5-12)", Sep (loc "verified/lib.rs(318,5-12)", CallExpr (loc "verified/lib.rs(318,5-12)", "array", [
    StructTypeExpr (loc "verified/lib.rs(318,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(318,5-12)", None, "T")])
  ], [], [
    LitPat (CastExpr (loc "verified/lib.rs(318,5-12)", PtrTypeExpr (loc "verified/lib.rs(318,5-12)", StructTypeExpr (loc "verified/lib.rs(318,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(318,5-12)", None, "T")])), CallExpr (loc "verified/lib.rs(318,5-12)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(318,5-12)", ManifestTypeExpr (loc "verified/lib.rs(318,5-12)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(318,5-12)", "scratch")))], Static)));
    LitPat (CallExpr (loc "verified/lib.rs(318,5-12)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(318,5-12)", "scratch"))], Static));
    VarPat (loc "verified/lib.rs(318,5-12)", "_v1_scratch")
  ], Static), CallExpr (loc "verified/lib.rs(318,5-12)", "foreach", [], [], [
    LitPat (Var (loc "verified/lib.rs(318,5-12)", "_v1_scratch"));
    LitPat (CallExpr (loc "verified/lib.rs(318,5-12)", "own", [
      StructTypeExpr (loc "verified/lib.rs(318,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(318,5-12)", None, "T")])
    ], [], [LitPat (Var (loc "verified/lib.rs(318,5-12)", "_t"))], Static))
  ], Static)), Sep (loc "verified/lib.rs(319,5-12)", Sep (loc "verified/lib.rs(319,5-12)", PointsTo (loc "verified/lib.rs(319,5-12)", Deref (loc "verified/lib.rs(319,5-12)", Var (loc "verified/lib.rs(319,5-12)", "is_less")), "RegularPointsTo", VarPat (loc "verified/lib.rs(319,5-12)", "_v1_is_less")), ExprCallExpr (loc "verified/lib.rs(319,5-12)", TypePredExpr (loc "verified/lib.rs(319,5-12)", IdentTypeExpr (loc "verified/lib.rs(319,5-12)", None, "F"), "own"), [LitPat (Var (loc "verified/lib.rs(319,5-12)", "_t")); LitPat (Var (loc "verified/lib.rs(319,5-12)", "_v1_is_less"))])), True (loc "verified/lib.rs(320,2)")))))))));
  SwitchExprClause (loc "verified/lib.rs(316,1-320,2)", "unwinding", [], Sep (loc "verified/lib.rs(316,1-320,2)", CallExpr (loc "verified/lib.rs(316,1-320,2)", "thread_token", [], [], [LitPat (Var (loc "verified/lib.rs(316,1-320,2)", "_t"))], Static), Sep (loc "verified/lib.rs(316,1-320,2)", CoefAsn (loc "verified/lib.rs(316,1-320,2)", LitPat (Var (loc "verified/lib.rs(316,1-320,2)", "_q___20")), CallExpr (loc "verified/lib.rs(316,1-320,2)", "lifetime_token", [], [], [
    LitPat (CallExpr (loc "verified/lib.rs(316,1-320,2)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(316,1-320,2)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(316,1-320,2)", None, "'__20"))))], Static))
  ], Static)), Sep (loc "verified/lib.rs(316,1-320,2)", CoefAsn (loc "verified/lib.rs(316,1-320,2)", LitPat (Var (loc "verified/lib.rs(316,1-320,2)", "_q___21")), CallExpr (loc "verified/lib.rs(316,1-320,2)", "lifetime_token", [], [], [
    LitPat (CallExpr (loc "verified/lib.rs(316,1-320,2)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(316,1-320,2)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(316,1-320,2)", None, "'__21"))))], Static))
  ], Static)), Sep (loc "verified/lib.rs(316,1-320,2)", CoefAsn (loc "verified/lib.rs(316,1-320,2)", LitPat (Var (loc "verified/lib.rs(316,1-320,2)", "_q___22")), CallExpr (loc "verified/lib.rs(316,1-320,2)", "lifetime_token", [], [], [
    LitPat (CallExpr (loc "verified/lib.rs(316,1-320,2)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(316,1-320,2)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(316,1-320,2)", None, "'__22"))))], Static))
  ], Static)), Sep (loc "verified/lib.rs(317,5-6)", Sep (loc "verified/lib.rs(317,5-6)", CallExpr (loc "verified/lib.rs(317,5-6)", "array", [IdentTypeExpr (loc "verified/lib.rs(317,5-6)", None, "T")], [], [
    LitPat (CastExpr (loc "verified/lib.rs(317,5-6)", PtrTypeExpr (loc "verified/lib.rs(317,5-6)", IdentTypeExpr (loc "verified/lib.rs(317,5-6)", None, "T")), CallExpr (loc "verified/lib.rs(317,5-6)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(317,5-6)", ManifestTypeExpr (loc "verified/lib.rs(317,5-6)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(317,5-6)", "v")))], Static)));
    LitPat (CallExpr (loc "verified/lib.rs(317,5-6)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(317,5-6)", "v"))], Static));
    VarPat (loc "verified/lib.rs(317,5-6)", "_v1_v")
  ], Static), CallExpr (loc "verified/lib.rs(317,5-6)", "foreach", [], [], [
    LitPat (Var (loc "verified/lib.rs(317,5-6)", "_v1_v"));
    LitPat (CallExpr (loc "verified/lib.rs(317,5-6)", "own", [IdentTypeExpr (loc "verified/lib.rs(317,5-6)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(317,5-6)", "_t"))], Static))
  ], Static)), Sep (loc "verified/lib.rs(318,5-12)", Sep (loc "verified/lib.rs(318,5-12)", CallExpr (loc "verified/lib.rs(318,5-12)", "array", [
    StructTypeExpr (loc "verified/lib.rs(318,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(318,5-12)", None, "T")])
  ], [], [
    LitPat (CastExpr (loc "verified/lib.rs(318,5-12)", PtrTypeExpr (loc "verified/lib.rs(318,5-12)", StructTypeExpr (loc "verified/lib.rs(318,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(318,5-12)", None, "T")])), CallExpr (loc "verified/lib.rs(318,5-12)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(318,5-12)", ManifestTypeExpr (loc "verified/lib.rs(318,5-12)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(318,5-12)", "scratch")))], Static)));
    LitPat (CallExpr (loc "verified/lib.rs(318,5-12)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(318,5-12)", "scratch"))], Static));
    VarPat (loc "verified/lib.rs(318,5-12)", "_v1_scratch")
  ], Static), CallExpr (loc "verified/lib.rs(318,5-12)", "foreach", [], [], [
    LitPat (Var (loc "verified/lib.rs(318,5-12)", "_v1_scratch"));
    LitPat (CallExpr (loc "verified/lib.rs(318,5-12)", "own", [
      StructTypeExpr (loc "verified/lib.rs(318,5-12)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(318,5-12)", None, "T")])
    ], [], [LitPat (Var (loc "verified/lib.rs(318,5-12)", "_t"))], Static))
  ], Static)), Sep (loc "verified/lib.rs(319,5-12)", Sep (loc "verified/lib.rs(319,5-12)", PointsTo (loc "verified/lib.rs(319,5-12)", Deref (loc "verified/lib.rs(319,5-12)", Var (loc "verified/lib.rs(319,5-12)", "is_less")), "RegularPointsTo", VarPat (loc "verified/lib.rs(319,5-12)", "_v1_is_less")), ExprCallExpr (loc "verified/lib.rs(319,5-12)", TypePredExpr (loc "verified/lib.rs(319,5-12)", IdentTypeExpr (loc "verified/lib.rs(319,5-12)", None, "F"), "own"), [LitPat (Var (loc "verified/lib.rs(319,5-12)", "_t")); LitPat (Var (loc "verified/lib.rs(319,5-12)", "_v1_is_less"))])), EmpAsn (loc "verified/lib.rs(316,1-320,2)")))))))))
], None)))), false, Some (([
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(320,2)", StructType ("std_tuple_0_", []))), "$_0", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(321,9-12)", Int (Unsigned, PtrRank)))), "len", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(321,15-16)", InferredTypeExpr (loc "verified/lib.rs(321,15-16)"), Shared, SliceTypeExpr (loc "verified/lib.rs(321,15-16)", IdentTypeExpr (loc "verified/lib.rs(321,15-16)", None, "T")))), "$_5", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(322,5-324,6)", StructType ("std_tuple_0_", [])))), "$_6", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(322,8-27)", Bool)), "$_7", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(322,8-22)", Int (Unsigned, PtrRank))), "$_8", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(322,28-324,6)", UnionType ("std_empty_"))), "$_9", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", PtrTypeExpr (loc "verified/lib.rs(328,9-15)", IdentTypeExpr (loc "verified/lib.rs(328,9-15)", None, "T")))), "v_base", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (PtrTypeExpr (loc "verified/lib.rs(328,18-41)", IdentTypeExpr (loc "verified/lib.rs(328,18-41)", None, "T"))), "$_11", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (PtrTypeExpr (loc "verified/lib.rs(328,18-31)", SliceTypeExpr (loc "verified/lib.rs(328,18-31)", IdentTypeExpr (loc "verified/lib.rs(328,18-31)", None, "T")))), "$_12", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (PtrTypeExpr (loc "verified/lib.rs(328,18-31)", SliceTypeExpr (loc "verified/lib.rs(328,18-31)", IdentTypeExpr (loc "verified/lib.rs(328,18-31)", None, "T")))), "$_13", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(330,8-16)", Bool)), "$_14", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(330,8-11)", Int (Unsigned, PtrRank))), "$_15", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(331,9-40)", StructType ("std_tuple_0_", [])))), "$_16", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(332,9-40)", StructType ("std_tuple_0_", [])))), "$_17", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(333,9-40)", StructType ("std_tuple_0_", [])))), "$_18", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(334,9-40)", StructType ("std_tuple_0_", [])))), "$_19", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(335,9-40)", StructType ("std_tuple_0_", [])))), "$_20", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(336,9-40)", StructType ("std_tuple_0_", [])))), "$_21", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(337,9-40)", StructType ("std_tuple_0_", [])))), "$_22", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(338,9-40)", StructType ("std_tuple_0_", [])))), "$_23", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(339,9-40)", StructType ("std_tuple_0_", [])))), "$_24", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(340,9-40)", StructType ("std_tuple_0_", [])))), "$_25", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(341,9-40)", StructType ("std_tuple_0_", [])))), "$_26", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(342,9-40)", StructType ("std_tuple_0_", [])))), "$_27", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(343,9-40)", StructType ("std_tuple_0_", [])))), "$_28", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(344,9-40)", StructType ("std_tuple_0_", [])))), "$_29", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(345,9-40)", StructType ("std_tuple_0_", [])))), "$_30", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(346,9-40)", StructType ("std_tuple_0_", [])))), "$_31", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(347,9-40)", StructType ("std_tuple_0_", [])))), "$_32", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(349,1-32)", StructType ("std_tuple_0_", [])))), "$_33", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(350,13-44)", StructType ("std_tuple_0_", [])))), "$_34", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(351,13-44)", StructType ("std_tuple_0_", [])))), "$_35", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(352,13-44)", StructType ("std_tuple_0_", [])))), "$_36", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(353,13-44)", StructType ("std_tuple_0_", [])))), "$_37", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(354,13-44)", StructType ("std_tuple_0_", [])))), "$_38", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(355,13-44)", StructType ("std_tuple_0_", [])))), "$_39", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(356,13-44)", StructType ("std_tuple_0_", [])))), "$_40", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(357,13-44)", StructType ("std_tuple_0_", [])))), "$_41", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(358,13-44)", StructType ("std_tuple_0_", [])))), "$_42", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(359,13-44)", StructType ("std_tuple_0_", [])))), "$_43", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(360,13-44)", StructType ("std_tuple_0_", [])))), "$_44", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(361,13-44)", StructType ("std_tuple_0_", [])))), "$_45", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(362,13-44)", StructType ("std_tuple_0_", [])))), "$_46", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(363,13-44)", StructType ("std_tuple_0_", [])))), "$_47", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(364,13-44)", StructType ("std_tuple_0_", [])))), "$_48", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(365,13-44)", StructType ("std_tuple_0_", [])))), "$_49", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(366,13-44)", StructType ("std_tuple_0_", [])))), "$_50", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(367,13-44)", StructType ("std_tuple_0_", [])))), "$_51", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(368,1-32)", StructType ("std_tuple_0_", [])))), "$_52", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(387,17-19)", Bool))), "c1", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(388,13-44)", StructType ("std_tuple_0_", [])))), "$_62", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(389,13-44)", StructType ("std_tuple_0_", [])))), "$_63", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(390,9-40)", StructType ("std_tuple_0_", [])))), "$_64", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(391,9-40)", StructType ("std_tuple_0_", [])))), "$_65", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(392,9-40)", StructType ("std_tuple_0_", [])))), "$_66", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(393,9-40)", StructType ("std_tuple_0_", [])))), "$_67", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(394,9-40)", StructType ("std_tuple_0_", [])))), "$_68", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(395,9-40)", StructType ("std_tuple_0_", [])))), "$_69", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(396,9-40)", StructType ("std_tuple_0_", [])))), "$_70", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(397,9-40)", StructType ("std_tuple_0_", [])))), "$_71", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(398,9-40)", StructType ("std_tuple_0_", [])))), "$_72", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(399,9-40)", StructType ("std_tuple_0_", [])))), "$_73", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(400,9-40)", StructType ("std_tuple_0_", [])))), "$_74", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(401,9-40)", StructType ("std_tuple_0_", [])))), "$_75", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(402,9-40)", StructType ("std_tuple_0_", [])))), "$_76", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(403,9-40)", StructType ("std_tuple_0_", [])))), "$_77", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(404,9-40)", StructType ("std_tuple_0_", [])))), "$_78", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(405,9-40)", StructType ("std_tuple_0_", [])))), "$_79", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(406,9-40)", StructType ("std_tuple_0_", [])))), "$_80", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(407,9-40)", StructType ("std_tuple_0_", [])))), "$_81", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(408,9-40)", StructType ("std_tuple_0_", [])))), "$_82", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(409,9-40)", StructType ("std_tuple_0_", [])))), "$_83", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(410,9-40)", StructType ("std_tuple_0_", [])))), "$_84", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(411,9-40)", StructType ("std_tuple_0_", [])))), "$_85", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(412,9-40)", StructType ("std_tuple_0_", [])))), "$_86", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(413,9-40)", StructType ("std_tuple_0_", [])))), "$_87", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(414,9-40)", StructType ("std_tuple_0_", [])))), "$_88", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(415,9-40)", StructType ("std_tuple_0_", [])))), "$_89", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(416,9-40)", StructType ("std_tuple_0_", [])))), "$_90", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(417,9-40)", StructType ("std_tuple_0_", [])))), "$_91", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(418,9-40)", StructType ("std_tuple_0_", [])))), "$_92", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(419,9-40)", StructType ("std_tuple_0_", [])))), "$_93", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(420,9-40)", StructType ("std_tuple_0_", [])))), "$_94", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(421,9-40)", StructType ("std_tuple_0_", [])))), "$_95", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(422,9-40)", StructType ("std_tuple_0_", [])))), "$_96", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(423,9-40)", StructType ("std_tuple_0_", [])))), "$_97", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(424,9-40)", StructType ("std_tuple_0_", [])))), "$_98", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(425,1-32)", StructType ("std_tuple_0_", [])))), "$_99", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(442,13-15)", Bool))), "c2", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(443,9-40)", StructType ("std_tuple_0_", [])))), "$_111", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(444,9-40)", StructType ("std_tuple_0_", [])))), "$_112", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(445,9-40)", StructType ("std_tuple_0_", [])))), "$_113", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(446,9-40)", StructType ("std_tuple_0_", [])))), "$_114", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(447,9-40)", StructType ("std_tuple_0_", [])))), "$_115", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(448,9-40)", StructType ("std_tuple_0_", [])))), "$_116", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(449,9-40)", StructType ("std_tuple_0_", [])))), "$_117", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(450,9-40)", StructType ("std_tuple_0_", [])))), "$_118", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(451,9-40)", StructType ("std_tuple_0_", [])))), "$_119", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(452,9-40)", StructType ("std_tuple_0_", [])))), "$_120", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(453,9-40)", StructType ("std_tuple_0_", [])))), "$_121", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(454,9-40)", StructType ("std_tuple_0_", [])))), "$_122", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(455,9-40)", StructType ("std_tuple_0_", [])))), "$_123", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(456,9-40)", StructType ("std_tuple_0_", [])))), "$_124", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(457,9-40)", StructType ("std_tuple_0_", [])))), "$_125", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(458,9-40)", StructType ("std_tuple_0_", [])))), "$_126", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", PtrTypeExpr (loc "verified/lib.rs(459,13-14)", IdentTypeExpr (loc "verified/lib.rs(459,13-14)", None, "T")))), "a", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (PtrTypeExpr (loc "verified/lib.rs(459,17-23)", IdentTypeExpr (loc "verified/lib.rs(459,17-23)", None, "T"))), "$_128", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(459,28-39)", Int (Unsigned, PtrRank))), "$_129", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(459,28-30)", Bool)), "$_130", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", PtrTypeExpr (loc "verified/lib.rs(460,13-14)", IdentTypeExpr (loc "verified/lib.rs(460,13-14)", None, "T")))), "b", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (PtrTypeExpr (loc "verified/lib.rs(460,17-23)", IdentTypeExpr (loc "verified/lib.rs(460,17-23)", None, "T"))), "$_132", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(460,28-40)", Int (Unsigned, PtrRank))), "$_133", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(460,28-31)", Bool)), "$_134", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(460,29-31)", Bool)), "$_135", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", PtrTypeExpr (loc "verified/lib.rs(461,13-14)", IdentTypeExpr (loc "verified/lib.rs(461,13-14)", None, "T")))), "c", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (PtrTypeExpr (loc "verified/lib.rs(461,17-23)", IdentTypeExpr (loc "verified/lib.rs(461,17-23)", None, "T"))), "$_137", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(461,28-43)", Int (Unsigned, PtrRank))), "$_138", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(461,32-43)", Int (Unsigned, PtrRank))), "$_139", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(461,32-34)", Bool)), "$_140", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", PtrTypeExpr (loc "verified/lib.rs(462,13-14)", IdentTypeExpr (loc "verified/lib.rs(462,13-14)", None, "T")))), "d", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (PtrTypeExpr (loc "verified/lib.rs(462,17-23)", IdentTypeExpr (loc "verified/lib.rs(462,17-23)", None, "T"))), "$_142", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(462,28-46)", Int (Unsigned, PtrRank))), "$_143", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(462,32-46)", Int (Unsigned, PtrRank))), "$_144", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(462,33-36)", Bool)), "$_145", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(462,34-36)", Bool)), "$_146", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(463,9-40)", StructType ("std_tuple_0_", [])))), "$_147", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(464,9-40)", StructType ("std_tuple_0_", [])))), "$_148", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(465,9-40)", StructType ("std_tuple_0_", [])))), "$_149", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(466,9-40)", StructType ("std_tuple_0_", [])))), "$_150", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(467,9-40)", StructType ("std_tuple_0_", [])))), "$_151", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(468,9-40)", StructType ("std_tuple_0_", [])))), "$_152", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(469,9-40)", StructType ("std_tuple_0_", [])))), "$_153", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(470,9-40)", StructType ("std_tuple_0_", [])))), "$_154", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(471,9-40)", StructType ("std_tuple_0_", [])))), "$_155", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(472,9-40)", StructType ("std_tuple_0_", [])))), "$_156", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(473,9-40)", StructType ("std_tuple_0_", [])))), "$_157", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(474,9-40)", StructType ("std_tuple_0_", [])))), "$_158", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(475,9-40)", StructType ("std_tuple_0_", [])))), "$_159", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(476,9-40)", StructType ("std_tuple_0_", [])))), "$_160", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(477,9-40)", StructType ("std_tuple_0_", [])))), "$_161", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(478,9-40)", StructType ("std_tuple_0_", [])))), "$_162", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(479,9-40)", StructType ("std_tuple_0_", [])))), "$_163", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(480,9-40)", StructType ("std_tuple_0_", [])))), "$_164", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(481,9-40)", StructType ("std_tuple_0_", [])))), "$_165", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(482,9-40)", StructType ("std_tuple_0_", [])))), "$_166", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(483,9-40)", StructType ("std_tuple_0_", [])))), "$_167", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(484,9-40)", StructType ("std_tuple_0_", [])))), "$_168", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(485,9-40)", StructType ("std_tuple_0_", [])))), "$_169", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(486,9-40)", StructType ("std_tuple_0_", [])))), "$_170", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(487,1-32)", StructType ("std_tuple_0_", [])))), "$_171", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(504,13-15)", Bool))), "c3", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(505,9-40)", StructType ("std_tuple_0_", [])))), "$_179", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(506,9-40)", StructType ("std_tuple_0_", [])))), "$_180", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(507,9-40)", StructType ("std_tuple_0_", [])))), "$_181", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(508,9-40)", StructType ("std_tuple_0_", [])))), "$_182", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(509,9-40)", StructType ("std_tuple_0_", [])))), "$_183", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(510,9-40)", StructType ("std_tuple_0_", [])))), "$_184", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(511,9-40)", StructType ("std_tuple_0_", [])))), "$_185", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(512,9-40)", StructType ("std_tuple_0_", [])))), "$_186", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(513,9-40)", StructType ("std_tuple_0_", [])))), "$_187", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(514,9-40)", StructType ("std_tuple_0_", [])))), "$_188", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(515,9-40)", StructType ("std_tuple_0_", [])))), "$_189", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(516,9-40)", StructType ("std_tuple_0_", [])))), "$_190", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(517,9-40)", StructType ("std_tuple_0_", [])))), "$_191", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(518,9-40)", StructType ("std_tuple_0_", [])))), "$_192", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(519,9-40)", StructType ("std_tuple_0_", [])))), "$_193", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(520,9-40)", StructType ("std_tuple_0_", [])))), "$_194", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(521,9-40)", StructType ("std_tuple_0_", [])))), "$_195", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(522,9-40)", StructType ("std_tuple_0_", [])))), "$_196", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(523,9-40)", StructType ("std_tuple_0_", [])))), "$_197", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(524,9-40)", StructType ("std_tuple_0_", [])))), "$_198", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(525,9-40)", StructType ("std_tuple_0_", [])))), "$_199", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(526,9-40)", StructType ("std_tuple_0_", [])))), "$_200", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(527,9-40)", StructType ("std_tuple_0_", [])))), "$_201", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(528,9-40)", StructType ("std_tuple_0_", [])))), "$_202", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(529,9-40)", StructType ("std_tuple_0_", [])))), "$_203", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(530,9-40)", StructType ("std_tuple_0_", [])))), "$_204", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(531,9-40)", StructType ("std_tuple_0_", [])))), "$_205", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(532,9-40)", StructType ("std_tuple_0_", [])))), "$_206", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(533,9-40)", StructType ("std_tuple_0_", [])))), "$_207", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(534,9-40)", StructType ("std_tuple_0_", [])))), "$_208", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(535,9-40)", StructType ("std_tuple_0_", [])))), "$_209", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(536,9-40)", StructType ("std_tuple_0_", [])))), "$_210", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(537,9-40)", StructType ("std_tuple_0_", [])))), "$_211", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(538,9-40)", StructType ("std_tuple_0_", [])))), "$_212", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(539,9-40)", StructType ("std_tuple_0_", [])))), "$_213", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(540,9-40)", StructType ("std_tuple_0_", [])))), "$_214", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(541,9-40)", StructType ("std_tuple_0_", [])))), "$_215", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(542,9-40)", StructType ("std_tuple_0_", [])))), "$_216", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(543,9-40)", StructType ("std_tuple_0_", [])))), "$_217", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(544,1-32)", StructType ("std_tuple_0_", [])))), "$_218", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(561,13-15)", Bool))), "c4", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(562,9-40)", StructType ("std_tuple_0_", [])))), "$_226", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(563,9-40)", StructType ("std_tuple_0_", [])))), "$_227", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(564,9-40)", StructType ("std_tuple_0_", [])))), "$_228", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(565,9-40)", StructType ("std_tuple_0_", [])))), "$_229", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(566,9-40)", StructType ("std_tuple_0_", [])))), "$_230", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(567,9-40)", StructType ("std_tuple_0_", [])))), "$_231", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(568,9-40)", StructType ("std_tuple_0_", [])))), "$_232", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(569,9-40)", StructType ("std_tuple_0_", [])))), "$_233", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(570,9-40)", StructType ("std_tuple_0_", [])))), "$_234", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(571,9-40)", StructType ("std_tuple_0_", [])))), "$_235", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(572,9-40)", StructType ("std_tuple_0_", [])))), "$_236", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(573,9-40)", StructType ("std_tuple_0_", [])))), "$_237", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(574,9-40)", StructType ("std_tuple_0_", [])))), "$_238", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(575,9-40)", StructType ("std_tuple_0_", [])))), "$_239", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(576,9-40)", StructType ("std_tuple_0_", [])))), "$_240", None, (ref (false), ref (None)))]);
  DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", ManifestTypeExpr (loc "verified/lib.rs(577,9-40)", StructType ("std_tuple_0_", [])))), "$_241", None, (ref (false), ref (None)))]);
  LabelStmt (loc "verified/lib.rs(321,15-16)", "0");
  ExprStmt (AssignExpr (loc "verified/lib.rs(321,15-16)", Var (loc "verified/lib.rs(321,15-16)", "$_5"), Mutation, CallExpr (loc "verified/lib.rs(321,15-16)", "fn_outcome_result", [], [], [
    LitPat (CallExpr (loc "verified/lib.rs(321,15-16)", "create_slice_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(321,15-16)", Deref (loc "verified/lib.rs(321,15-16)", Var (loc "verified/lib.rs(321,15-16)", "v"))))], Static))
  ], Static)));
  ExprStmt (AssignExpr (loc "verified/lib.rs(321,15-22)", Var (loc "verified/lib.rs(321,15-22)", "len"), Initialization, CallExpr (loc "verified/lib.rs(321,17-22)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(321,17-22)", "$_5"))], Static)));
  SwitchStmt (loc "verified/lib.rs(322,8-22)", CallExpr (loc "verified/lib.rs(322,8-22)", "std::mem::size_of", [IdentTypeExpr (loc "verified/lib.rs(322,8-22)", None, "T")], [], [], Static), [
    SwitchStmtClause (loc "verified/lib.rs(322,8-22)", CallExpr (loc "verified/lib.rs(322,8-22)", "returning", [], [], [LitPat (Var (loc "verified/lib.rs(322,8-22)", "__result"))], Static), [ExprStmt (AssignExpr (loc "verified/lib.rs(322,8-22)", Var (loc "verified/lib.rs(322,8-22)", "$_8"), Mutation, Var (loc "verified/lib.rs(322,8-22)", "__result")))]);
    SwitchStmtClause (loc "verified/lib.rs(322,8-22)", CallExpr (loc "verified/lib.rs(322,8-22)", "unwinding", [], [], [], Static), [ReturnStmt (loc "verified/lib.rs(322,8-22)", Some (CallExpr (loc "verified/lib.rs(322,8-22)", "unwinding", [], [], [], Static)))])
  ]);
  ExprStmt (AssignExpr (loc "verified/lib.rs(322,8-27)", Var (loc "verified/lib.rs(322,8-27)", "$_7"), Mutation, Operation (loc "verified/lib.rs(322,8-27)", Eq, [Var (loc "verified/lib.rs(322,8-27)", "$_8"); CastExpr (loc "verified/lib.rs(322,26-27)", ManifestTypeExpr (loc "verified/lib.rs(322,26-27)", Int (Unsigned, PtrRank)), IntLit (loc "verified/lib.rs(322,26-27)", big_int_of_string "0", true, false, LLSuffix))])));
  IfStmt (loc "verified/lib.rs(322,8-27)", Var (loc "verified/lib.rs(322,8-27)", "$_7"), [GotoStmt (loc "verified/lib.rs(322,8-27)", "3")], [GotoStmt (loc "verified/lib.rs(322,8-27)", "4")]);
  LabelStmt (loc "verified/lib.rs(328,18-19)", "4");
  ExprStmt (AssignExpr (loc "verified/lib.rs(328,18-19)", Var (loc "verified/lib.rs(328,18-19)", "$_13"), Mutation, AddressOf (loc "verified/lib.rs(328,18-19)", Deref (loc "verified/lib.rs(328,18-19)", Var (loc "verified/lib.rs(328,18-19)", "v")))));
  ExprStmt (AssignExpr (loc "verified/lib.rs(328,18-31)", Var (loc "verified/lib.rs(328,18-31)", "$_12"), Mutation, Var (loc "verified/lib.rs(328,18-31)", "$_13")));
  ExprStmt (AssignExpr (loc "verified/lib.rs(328,18-41)", Var (loc "verified/lib.rs(328,18-41)", "$_11"), Mutation, CastExpr (loc "verified/lib.rs(328,18-41)", PtrTypeExpr (loc "verified/lib.rs(328,18-41)", IdentTypeExpr (loc "verified/lib.rs(328,18-41)", None, "T")), Var (loc "verified/lib.rs(328,18-41)", "$_12"))));
  ExprStmt (AssignExpr (loc "verified/lib.rs(328,18-41)", Var (loc "verified/lib.rs(328,18-41)", "v_base"), Initialization, Var (loc "verified/lib.rs(328,18-41)", "$_11")));
  ExprStmt (AssignExpr (loc "verified/lib.rs(330,8-11)", Var (loc "verified/lib.rs(330,8-11)", "$_15"), Mutation, Var (loc "verified/lib.rs(330,8-11)", "len")));
  ExprStmt (AssignExpr (loc "verified/lib.rs(330,8-16)", Var (loc "verified/lib.rs(330,8-16)", "$_14"), Mutation, Operation (loc "verified/lib.rs(330,8-16)", Ge, [Var (loc "verified/lib.rs(330,8-16)", "$_15"); CastExpr (loc "verified/lib.rs(330,15-16)", ManifestTypeExpr (loc "verified/lib.rs(330,15-16)", Int (Unsigned, PtrRank)), IntLit (loc "verified/lib.rs(330,15-16)", big_int_of_string "8", true, false, LLSuffix))])));
  IfStmt (loc "verified/lib.rs(330,8-16)", Var (loc "verified/lib.rs(330,8-16)", "$_14"), [GotoStmt (loc "verified/lib.rs(330,8-16)", "5")], [GotoStmt (loc "verified/lib.rs(330,8-16)", "6")]);
  LabelStmt (loc "verified/lib.rs(330,5-578,6)", "6");
  GotoStmt (loc "verified/lib.rs(330,5-578,6)", "190");
  LabelStmt (loc "verified/lib.rs(331,9-332,1)", "5");
  PureStmt (loc "verified/lib.rs(331,9-332,1)", ExprStmt (CallExpr (loc "verified/lib.rs(331,37-38)", "produce_type_interp", [IdentTypeExpr (loc "verified/lib.rs(331,35-36)", None, "T")], [], [], Static)));
  PureStmt (loc "verified/lib.rs(332,9-333,1)", ExprStmt (CallExpr (loc "verified/lib.rs(332,37-38)", "produce_type_interp", [IdentTypeExpr (loc "verified/lib.rs(332,35-36)", None, "F")], [], [], Static)));
  PureStmt (loc "verified/lib.rs(333,9-334,1)", Assert (loc "verified/lib.rs(333,13-19)", CallExpr (loc "verified/lib.rs(333,20-32)", "thread_token", [], [], [VarPat (loc "verified/lib.rs(333,34-35)", "t")], Static)));
  PureStmt (loc "verified/lib.rs(334,9-335,1)", Assert (loc "verified/lib.rs(334,13-19)", Operation (loc "verified/lib.rs(334,22-24)", Eq, [Var (loc "verified/lib.rs(334,20-21)", "t"); Var (loc "verified/lib.rs(334,25-38)", "currentThread")])));
  PureStmt (loc "verified/lib.rs(335,9-336,1)", Assert (loc "verified/lib.rs(335,13-19)", PointsTo (loc "verified/lib.rs(335,34-37)", ReadArray (loc "verified/lib.rs(335,26-27)", Var (loc "verified/lib.rs(335,20-26)", "v_base"), SliceExpr (loc "verified/lib.rs(335,27-29)", None, Some (LitPat (Var (loc "verified/lib.rs(335,29-32)", "len"))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(335,39-49)", "source_all"))));
  PureStmt (loc "verified/lib.rs(336,9-337,1)", Assert (loc "verified/lib.rs(336,13-19)", CallExpr (loc "verified/lib.rs(336,20-27)", "foreach", [], [], [
    LitPat (Var (loc "verified/lib.rs(336,28-38)", "source_all"));
    LitPat (CallExpr (loc "verified/lib.rs(336,48-49)", "own", [IdentTypeExpr (loc "verified/lib.rs(336,46-47)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(336,49-50)", "t"))], Static))
  ], Static)));
  PureStmt (loc "verified/lib.rs(337,9-338,1)", DeclStmt (loc "verified/lib.rs(337,13-16)", [
    (loc "verified/lib.rs(337,17-24)", None, "mu_base", Some (CastExpr (loc "verified/lib.rs(337,70-72)", PtrTypeExpr (loc "verified/lib.rs(337,73-74)", ConstructedTypeExpr (loc "verified/lib.rs(337,74-95)", "std::mem::MaybeUninit", [IdentTypeExpr (loc "verified/lib.rs(337,96-97)", None, "T")])), CallExpr (loc "verified/lib.rs(337,27-49)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(337,58-60)", IdentTypeExpr (loc "verified/lib.rs(337,61-68)", None, "pointer"), Var (loc "verified/lib.rs(337,50-57)", "scratch")))], Static))), (ref (false), ref (None)))
  ]));
  PureStmt (loc "verified/lib.rs(338,9-339,1)", DeclStmt (loc "verified/lib.rs(338,13-16)", [
    (loc "verified/lib.rs(338,17-28)", None, "scratch_len", Some (CallExpr (loc "verified/lib.rs(338,31-38)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(338,39-46)", "scratch"))], Static)), (ref (false), ref (None)))
  ]));
  PureStmt (loc "verified/lib.rs(339,9-340,1)", Assert (loc "verified/lib.rs(339,13-19)", PointsTo (loc "verified/lib.rs(339,43-46)", ReadArray (loc "verified/lib.rs(339,27-28)", Var (loc "verified/lib.rs(339,20-27)", "mu_base"), SliceExpr (loc "verified/lib.rs(339,28-30)", None, Some (LitPat (Var (loc "verified/lib.rs(339,30-41)", "scratch_len"))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(339,48-54)", "mu_all"))));
  PureStmt (loc "verified/lib.rs(340,9-341,1)", Assert (loc "verified/lib.rs(340,13-19)", CallExpr (loc "verified/lib.rs(340,20-27)", "foreach", [], [], [
    LitPat (Var (loc "verified/lib.rs(340,28-34)", "mu_all"));
    LitPat (CallExpr (loc "verified/lib.rs(340,67-68)", "own", [
      ConstructedTypeExpr (loc "verified/lib.rs(340,42-63)", "std::mem::MaybeUninit", [IdentTypeExpr (loc "verified/lib.rs(340,64-65)", None, "T")])
    ], [], [LitPat (Var (loc "verified/lib.rs(340,68-69)", "t"))], Static))
  ], Static)));
  PureStmt (loc "verified/lib.rs(341,9-342,1)", Assert (loc "verified/lib.rs(341,13-19)", PointsTo (loc "verified/lib.rs(341,29-32)", Deref (loc "verified/lib.rs(341,20-21)", Var (loc "verified/lib.rs(341,21-28)", "is_less")), "RegularPointsTo", VarPat (loc "verified/lib.rs(341,34-45)", "less_before"))));
  PureStmt (loc "verified/lib.rs(342,9-343,1)", Assert (loc "verified/lib.rs(342,13-19)", ExprCallExpr (loc "verified/lib.rs(342,27-28)", TypePredExpr (loc "verified/lib.rs(342,23-24)", IdentTypeExpr (loc "verified/lib.rs(342,21-22)", None, "F"), "own"), [LitPat (Var (loc "verified/lib.rs(342,28-29)", "t")); LitPat (Var (loc "verified/lib.rs(342,31-42)", "less_before"))])));
  PureStmt (loc "verified/lib.rs(343,9-344,1)", ExprStmt (CallExpr (loc "verified/lib.rs(343,29-30)", "array_split", [IdentTypeExpr (loc "verified/lib.rs(343,27-28)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(343,30-36)", "v_base")); LitPat (IntLit (loc "verified/lib.rs(343,38-39)", big_int_of_string "4", true, false, NoLSuffix))], Static)));
  PureStmt (loc "verified/lib.rs(344,9-345,1)", ExprStmt (CallExpr (loc "verified/lib.rs(344,13-26)", "foreach_split", [], [], [
    LitPat (Var (loc "verified/lib.rs(344,27-37)", "source_all"));
    LitPat (CallExpr (loc "verified/lib.rs(344,47-48)", "own", [IdentTypeExpr (loc "verified/lib.rs(344,45-46)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(344,48-49)", "t"))], Static));
    LitPat (IntLit (loc "verified/lib.rs(344,52-53)", big_int_of_string "4", true, false, NoLSuffix))
  ], Static)));
  PureStmt (loc "verified/lib.rs(345,9-346,1)", Assert (loc "verified/lib.rs(345,13-19)", PointsTo (loc "verified/lib.rs(345,32-35)", ReadArray (loc "verified/lib.rs(345,26-27)", Var (loc "verified/lib.rs(345,20-26)", "v_base"), SliceExpr (loc "verified/lib.rs(345,27-29)", None, Some (LitPat (IntLit (loc "verified/lib.rs(345,29-30)", big_int_of_string "4", true, false, NoLSuffix))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(345,37-47)", "first_four"))));
  PureStmt (loc "verified/lib.rs(346,9-347,1)", ExprStmt (CallExpr (loc "verified/lib.rs(346,41-42)", "interior_pointer_limits", [IdentTypeExpr (loc "verified/lib.rs(346,39-40)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(346,42-48)", "v_base")); LitPat (IntLit (loc "verified/lib.rs(346,50-51)", big_int_of_string "4", true, false, NoLSuffix)); LitPat (IntLit (loc "verified/lib.rs(346,53-54)", big_int_of_string "1", true, false, NoLSuffix))], Static)));
  PureStmt (loc "verified/lib.rs(347,9-348,1)", DeclStmt (loc "verified/lib.rs(347,13-16)", [(loc "verified/lib.rs(347,17-22)", None, "cmp_k", Some (CallExpr (loc "verified/lib.rs(347,25-39)", "begin_lifetime", [], [], [], Static)), (ref (false), ref (None)))]));
  GotoStmt (loc "verified/lib.rs(349,1-30)", "bh0");
  LabelStmt (loc "verified/lib.rs(349,1-30)", "bh0");
  BlockStmt (loc "verified/lib.rs(349,1-30)", [], [
    BlockStmt (loc "verified/lib.rs(349,1-30)", [
      TypeWithTypeidDecl (loc "verified/lib.rs(349,5-12)", "'cmp", CallExpr (loc "verified/lib.rs(349,5-12)", "typeid_of_lft", [], [], [LitPat (Var (loc "verified/lib.rs(349,20-25)", "cmp_k"))], Static))
    ], [
      ExprStmt (CallExpr (loc "verified/lib.rs(389,13-390,1)", "#strict_lft_binding_scope", [IdentTypeExpr (loc "verified/lib.rs(389,13-390,1)", None, "'cmp")], [], [], Static));
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(387,22-29)", InferredTypeExpr (loc "verified/lib.rs(387,22-29)"), Mutable, IdentTypeExpr (loc "verified/lib.rs(387,22-29)", None, "F"))), "$_54", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [
        (loc "verified/lib.rs(316,1-579,2)", Some (StructTypeExpr (loc "verified/lib.rs(387,22-93)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(387,22-93)", InferredTypeExpr (loc "verified/lib.rs(387,22-93)"), Shared, IdentTypeExpr (loc "verified/lib.rs(387,22-93)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(387,22-93)", InferredTypeExpr (loc "verified/lib.rs(387,22-93)"), Shared, IdentTypeExpr (loc "verified/lib.rs(387,22-93)", None, "T"))])), "$_55", None, (ref (false), ref (None)))
      ]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(387,67-82)", InferredTypeExpr (loc "verified/lib.rs(387,67-82)"), Shared, IdentTypeExpr (loc "verified/lib.rs(387,67-82)", None, "T"))), "$_56", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", RustRefTypeExpr (loc "verified/lib.rs(387,67-82)", InferredTypeExpr (loc "verified/lib.rs(387,67-82)"), Shared, IdentTypeExpr (loc "verified/lib.rs(387,67-82)", None, "T")))), "$_57", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", PtrTypeExpr (loc "verified/lib.rs(387,69-82)", IdentTypeExpr (loc "verified/lib.rs(387,69-82)", None, "T")))), "$_58", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (PtrTypeExpr (loc "verified/lib.rs(387,69-75)", IdentTypeExpr (loc "verified/lib.rs(387,69-75)", None, "T"))), "$_59", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(387,84-92)", InferredTypeExpr (loc "verified/lib.rs(387,84-92)"), Shared, IdentTypeExpr (loc "verified/lib.rs(387,84-92)", None, "T"))), "$_60", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", RustRefTypeExpr (loc "verified/lib.rs(387,84-92)", InferredTypeExpr (loc "verified/lib.rs(387,84-92)"), Shared, IdentTypeExpr (loc "verified/lib.rs(387,84-92)", None, "T")))), "$_61", None, (ref (false), ref (None)))]);
      LabelStmt (loc "verified/lib.rs(349,1-30)", "bh0");
      GotoStmt (loc "verified/lib.rs(349,1-32)", "24");
      LabelStmt (loc "verified/lib.rs(350,13-351,1)", "24");
      PureStmt (loc "verified/lib.rs(350,13-351,1)", ExprStmt (CallExpr (loc "verified/lib.rs(350,44-45)", "split_four_owned_cells", [IdentTypeExpr (loc "verified/lib.rs(350,42-43)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(350,45-51)", "v_base")); LitPat (Var (loc "verified/lib.rs(350,53-54)", "t"))], Static)));
      PureStmt (loc "verified/lib.rs(351,13-352,1)", ExprStmt (CallExpr (loc "verified/lib.rs(351,47-48)", "close_full_borrow_content", [IdentTypeExpr (loc "verified/lib.rs(351,45-46)", None, "T")], [], [
        LitPat (Var (loc "verified/lib.rs(351,48-49)", "t"));
        LitPat (Operation (loc "verified/lib.rs(351,58-59)", Add, [Var (loc "verified/lib.rs(351,51-57)", "v_base"); IntLit (loc "verified/lib.rs(351,60-61)", big_int_of_string "1", true, false, NoLSuffix)]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(352,13-353,1)", ExprStmt (CallExpr (loc "verified/lib.rs(352,47-48)", "close_full_borrow_content", [IdentTypeExpr (loc "verified/lib.rs(352,45-46)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(352,48-49)", "t")); LitPat (Var (loc "verified/lib.rs(352,51-57)", "v_base"))], Static)));
      PureStmt (loc "verified/lib.rs(353,13-354,1)", ExprStmt (CallExpr (loc "verified/lib.rs(353,17-23)", "borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(353,24-29)", "cmp_k"));
        LitPat (ExprCallExpr (loc "verified/lib.rs(353,54-55)", TypePredExpr (loc "verified/lib.rs(353,34-35)", IdentTypeExpr (loc "verified/lib.rs(353,32-33)", None, "T"), "full_borrow_content"), [
          LitPat (Var (loc "verified/lib.rs(353,55-56)", "t"));
          LitPat (Operation (loc "verified/lib.rs(353,65-66)", Add, [Var (loc "verified/lib.rs(353,58-64)", "v_base"); IntLit (loc "verified/lib.rs(353,67-68)", big_int_of_string "1", true, false, NoLSuffix)]))
        ]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(354,13-355,1)", ExprStmt (CallExpr (loc "verified/lib.rs(354,17-23)", "borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(354,24-29)", "cmp_k"));
        LitPat (ExprCallExpr (loc "verified/lib.rs(354,54-55)", TypePredExpr (loc "verified/lib.rs(354,34-35)", IdentTypeExpr (loc "verified/lib.rs(354,32-33)", None, "T"), "full_borrow_content"), [LitPat (Var (loc "verified/lib.rs(354,55-56)", "t")); LitPat (Var (loc "verified/lib.rs(354,58-64)", "v_base"))]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(355,13-356,1)", ExprStmt (CallExpr (loc "verified/lib.rs(355,39-40)", "share_full_borrow", [IdentTypeExpr (loc "verified/lib.rs(355,37-38)", None, "T")], [], [
        LitPat (Var (loc "verified/lib.rs(355,40-45)", "cmp_k"));
        LitPat (Var (loc "verified/lib.rs(355,47-48)", "t"));
        LitPat (Operation (loc "verified/lib.rs(355,57-58)", Add, [Var (loc "verified/lib.rs(355,50-56)", "v_base"); IntLit (loc "verified/lib.rs(355,59-60)", big_int_of_string "1", true, false, NoLSuffix)]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(356,13-357,1)", ExprStmt (CallExpr (loc "verified/lib.rs(356,39-40)", "share_full_borrow", [IdentTypeExpr (loc "verified/lib.rs(356,37-38)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(356,40-45)", "cmp_k")); LitPat (Var (loc "verified/lib.rs(356,47-48)", "t")); LitPat (Var (loc "verified/lib.rs(356,50-56)", "v_base"))], Static)));
      PureStmt (loc "verified/lib.rs(357,13-358,1)", DeclStmt (loc "verified/lib.rs(357,17-20)", [
        (loc "verified/lib.rs(357,21-29)", None, "left_ref", Some (CallExpr (loc "verified/lib.rs(357,32-45)", "precreate_ref", [], [], [
          LitPat (Operation (loc "verified/lib.rs(357,53-54)", Add, [Var (loc "verified/lib.rs(357,46-52)", "v_base"); IntLit (loc "verified/lib.rs(357,55-56)", big_int_of_string "1", true, false, NoLSuffix)]))
        ], Static)), (ref (false), ref (None)))
      ]));
      PureStmt (loc "verified/lib.rs(358,13-359,1)", DeclStmt (loc "verified/lib.rs(358,17-20)", [
        (loc "verified/lib.rs(358,21-30)", None, "right_ref", Some (CallExpr (loc "verified/lib.rs(358,33-46)", "precreate_ref", [], [], [LitPat (Var (loc "verified/lib.rs(358,47-53)", "v_base"))], Static)), (ref (false), ref (None)))
      ]));
      PureStmt (loc "verified/lib.rs(359,13-360,1)", ExprStmt (CallExpr (loc "verified/lib.rs(359,36-37)", "init_ref_share", [IdentTypeExpr (loc "verified/lib.rs(359,34-35)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(359,37-42)", "cmp_k")); LitPat (Var (loc "verified/lib.rs(359,44-45)", "t")); LitPat (Var (loc "verified/lib.rs(359,47-55)", "left_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(360,13-361,1)", ExprStmt (CallExpr (loc "verified/lib.rs(360,36-37)", "init_ref_share", [IdentTypeExpr (loc "verified/lib.rs(360,34-35)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(360,37-42)", "cmp_k")); LitPat (Var (loc "verified/lib.rs(360,44-45)", "t")); LitPat (Var (loc "verified/lib.rs(360,47-56)", "right_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(361,13-362,1)", ExprStmt (CallExpr (loc "verified/lib.rs(361,41-42)", "close_ref_own", [IdentTypeExpr (loc "verified/lib.rs(361,33-37)", None, "'cmp"); IdentTypeExpr (loc "verified/lib.rs(361,39-40)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(361,42-50)", "left_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(362,13-363,1)", ExprStmt (CallExpr (loc "verified/lib.rs(362,41-42)", "close_ref_own", [IdentTypeExpr (loc "verified/lib.rs(362,33-37)", None, "'cmp"); IdentTypeExpr (loc "verified/lib.rs(362,39-40)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(362,42-51)", "right_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(363,13-364,1)", Close (loc "verified/lib.rs(363,17-22)", None, "std_tuple_2__own", [RustRefTypeExpr (loc "verified/lib.rs(363,25-26)", IdentTypeExpr (loc "verified/lib.rs(363,25-26)", None, "'cmp"), Shared, IdentTypeExpr (loc "verified/lib.rs(363,31-32)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(363,34-35)", IdentTypeExpr (loc "verified/lib.rs(363,34-35)", None, "'cmp"), Shared, IdentTypeExpr (loc "verified/lib.rs(363,40-41)", None, "T"))], [], [
        LitPat (Var (loc "verified/lib.rs(363,48-49)", "t"));
        LitPat (CastExpr (loc "verified/lib.rs(363,51-63)", StructTypeExpr (loc "verified/lib.rs(363,51-63)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(363,66-67)", IdentTypeExpr (loc "verified/lib.rs(363,66-67)", None, "'cmp"), Shared, IdentTypeExpr (loc "verified/lib.rs(363,72-73)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(363,75-76)", IdentTypeExpr (loc "verified/lib.rs(363,75-76)", None, "'cmp"), Shared, IdentTypeExpr (loc "verified/lib.rs(363,81-82)", None, "T"))]), InitializerList (loc "verified/lib.rs(363,51-63)", [(Some ((loc "verified/lib.rs(363,86-87)", "0")), Var (loc "verified/lib.rs(363,89-97)", "left_ref")); (Some ((loc "verified/lib.rs(363,99-100)", "1")), Var (loc "verified/lib.rs(363,102-111)", "right_ref"))])))
      ], None));
      PureStmt (loc "verified/lib.rs(364,13-365,1)", ExprStmt (CallExpr (loc "verified/lib.rs(364,17-33)", "open_frac_borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(364,34-39)", "cmp_k"));
        LitPat (CallExpr (loc "verified/lib.rs(364,41-57)", "ref_initialized_", [], [], [LitPat (Var (loc "verified/lib.rs(364,58-66)", "left_ref"))], Static));
        LitPat (Operation (loc "verified/lib.rs(364,70-71)", Div, [IntLit (loc "verified/lib.rs(364,69-70)", big_int_of_string "1", true, false, NoLSuffix); IntLit (loc "verified/lib.rs(364,71-72)", big_int_of_string "4", true, false, NoLSuffix)]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(365,13-366,1)", Open (loc "verified/lib.rs(365,17-21)", None, "ref_initialized_", [IdentTypeExpr (loc "verified/lib.rs(365,57-58)", None, "T")], [LitPat (Var (loc "verified/lib.rs(365,60-68)", "left_ref"))], [], Some (VarPat (loc "verified/lib.rs(365,24-37)", "left_fraction"))));
      PureStmt (loc "verified/lib.rs(366,13-367,1)", ExprStmt (CallExpr (loc "verified/lib.rs(366,17-33)", "open_frac_borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(366,34-39)", "cmp_k"));
        LitPat (CallExpr (loc "verified/lib.rs(366,41-57)", "ref_initialized_", [], [], [LitPat (Var (loc "verified/lib.rs(366,58-67)", "right_ref"))], Static));
        LitPat (Operation (loc "verified/lib.rs(366,71-72)", Div, [IntLit (loc "verified/lib.rs(366,70-71)", big_int_of_string "1", true, false, NoLSuffix); IntLit (loc "verified/lib.rs(366,72-73)", big_int_of_string "4", true, false, NoLSuffix)]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(367,13-368,1)", Open (loc "verified/lib.rs(367,17-21)", None, "ref_initialized_", [IdentTypeExpr (loc "verified/lib.rs(367,58-59)", None, "T")], [LitPat (Var (loc "verified/lib.rs(367,61-70)", "right_ref"))], [], Some (VarPat (loc "verified/lib.rs(367,24-38)", "right_fraction"))));
      NoopStmt (loc "verified/lib.rs(368,1-386,18)");
      ExprStmt (AssignExpr (loc "verified/lib.rs(387,22-29)", Var (loc "verified/lib.rs(387,22-29)", "$_54"), Mutation, AddressOf (loc "verified/lib.rs(387,22-29)", Deref (loc "verified/lib.rs(387,22-29)", Var (loc "verified/lib.rs(387,22-29)", "is_less")))));
      ExprStmt (AssignExpr (loc "verified/lib.rs(387,69-75)", Var (loc "verified/lib.rs(387,69-75)", "$_59"), Mutation, Var (loc "verified/lib.rs(387,69-75)", "v_base")));
      ExprStmt (AssignExpr (loc "verified/lib.rs(387,69-82)", Var (loc "verified/lib.rs(387,69-82)", "$_58"), Initialization, Operation (loc "verified/lib.rs(387,76-82)", Add, [Var (loc "verified/lib.rs(387,76-82)", "$_59"); CastExpr (loc "verified/lib.rs(387,80-81)", ManifestTypeExpr (loc "verified/lib.rs(387,80-81)", Int (Unsigned, PtrRank)), IntLit (loc "verified/lib.rs(387,80-81)", big_int_of_string "1", true, false, LLSuffix))])));
      ExprStmt (AssignExpr (loc "verified/lib.rs(387,67-82)", Var (loc "verified/lib.rs(387,67-82)", "$_57"), Initialization, CallExpr (loc "verified/lib.rs(387,67-82)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(387,67-82)", "create_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(387,67-82)", Deref (loc "verified/lib.rs(387,67-82)", Var (loc "verified/lib.rs(387,67-82)", "$_58"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(387,67-82)", Var (loc "verified/lib.rs(387,67-82)", "$_56"), Mutation, CallExpr (loc "verified/lib.rs(387,67-82)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(387,67-82)", "reborrow_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(387,67-82)", Deref (loc "verified/lib.rs(387,67-82)", Var (loc "verified/lib.rs(387,67-82)", "$_57"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(387,84-92)", Var (loc "verified/lib.rs(387,84-92)", "$_61"), Initialization, CallExpr (loc "verified/lib.rs(387,84-92)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(387,84-92)", "create_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(387,84-92)", Deref (loc "verified/lib.rs(387,84-92)", Var (loc "verified/lib.rs(387,84-92)", "v_base"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(387,84-92)", Var (loc "verified/lib.rs(387,84-92)", "$_60"), Mutation, CallExpr (loc "verified/lib.rs(387,84-92)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(387,84-92)", "reborrow_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(387,84-92)", Deref (loc "verified/lib.rs(387,84-92)", Var (loc "verified/lib.rs(387,84-92)", "$_61"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(387,22-93)", Select (loc "verified/lib.rs(387,22-93)", Var (loc "verified/lib.rs(387,22-93)", "$_55"), "0"), Mutation, Var (loc "verified/lib.rs(387,22-93)", "$_56")));
      ExprStmt (AssignExpr (loc "verified/lib.rs(387,22-93)", Select (loc "verified/lib.rs(387,22-93)", Var (loc "verified/lib.rs(387,22-93)", "$_55"), "1"), Mutation, Var (loc "verified/lib.rs(387,22-93)", "$_60")));
      ExprStmt (CallExpr (loc "verified/lib.rs(387,22-93)", "#register_type_projection_equality", [
        ProjectionTypeExpr (loc "verified/lib.rs(387,22-93)", IdentTypeExpr (loc "verified/lib.rs(387,35-36)", None, "F"), "std::ops::FnOnce", [
          StructTypeExpr (loc "verified/lib.rs(387,38-39)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(387,39-40)", IdentTypeExpr (loc "verified/lib.rs(387,39-40)", None, "'cmp"), Shared, IdentTypeExpr (loc "verified/lib.rs(387,45-46)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(387,48-49)", IdentTypeExpr (loc "verified/lib.rs(387,48-49)", None, "'cmp"), Shared, IdentTypeExpr (loc "verified/lib.rs(387,54-55)", None, "T"))])
        ], "Output");
        ManifestTypeExpr (loc "verified/lib.rs(387,22-93)", Bool)
      ], [], [], Static));
      SwitchStmt (loc "verified/lib.rs(387,22-93)", CallExpr (loc "verified/lib.rs(387,22-93)", "std::ops::FnMut::call_mut", [
        IdentTypeExpr (loc "verified/lib.rs(387,35-36)", None, "F");
        StructTypeExpr (loc "verified/lib.rs(387,38-39)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(387,39-40)", IdentTypeExpr (loc "verified/lib.rs(387,39-40)", None, "'cmp"), Shared, IdentTypeExpr (loc "verified/lib.rs(387,45-46)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(387,48-49)", IdentTypeExpr (loc "verified/lib.rs(387,48-49)", None, "'cmp"), Shared, IdentTypeExpr (loc "verified/lib.rs(387,54-55)", None, "T"))]);
        IdentTypeExpr (loc "verified/lib.rs(387,58-62)", None, "'cmp")
      ], [], [LitPat (Var (loc "verified/lib.rs(387,22-93)", "$_54")); LitPat (Var (loc "verified/lib.rs(387,22-93)", "$_55"))], Static), [
        SwitchStmtClause (loc "verified/lib.rs(387,22-93)", CallExpr (loc "verified/lib.rs(387,22-93)", "returning", [], [], [LitPat (Var (loc "verified/lib.rs(387,22-93)", "__result"))], Static), [ExprStmt (AssignExpr (loc "verified/lib.rs(387,22-93)", Var (loc "verified/lib.rs(387,22-93)", "c1"), Initialization, Var (loc "verified/lib.rs(387,22-93)", "__result")))]);
        SwitchStmtClause (loc "verified/lib.rs(387,22-93)", CallExpr (loc "verified/lib.rs(387,22-93)", "unwinding", [], [], [], Static), [
          PureStmt (loc "verified/lib.rs(372,19-24)", Close (loc "verified/lib.rs(372,19-24)", None, "comparison_debt", [IdentTypeExpr (loc "verified/lib.rs(372,43-44)", None, "T")], [], [
            LitPat (Var (loc "verified/lib.rs(372,46-47)", "t"));
            LitPat (Var (loc "verified/lib.rs(372,49-54)", "cmp_k"));
            LitPat (Operation (loc "verified/lib.rs(372,63-64)", Add, [Var (loc "verified/lib.rs(372,56-62)", "v_base"); IntLit (loc "verified/lib.rs(372,65-66)", big_int_of_string "1", true, false, NoLSuffix)]));
            LitPat (Var (loc "verified/lib.rs(372,68-74)", "v_base"));
            LitPat (Var (loc "verified/lib.rs(372,76-84)", "left_ref"));
            LitPat (Var (loc "verified/lib.rs(372,86-95)", "right_ref"));
            LitPat (Var (loc "verified/lib.rs(372,97-110)", "left_fraction"));
            LitPat (Var (loc "verified/lib.rs(372,112-126)", "right_fraction"))
          ], None));
          GotoStmt (loc "verified/lib.rs(387,22-93)", "#native_c4_direct_unwind_1")
        ])
      ]);
      PureStmt (loc "verified/lib.rs(388,13-389,1)", Close (loc "verified/lib.rs(388,17-22)", None, "comparison_debt", [IdentTypeExpr (loc "verified/lib.rs(388,41-42)", None, "T")], [], [
        LitPat (Var (loc "verified/lib.rs(388,44-45)", "t"));
        LitPat (Var (loc "verified/lib.rs(388,47-52)", "cmp_k"));
        LitPat (Operation (loc "verified/lib.rs(388,61-62)", Add, [Var (loc "verified/lib.rs(388,54-60)", "v_base"); IntLit (loc "verified/lib.rs(388,63-64)", big_int_of_string "1", true, false, NoLSuffix)]));
        LitPat (Var (loc "verified/lib.rs(388,66-72)", "v_base"));
        LitPat (Var (loc "verified/lib.rs(388,74-82)", "left_ref"));
        LitPat (Var (loc "verified/lib.rs(388,84-93)", "right_ref"));
        LitPat (Var (loc "verified/lib.rs(388,95-108)", "left_fraction"));
        LitPat (Var (loc "verified/lib.rs(388,110-124)", "right_fraction"))
      ], None))
    ], loc "verified/lib.rs(389,13-390,1)", ref ([]));
    NoopStmt (loc "verified/lib.rs(389,13-390,1)");
    PureStmt (loc "verified/lib.rs(390,9-391,1)", ExprStmt (CallExpr (loc "verified/lib.rs(390,30-31)", "recover_pair", [IdentTypeExpr (loc "verified/lib.rs(390,28-29)", None, "T")], [], [
      LitPat (Operation (loc "verified/lib.rs(390,38-39)", Add, [Var (loc "verified/lib.rs(390,31-37)", "v_base"); IntLit (loc "verified/lib.rs(390,40-41)", big_int_of_string "1", true, false, NoLSuffix)]));
      LitPat (Var (loc "verified/lib.rs(390,43-49)", "v_base"))
    ], Static)));
    PureStmt (loc "verified/lib.rs(391,9-392,1)", ExprStmt (CallExpr (loc "verified/lib.rs(391,39-40)", "join_four_owned_cells", [IdentTypeExpr (loc "verified/lib.rs(391,37-38)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(391,40-46)", "v_base")); LitPat (Var (loc "verified/lib.rs(391,48-49)", "t"))], Static)));
    PureStmt (loc "verified/lib.rs(392,9-393,1)", Assert (loc "verified/lib.rs(392,13-19)", PointsTo (loc "verified/lib.rs(392,32-35)", ReadArray (loc "verified/lib.rs(392,26-27)", Var (loc "verified/lib.rs(392,20-26)", "v_base"), SliceExpr (loc "verified/lib.rs(392,27-29)", None, Some (LitPat (IntLit (loc "verified/lib.rs(392,29-30)", big_int_of_string "4", true, false, NoLSuffix))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(392,37-50)", "first_current"))));
    PureStmt (loc "verified/lib.rs(393,9-394,1)", ExprStmt (CallExpr (loc "verified/lib.rs(393,28-29)", "array_join", [IdentTypeExpr (loc "verified/lib.rs(393,26-27)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(393,29-35)", "v_base"))], Static)));
    PureStmt (loc "verified/lib.rs(394,9-395,1)", ExprStmt (CallExpr (loc "verified/lib.rs(394,13-27)", "foreach_append", [], [], [
      LitPat (Var (loc "verified/lib.rs(394,28-41)", "first_current"));
      LitPat (CallExpr (loc "verified/lib.rs(394,43-47)", "drop", [], [], [LitPat (IntLit (loc "verified/lib.rs(394,48-49)", big_int_of_string "4", true, false, NoLSuffix)); LitPat (Var (loc "verified/lib.rs(394,51-61)", "source_all"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(395,9-396,1)", Assert (loc "verified/lib.rs(395,13-19)", PointsTo (loc "verified/lib.rs(395,34-37)", ReadArray (loc "verified/lib.rs(395,26-27)", Var (loc "verified/lib.rs(395,20-26)", "v_base"), SliceExpr (loc "verified/lib.rs(395,27-29)", None, Some (LitPat (Var (loc "verified/lib.rs(395,29-32)", "len"))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(395,39-53)", "source_current"))));
    PureStmt (loc "verified/lib.rs(396,9-397,1)", Assert (loc "verified/lib.rs(396,13-19)", CallExpr (loc "verified/lib.rs(396,20-27)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(396,28-42)", "source_current"));
      LitPat (CallExpr (loc "verified/lib.rs(396,52-53)", "own", [IdentTypeExpr (loc "verified/lib.rs(396,50-51)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(396,53-54)", "t"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(397,9-398,1)", Assert (loc "verified/lib.rs(397,13-19)", PointsTo (loc "verified/lib.rs(397,43-46)", ReadArray (loc "verified/lib.rs(397,27-28)", Var (loc "verified/lib.rs(397,20-27)", "mu_base"), SliceExpr (loc "verified/lib.rs(397,28-30)", None, Some (LitPat (Var (loc "verified/lib.rs(397,30-41)", "scratch_len"))))), "RegularPointsTo", LitPat (Var (loc "verified/lib.rs(397,47-53)", "mu_all")))));
    PureStmt (loc "verified/lib.rs(398,9-399,1)", Assert (loc "verified/lib.rs(398,13-19)", CallExpr (loc "verified/lib.rs(398,20-27)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(398,28-34)", "mu_all"));
      LitPat (CallExpr (loc "verified/lib.rs(398,67-68)", "own", [
        ConstructedTypeExpr (loc "verified/lib.rs(398,42-63)", "std::mem::MaybeUninit", [IdentTypeExpr (loc "verified/lib.rs(398,64-65)", None, "T")])
      ], [], [LitPat (Var (loc "verified/lib.rs(398,68-69)", "t"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(399,9-400,1)", Assert (loc "verified/lib.rs(399,13-19)", PointsTo (loc "verified/lib.rs(399,29-32)", Deref (loc "verified/lib.rs(399,20-21)", Var (loc "verified/lib.rs(399,21-28)", "is_less")), "RegularPointsTo", VarPat (loc "verified/lib.rs(399,34-46)", "less_current"))));
    PureStmt (loc "verified/lib.rs(400,9-401,1)", Assert (loc "verified/lib.rs(400,13-19)", ExprCallExpr (loc "verified/lib.rs(400,27-28)", TypePredExpr (loc "verified/lib.rs(400,23-24)", IdentTypeExpr (loc "verified/lib.rs(400,21-22)", None, "F"), "own"), [LitPat (Var (loc "verified/lib.rs(400,28-29)", "t")); LitPat (Var (loc "verified/lib.rs(400,31-43)", "less_current"))])));
    PureStmt (loc "verified/lib.rs(401,9-402,1)", ExprStmt (CallExpr (loc "verified/lib.rs(401,29-30)", "array_split", [IdentTypeExpr (loc "verified/lib.rs(401,27-28)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(401,30-36)", "v_base")); LitPat (IntLit (loc "verified/lib.rs(401,38-39)", big_int_of_string "4", true, false, NoLSuffix))], Static)));
    PureStmt (loc "verified/lib.rs(402,9-403,1)", ExprStmt (CallExpr (loc "verified/lib.rs(402,13-26)", "foreach_split", [], [], [
      LitPat (Var (loc "verified/lib.rs(402,27-41)", "source_current"));
      LitPat (CallExpr (loc "verified/lib.rs(402,51-52)", "own", [IdentTypeExpr (loc "verified/lib.rs(402,49-50)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(402,52-53)", "t"))], Static));
      LitPat (IntLit (loc "verified/lib.rs(402,56-57)", big_int_of_string "4", true, false, NoLSuffix))
    ], Static)));
    PureStmt (loc "verified/lib.rs(403,9-404,1)", DeclStmt (loc "verified/lib.rs(403,13-16)", [(loc "verified/lib.rs(403,17-23)", None, "cmp2_k", Some (CallExpr (loc "verified/lib.rs(403,26-40)", "begin_lifetime", [], [], [], Static)), (ref (false), ref (None)))]));
    BlockStmt (loc "verified/lib.rs(405,9-406,1)", [
      TypeWithTypeidDecl (loc "verified/lib.rs(404,13-20)", "'cmp2", CallExpr (loc "verified/lib.rs(404,13-20)", "typeid_of_lft", [], [], [LitPat (Var (loc "verified/lib.rs(404,29-35)", "cmp2_k"))], Static))
    ], [
      ExprStmt (CallExpr (loc "verified/lib.rs(444,9-445,1)", "#strict_lft_binding_scope", [IdentTypeExpr (loc "verified/lib.rs(444,9-445,1)", None, "'cmp2")], [], [], Static));
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(442,18-25)", InferredTypeExpr (loc "verified/lib.rs(442,18-25)"), Mutable, IdentTypeExpr (loc "verified/lib.rs(442,18-25)", None, "F"))), "$_101", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [
        (loc "verified/lib.rs(316,1-579,2)", Some (StructTypeExpr (loc "verified/lib.rs(442,18-99)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(442,18-99)", InferredTypeExpr (loc "verified/lib.rs(442,18-99)"), Shared, IdentTypeExpr (loc "verified/lib.rs(442,18-99)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(442,18-99)", InferredTypeExpr (loc "verified/lib.rs(442,18-99)"), Shared, IdentTypeExpr (loc "verified/lib.rs(442,18-99)", None, "T"))])), "$_102", None, (ref (false), ref (None)))
      ]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(442,66-81)", InferredTypeExpr (loc "verified/lib.rs(442,66-81)"), Shared, IdentTypeExpr (loc "verified/lib.rs(442,66-81)", None, "T"))), "$_103", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", RustRefTypeExpr (loc "verified/lib.rs(442,66-81)", InferredTypeExpr (loc "verified/lib.rs(442,66-81)"), Shared, IdentTypeExpr (loc "verified/lib.rs(442,66-81)", None, "T")))), "$_104", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", PtrTypeExpr (loc "verified/lib.rs(442,68-81)", IdentTypeExpr (loc "verified/lib.rs(442,68-81)", None, "T")))), "$_105", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (PtrTypeExpr (loc "verified/lib.rs(442,68-74)", IdentTypeExpr (loc "verified/lib.rs(442,68-74)", None, "T"))), "$_106", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(442,83-98)", InferredTypeExpr (loc "verified/lib.rs(442,83-98)"), Shared, IdentTypeExpr (loc "verified/lib.rs(442,83-98)", None, "T"))), "$_107", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", RustRefTypeExpr (loc "verified/lib.rs(442,83-98)", InferredTypeExpr (loc "verified/lib.rs(442,83-98)"), Shared, IdentTypeExpr (loc "verified/lib.rs(442,83-98)", None, "T")))), "$_108", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", PtrTypeExpr (loc "verified/lib.rs(442,85-98)", IdentTypeExpr (loc "verified/lib.rs(442,85-98)", None, "T")))), "$_109", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (PtrTypeExpr (loc "verified/lib.rs(442,85-91)", IdentTypeExpr (loc "verified/lib.rs(442,85-91)", None, "T"))), "$_110", None, (ref (false), ref (None)))]);
      PureStmt (loc "verified/lib.rs(405,9-406,1)", ExprStmt (CallExpr (loc "verified/lib.rs(405,41-42)", "interior_pointer_limits", [IdentTypeExpr (loc "verified/lib.rs(405,39-40)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(405,42-48)", "v_base")); LitPat (IntLit (loc "verified/lib.rs(405,50-51)", big_int_of_string "4", true, false, NoLSuffix)); LitPat (IntLit (loc "verified/lib.rs(405,53-54)", big_int_of_string "3", true, false, NoLSuffix))], Static)));
      PureStmt (loc "verified/lib.rs(406,9-407,1)", ExprStmt (CallExpr (loc "verified/lib.rs(406,41-42)", "interior_pointer_limits", [IdentTypeExpr (loc "verified/lib.rs(406,39-40)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(406,42-48)", "v_base")); LitPat (IntLit (loc "verified/lib.rs(406,50-51)", big_int_of_string "4", true, false, NoLSuffix)); LitPat (IntLit (loc "verified/lib.rs(406,53-54)", big_int_of_string "2", true, false, NoLSuffix))], Static)));
      PureStmt (loc "verified/lib.rs(407,9-408,1)", ExprStmt (CallExpr (loc "verified/lib.rs(407,40-41)", "split_four_owned_cells", [IdentTypeExpr (loc "verified/lib.rs(407,38-39)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(407,41-47)", "v_base")); LitPat (Var (loc "verified/lib.rs(407,49-50)", "t"))], Static)));
      PureStmt (loc "verified/lib.rs(408,9-409,1)", ExprStmt (CallExpr (loc "verified/lib.rs(408,43-44)", "close_full_borrow_content", [IdentTypeExpr (loc "verified/lib.rs(408,41-42)", None, "T")], [], [
        LitPat (Var (loc "verified/lib.rs(408,44-45)", "t"));
        LitPat (Operation (loc "verified/lib.rs(408,54-55)", Add, [Var (loc "verified/lib.rs(408,47-53)", "v_base"); IntLit (loc "verified/lib.rs(408,56-57)", big_int_of_string "3", true, false, NoLSuffix)]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(409,9-410,1)", ExprStmt (CallExpr (loc "verified/lib.rs(409,43-44)", "close_full_borrow_content", [IdentTypeExpr (loc "verified/lib.rs(409,41-42)", None, "T")], [], [
        LitPat (Var (loc "verified/lib.rs(409,44-45)", "t"));
        LitPat (Operation (loc "verified/lib.rs(409,54-55)", Add, [Var (loc "verified/lib.rs(409,47-53)", "v_base"); IntLit (loc "verified/lib.rs(409,56-57)", big_int_of_string "2", true, false, NoLSuffix)]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(410,9-411,1)", ExprStmt (CallExpr (loc "verified/lib.rs(410,13-19)", "borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(410,20-26)", "cmp2_k"));
        LitPat (ExprCallExpr (loc "verified/lib.rs(410,51-52)", TypePredExpr (loc "verified/lib.rs(410,31-32)", IdentTypeExpr (loc "verified/lib.rs(410,29-30)", None, "T"), "full_borrow_content"), [
          LitPat (Var (loc "verified/lib.rs(410,52-53)", "t"));
          LitPat (Operation (loc "verified/lib.rs(410,62-63)", Add, [Var (loc "verified/lib.rs(410,55-61)", "v_base"); IntLit (loc "verified/lib.rs(410,64-65)", big_int_of_string "3", true, false, NoLSuffix)]))
        ]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(411,9-412,1)", ExprStmt (CallExpr (loc "verified/lib.rs(411,13-19)", "borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(411,20-26)", "cmp2_k"));
        LitPat (ExprCallExpr (loc "verified/lib.rs(411,51-52)", TypePredExpr (loc "verified/lib.rs(411,31-32)", IdentTypeExpr (loc "verified/lib.rs(411,29-30)", None, "T"), "full_borrow_content"), [
          LitPat (Var (loc "verified/lib.rs(411,52-53)", "t"));
          LitPat (Operation (loc "verified/lib.rs(411,62-63)", Add, [Var (loc "verified/lib.rs(411,55-61)", "v_base"); IntLit (loc "verified/lib.rs(411,64-65)", big_int_of_string "2", true, false, NoLSuffix)]))
        ]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(412,9-413,1)", ExprStmt (CallExpr (loc "verified/lib.rs(412,35-36)", "share_full_borrow", [IdentTypeExpr (loc "verified/lib.rs(412,33-34)", None, "T")], [], [
        LitPat (Var (loc "verified/lib.rs(412,36-42)", "cmp2_k"));
        LitPat (Var (loc "verified/lib.rs(412,44-45)", "t"));
        LitPat (Operation (loc "verified/lib.rs(412,54-55)", Add, [Var (loc "verified/lib.rs(412,47-53)", "v_base"); IntLit (loc "verified/lib.rs(412,56-57)", big_int_of_string "3", true, false, NoLSuffix)]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(413,9-414,1)", ExprStmt (CallExpr (loc "verified/lib.rs(413,35-36)", "share_full_borrow", [IdentTypeExpr (loc "verified/lib.rs(413,33-34)", None, "T")], [], [
        LitPat (Var (loc "verified/lib.rs(413,36-42)", "cmp2_k"));
        LitPat (Var (loc "verified/lib.rs(413,44-45)", "t"));
        LitPat (Operation (loc "verified/lib.rs(413,54-55)", Add, [Var (loc "verified/lib.rs(413,47-53)", "v_base"); IntLit (loc "verified/lib.rs(413,56-57)", big_int_of_string "2", true, false, NoLSuffix)]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(414,9-415,1)", DeclStmt (loc "verified/lib.rs(414,13-16)", [
        (loc "verified/lib.rs(414,17-26)", None, "left2_ref", Some (CallExpr (loc "verified/lib.rs(414,29-42)", "precreate_ref", [], [], [
          LitPat (Operation (loc "verified/lib.rs(414,50-51)", Add, [Var (loc "verified/lib.rs(414,43-49)", "v_base"); IntLit (loc "verified/lib.rs(414,52-53)", big_int_of_string "3", true, false, NoLSuffix)]))
        ], Static)), (ref (false), ref (None)))
      ]));
      PureStmt (loc "verified/lib.rs(415,9-416,1)", DeclStmt (loc "verified/lib.rs(415,13-16)", [
        (loc "verified/lib.rs(415,17-27)", None, "right2_ref", Some (CallExpr (loc "verified/lib.rs(415,30-43)", "precreate_ref", [], [], [
          LitPat (Operation (loc "verified/lib.rs(415,51-52)", Add, [Var (loc "verified/lib.rs(415,44-50)", "v_base"); IntLit (loc "verified/lib.rs(415,53-54)", big_int_of_string "2", true, false, NoLSuffix)]))
        ], Static)), (ref (false), ref (None)))
      ]));
      PureStmt (loc "verified/lib.rs(416,9-417,1)", ExprStmt (CallExpr (loc "verified/lib.rs(416,32-33)", "init_ref_share", [IdentTypeExpr (loc "verified/lib.rs(416,30-31)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(416,33-39)", "cmp2_k")); LitPat (Var (loc "verified/lib.rs(416,41-42)", "t")); LitPat (Var (loc "verified/lib.rs(416,44-53)", "left2_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(417,9-418,1)", ExprStmt (CallExpr (loc "verified/lib.rs(417,32-33)", "init_ref_share", [IdentTypeExpr (loc "verified/lib.rs(417,30-31)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(417,33-39)", "cmp2_k")); LitPat (Var (loc "verified/lib.rs(417,41-42)", "t")); LitPat (Var (loc "verified/lib.rs(417,44-54)", "right2_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(418,9-419,1)", ExprStmt (CallExpr (loc "verified/lib.rs(418,38-39)", "close_ref_own", [IdentTypeExpr (loc "verified/lib.rs(418,29-34)", None, "'cmp2"); IdentTypeExpr (loc "verified/lib.rs(418,36-37)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(418,39-48)", "left2_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(419,9-420,1)", ExprStmt (CallExpr (loc "verified/lib.rs(419,38-39)", "close_ref_own", [IdentTypeExpr (loc "verified/lib.rs(419,29-34)", None, "'cmp2"); IdentTypeExpr (loc "verified/lib.rs(419,36-37)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(419,39-49)", "right2_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(420,9-421,1)", Close (loc "verified/lib.rs(420,13-18)", None, "std_tuple_2__own", [RustRefTypeExpr (loc "verified/lib.rs(420,21-22)", IdentTypeExpr (loc "verified/lib.rs(420,21-22)", None, "'cmp2"), Shared, IdentTypeExpr (loc "verified/lib.rs(420,28-29)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(420,31-32)", IdentTypeExpr (loc "verified/lib.rs(420,31-32)", None, "'cmp2"), Shared, IdentTypeExpr (loc "verified/lib.rs(420,38-39)", None, "T"))], [], [
        LitPat (Var (loc "verified/lib.rs(420,46-47)", "t"));
        LitPat (CastExpr (loc "verified/lib.rs(420,49-61)", StructTypeExpr (loc "verified/lib.rs(420,49-61)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(420,64-65)", IdentTypeExpr (loc "verified/lib.rs(420,64-65)", None, "'cmp2"), Shared, IdentTypeExpr (loc "verified/lib.rs(420,71-72)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(420,74-75)", IdentTypeExpr (loc "verified/lib.rs(420,74-75)", None, "'cmp2"), Shared, IdentTypeExpr (loc "verified/lib.rs(420,81-82)", None, "T"))]), InitializerList (loc "verified/lib.rs(420,49-61)", [(Some ((loc "verified/lib.rs(420,86-87)", "0")), Var (loc "verified/lib.rs(420,89-98)", "left2_ref")); (Some ((loc "verified/lib.rs(420,100-101)", "1")), Var (loc "verified/lib.rs(420,103-113)", "right2_ref"))])))
      ], None));
      PureStmt (loc "verified/lib.rs(421,9-422,1)", ExprStmt (CallExpr (loc "verified/lib.rs(421,13-29)", "open_frac_borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(421,30-36)", "cmp2_k"));
        LitPat (CallExpr (loc "verified/lib.rs(421,38-54)", "ref_initialized_", [], [], [LitPat (Var (loc "verified/lib.rs(421,55-64)", "left2_ref"))], Static));
        LitPat (Operation (loc "verified/lib.rs(421,68-69)", Div, [IntLit (loc "verified/lib.rs(421,67-68)", big_int_of_string "1", true, false, NoLSuffix); IntLit (loc "verified/lib.rs(421,69-70)", big_int_of_string "4", true, false, NoLSuffix)]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(422,9-423,1)", Open (loc "verified/lib.rs(422,13-17)", None, "ref_initialized_", [IdentTypeExpr (loc "verified/lib.rs(422,54-55)", None, "T")], [LitPat (Var (loc "verified/lib.rs(422,57-66)", "left2_ref"))], [], Some (VarPat (loc "verified/lib.rs(422,20-34)", "left2_fraction"))));
      PureStmt (loc "verified/lib.rs(423,9-424,1)", ExprStmt (CallExpr (loc "verified/lib.rs(423,13-29)", "open_frac_borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(423,30-36)", "cmp2_k"));
        LitPat (CallExpr (loc "verified/lib.rs(423,38-54)", "ref_initialized_", [], [], [LitPat (Var (loc "verified/lib.rs(423,55-65)", "right2_ref"))], Static));
        LitPat (Operation (loc "verified/lib.rs(423,69-70)", Div, [IntLit (loc "verified/lib.rs(423,68-69)", big_int_of_string "1", true, false, NoLSuffix); IntLit (loc "verified/lib.rs(423,70-71)", big_int_of_string "4", true, false, NoLSuffix)]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(424,9-425,1)", Open (loc "verified/lib.rs(424,13-17)", None, "ref_initialized_", [IdentTypeExpr (loc "verified/lib.rs(424,55-56)", None, "T")], [LitPat (Var (loc "verified/lib.rs(424,58-68)", "right2_ref"))], [], Some (VarPat (loc "verified/lib.rs(424,20-35)", "right2_fraction"))));
      NoopStmt (loc "verified/lib.rs(425,1-441,14)");
      ExprStmt (AssignExpr (loc "verified/lib.rs(442,18-25)", Var (loc "verified/lib.rs(442,18-25)", "$_101"), Mutation, AddressOf (loc "verified/lib.rs(442,18-25)", Deref (loc "verified/lib.rs(442,18-25)", Var (loc "verified/lib.rs(442,18-25)", "is_less")))));
      ExprStmt (AssignExpr (loc "verified/lib.rs(442,68-74)", Var (loc "verified/lib.rs(442,68-74)", "$_106"), Mutation, Var (loc "verified/lib.rs(442,68-74)", "v_base")));
      ExprStmt (AssignExpr (loc "verified/lib.rs(442,68-81)", Var (loc "verified/lib.rs(442,68-81)", "$_105"), Initialization, Operation (loc "verified/lib.rs(442,75-81)", Add, [Var (loc "verified/lib.rs(442,75-81)", "$_106"); CastExpr (loc "verified/lib.rs(442,79-80)", ManifestTypeExpr (loc "verified/lib.rs(442,79-80)", Int (Unsigned, PtrRank)), IntLit (loc "verified/lib.rs(442,79-80)", big_int_of_string "3", true, false, LLSuffix))])));
      ExprStmt (AssignExpr (loc "verified/lib.rs(442,66-81)", Var (loc "verified/lib.rs(442,66-81)", "$_104"), Initialization, CallExpr (loc "verified/lib.rs(442,66-81)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(442,66-81)", "create_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(442,66-81)", Deref (loc "verified/lib.rs(442,66-81)", Var (loc "verified/lib.rs(442,66-81)", "$_105"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(442,66-81)", Var (loc "verified/lib.rs(442,66-81)", "$_103"), Mutation, CallExpr (loc "verified/lib.rs(442,66-81)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(442,66-81)", "reborrow_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(442,66-81)", Deref (loc "verified/lib.rs(442,66-81)", Var (loc "verified/lib.rs(442,66-81)", "$_104"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(442,85-91)", Var (loc "verified/lib.rs(442,85-91)", "$_110"), Mutation, Var (loc "verified/lib.rs(442,85-91)", "v_base")));
      ExprStmt (AssignExpr (loc "verified/lib.rs(442,85-98)", Var (loc "verified/lib.rs(442,85-98)", "$_109"), Initialization, Operation (loc "verified/lib.rs(442,92-98)", Add, [Var (loc "verified/lib.rs(442,92-98)", "$_110"); CastExpr (loc "verified/lib.rs(442,96-97)", ManifestTypeExpr (loc "verified/lib.rs(442,96-97)", Int (Unsigned, PtrRank)), IntLit (loc "verified/lib.rs(442,96-97)", big_int_of_string "2", true, false, LLSuffix))])));
      ExprStmt (AssignExpr (loc "verified/lib.rs(442,83-98)", Var (loc "verified/lib.rs(442,83-98)", "$_108"), Initialization, CallExpr (loc "verified/lib.rs(442,83-98)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(442,83-98)", "create_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(442,83-98)", Deref (loc "verified/lib.rs(442,83-98)", Var (loc "verified/lib.rs(442,83-98)", "$_109"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(442,83-98)", Var (loc "verified/lib.rs(442,83-98)", "$_107"), Mutation, CallExpr (loc "verified/lib.rs(442,83-98)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(442,83-98)", "reborrow_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(442,83-98)", Deref (loc "verified/lib.rs(442,83-98)", Var (loc "verified/lib.rs(442,83-98)", "$_108"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(442,18-99)", Select (loc "verified/lib.rs(442,18-99)", Var (loc "verified/lib.rs(442,18-99)", "$_102"), "0"), Mutation, Var (loc "verified/lib.rs(442,18-99)", "$_103")));
      ExprStmt (AssignExpr (loc "verified/lib.rs(442,18-99)", Select (loc "verified/lib.rs(442,18-99)", Var (loc "verified/lib.rs(442,18-99)", "$_102"), "1"), Mutation, Var (loc "verified/lib.rs(442,18-99)", "$_107")));
      ExprStmt (CallExpr (loc "verified/lib.rs(442,18-99)", "#register_type_projection_equality", [
        ProjectionTypeExpr (loc "verified/lib.rs(442,18-99)", IdentTypeExpr (loc "verified/lib.rs(442,31-32)", None, "F"), "std::ops::FnOnce", [
          StructTypeExpr (loc "verified/lib.rs(442,34-35)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(442,35-36)", IdentTypeExpr (loc "verified/lib.rs(442,35-36)", None, "'cmp2"), Shared, IdentTypeExpr (loc "verified/lib.rs(442,42-43)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(442,45-46)", IdentTypeExpr (loc "verified/lib.rs(442,45-46)", None, "'cmp2"), Shared, IdentTypeExpr (loc "verified/lib.rs(442,52-53)", None, "T"))])
        ], "Output");
        ManifestTypeExpr (loc "verified/lib.rs(442,18-99)", Bool)
      ], [], [], Static));
      SwitchStmt (loc "verified/lib.rs(442,18-99)", CallExpr (loc "verified/lib.rs(442,18-99)", "std::ops::FnMut::call_mut", [
        IdentTypeExpr (loc "verified/lib.rs(442,31-32)", None, "F");
        StructTypeExpr (loc "verified/lib.rs(442,34-35)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(442,35-36)", IdentTypeExpr (loc "verified/lib.rs(442,35-36)", None, "'cmp2"), Shared, IdentTypeExpr (loc "verified/lib.rs(442,42-43)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(442,45-46)", IdentTypeExpr (loc "verified/lib.rs(442,45-46)", None, "'cmp2"), Shared, IdentTypeExpr (loc "verified/lib.rs(442,52-53)", None, "T"))]);
        IdentTypeExpr (loc "verified/lib.rs(442,56-61)", None, "'cmp2")
      ], [], [LitPat (Var (loc "verified/lib.rs(442,18-99)", "$_101")); LitPat (Var (loc "verified/lib.rs(442,18-99)", "$_102"))], Static), [
        SwitchStmtClause (loc "verified/lib.rs(442,18-99)", CallExpr (loc "verified/lib.rs(442,18-99)", "returning", [], [], [LitPat (Var (loc "verified/lib.rs(442,18-99)", "__result"))], Static), [ExprStmt (AssignExpr (loc "verified/lib.rs(442,18-99)", Var (loc "verified/lib.rs(442,18-99)", "c2"), Initialization, Var (loc "verified/lib.rs(442,18-99)", "__result")))]);
        SwitchStmtClause (loc "verified/lib.rs(442,18-99)", CallExpr (loc "verified/lib.rs(442,18-99)", "unwinding", [], [], [], Static), [
          PureStmt (loc "verified/lib.rs(427,15-20)", Close (loc "verified/lib.rs(427,15-20)", None, "comparison_debt", [IdentTypeExpr (loc "verified/lib.rs(427,39-40)", None, "T")], [], [
            LitPat (Var (loc "verified/lib.rs(427,42-43)", "t"));
            LitPat (Var (loc "verified/lib.rs(427,45-51)", "cmp2_k"));
            LitPat (Operation (loc "verified/lib.rs(427,60-61)", Add, [Var (loc "verified/lib.rs(427,53-59)", "v_base"); IntLit (loc "verified/lib.rs(427,62-63)", big_int_of_string "3", true, false, NoLSuffix)]));
            LitPat (Operation (loc "verified/lib.rs(427,72-73)", Add, [Var (loc "verified/lib.rs(427,65-71)", "v_base"); IntLit (loc "verified/lib.rs(427,74-75)", big_int_of_string "2", true, false, NoLSuffix)]));
            LitPat (Var (loc "verified/lib.rs(427,77-86)", "left2_ref"));
            LitPat (Var (loc "verified/lib.rs(427,88-98)", "right2_ref"));
            LitPat (Var (loc "verified/lib.rs(427,100-114)", "left2_fraction"));
            LitPat (Var (loc "verified/lib.rs(427,116-131)", "right2_fraction"))
          ], None));
          GotoStmt (loc "verified/lib.rs(442,18-99)", "#native_c4_direct_unwind_2")
        ])
      ]);
      PureStmt (loc "verified/lib.rs(443,9-444,1)", Close (loc "verified/lib.rs(443,13-18)", None, "comparison_debt", [IdentTypeExpr (loc "verified/lib.rs(443,37-38)", None, "T")], [], [
        LitPat (Var (loc "verified/lib.rs(443,40-41)", "t"));
        LitPat (Var (loc "verified/lib.rs(443,43-49)", "cmp2_k"));
        LitPat (Operation (loc "verified/lib.rs(443,58-59)", Add, [Var (loc "verified/lib.rs(443,51-57)", "v_base"); IntLit (loc "verified/lib.rs(443,60-61)", big_int_of_string "3", true, false, NoLSuffix)]));
        LitPat (Operation (loc "verified/lib.rs(443,70-71)", Add, [Var (loc "verified/lib.rs(443,63-69)", "v_base"); IntLit (loc "verified/lib.rs(443,72-73)", big_int_of_string "2", true, false, NoLSuffix)]));
        LitPat (Var (loc "verified/lib.rs(443,75-84)", "left2_ref"));
        LitPat (Var (loc "verified/lib.rs(443,86-96)", "right2_ref"));
        LitPat (Var (loc "verified/lib.rs(443,98-112)", "left2_fraction"));
        LitPat (Var (loc "verified/lib.rs(443,114-129)", "right2_fraction"))
      ], None))
    ], loc "verified/lib.rs(444,9-445,1)", ref ([]));
    NoopStmt (loc "verified/lib.rs(444,9-445,1)");
    PureStmt (loc "verified/lib.rs(445,9-446,1)", ExprStmt (CallExpr (loc "verified/lib.rs(445,30-31)", "recover_pair", [IdentTypeExpr (loc "verified/lib.rs(445,28-29)", None, "T")], [], [
      LitPat (Operation (loc "verified/lib.rs(445,38-39)", Add, [Var (loc "verified/lib.rs(445,31-37)", "v_base"); IntLit (loc "verified/lib.rs(445,40-41)", big_int_of_string "3", true, false, NoLSuffix)]));
      LitPat (Operation (loc "verified/lib.rs(445,50-51)", Add, [Var (loc "verified/lib.rs(445,43-49)", "v_base"); IntLit (loc "verified/lib.rs(445,52-53)", big_int_of_string "2", true, false, NoLSuffix)]))
    ], Static)));
    PureStmt (loc "verified/lib.rs(446,9-447,1)", ExprStmt (CallExpr (loc "verified/lib.rs(446,39-40)", "join_four_owned_cells", [IdentTypeExpr (loc "verified/lib.rs(446,37-38)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(446,40-46)", "v_base")); LitPat (Var (loc "verified/lib.rs(446,48-49)", "t"))], Static)));
    PureStmt (loc "verified/lib.rs(447,9-448,1)", Assert (loc "verified/lib.rs(447,13-19)", PointsTo (loc "verified/lib.rs(447,32-35)", ReadArray (loc "verified/lib.rs(447,26-27)", Var (loc "verified/lib.rs(447,20-26)", "v_base"), SliceExpr (loc "verified/lib.rs(447,27-29)", None, Some (LitPat (IntLit (loc "verified/lib.rs(447,29-30)", big_int_of_string "4", true, false, NoLSuffix))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(447,37-51)", "first_current2"))));
    PureStmt (loc "verified/lib.rs(448,9-449,1)", ExprStmt (CallExpr (loc "verified/lib.rs(448,28-29)", "array_join", [IdentTypeExpr (loc "verified/lib.rs(448,26-27)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(448,29-35)", "v_base"))], Static)));
    PureStmt (loc "verified/lib.rs(449,9-450,1)", ExprStmt (CallExpr (loc "verified/lib.rs(449,13-27)", "foreach_append", [], [], [
      LitPat (Var (loc "verified/lib.rs(449,28-42)", "first_current2"));
      LitPat (CallExpr (loc "verified/lib.rs(449,44-48)", "drop", [], [], [LitPat (IntLit (loc "verified/lib.rs(449,49-50)", big_int_of_string "4", true, false, NoLSuffix)); LitPat (Var (loc "verified/lib.rs(449,52-66)", "source_current"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(450,9-451,1)", Assert (loc "verified/lib.rs(450,13-19)", PointsTo (loc "verified/lib.rs(450,34-37)", ReadArray (loc "verified/lib.rs(450,26-27)", Var (loc "verified/lib.rs(450,20-26)", "v_base"), SliceExpr (loc "verified/lib.rs(450,27-29)", None, Some (LitPat (Var (loc "verified/lib.rs(450,29-32)", "len"))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(450,39-54)", "source_current2"))));
    PureStmt (loc "verified/lib.rs(451,9-452,1)", Assert (loc "verified/lib.rs(451,13-19)", CallExpr (loc "verified/lib.rs(451,20-27)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(451,28-43)", "source_current2"));
      LitPat (CallExpr (loc "verified/lib.rs(451,53-54)", "own", [IdentTypeExpr (loc "verified/lib.rs(451,51-52)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(451,54-55)", "t"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(452,9-453,1)", Assert (loc "verified/lib.rs(452,13-19)", PointsTo (loc "verified/lib.rs(452,43-46)", ReadArray (loc "verified/lib.rs(452,27-28)", Var (loc "verified/lib.rs(452,20-27)", "mu_base"), SliceExpr (loc "verified/lib.rs(452,28-30)", None, Some (LitPat (Var (loc "verified/lib.rs(452,30-41)", "scratch_len"))))), "RegularPointsTo", LitPat (Var (loc "verified/lib.rs(452,47-53)", "mu_all")))));
    PureStmt (loc "verified/lib.rs(453,9-454,1)", Assert (loc "verified/lib.rs(453,13-19)", CallExpr (loc "verified/lib.rs(453,20-27)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(453,28-34)", "mu_all"));
      LitPat (CallExpr (loc "verified/lib.rs(453,67-68)", "own", [
        ConstructedTypeExpr (loc "verified/lib.rs(453,42-63)", "std::mem::MaybeUninit", [IdentTypeExpr (loc "verified/lib.rs(453,64-65)", None, "T")])
      ], [], [LitPat (Var (loc "verified/lib.rs(453,68-69)", "t"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(454,9-455,1)", Assert (loc "verified/lib.rs(454,13-19)", PointsTo (loc "verified/lib.rs(454,29-32)", Deref (loc "verified/lib.rs(454,20-21)", Var (loc "verified/lib.rs(454,21-28)", "is_less")), "RegularPointsTo", VarPat (loc "verified/lib.rs(454,34-47)", "less_current2"))));
    PureStmt (loc "verified/lib.rs(455,9-456,1)", Assert (loc "verified/lib.rs(455,13-19)", ExprCallExpr (loc "verified/lib.rs(455,27-28)", TypePredExpr (loc "verified/lib.rs(455,23-24)", IdentTypeExpr (loc "verified/lib.rs(455,21-22)", None, "F"), "own"), [LitPat (Var (loc "verified/lib.rs(455,28-29)", "t")); LitPat (Var (loc "verified/lib.rs(455,31-44)", "less_current2"))])));
    PureStmt (loc "verified/lib.rs(456,9-457,1)", ExprStmt (CallExpr (loc "verified/lib.rs(456,29-30)", "array_split", [IdentTypeExpr (loc "verified/lib.rs(456,27-28)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(456,30-36)", "v_base")); LitPat (IntLit (loc "verified/lib.rs(456,38-39)", big_int_of_string "4", true, false, NoLSuffix))], Static)));
    PureStmt (loc "verified/lib.rs(457,9-458,1)", ExprStmt (CallExpr (loc "verified/lib.rs(457,13-26)", "foreach_split", [], [], [
      LitPat (Var (loc "verified/lib.rs(457,27-42)", "source_current2"));
      LitPat (CallExpr (loc "verified/lib.rs(457,52-53)", "own", [IdentTypeExpr (loc "verified/lib.rs(457,50-51)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(457,53-54)", "t"))], Static));
      LitPat (IntLit (loc "verified/lib.rs(457,57-58)", big_int_of_string "4", true, false, NoLSuffix))
    ], Static)));
    PureStmt (loc "verified/lib.rs(458,9-459,1)", ExprStmt (CallExpr (loc "verified/lib.rs(458,38-39)", "selected_four_limits", [IdentTypeExpr (loc "verified/lib.rs(458,36-37)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(458,39-45)", "v_base")); LitPat (Var (loc "verified/lib.rs(458,47-49)", "c1")); LitPat (Var (loc "verified/lib.rs(458,51-53)", "c2"))], Static)));
    ExprStmt (AssignExpr (loc "verified/lib.rs(459,17-23)", Var (loc "verified/lib.rs(459,17-23)", "$_128"), Mutation, Var (loc "verified/lib.rs(459,17-23)", "v_base")));
    ExprStmt (AssignExpr (loc "verified/lib.rs(459,28-30)", Var (loc "verified/lib.rs(459,28-30)", "$_130"), Mutation, Var (loc "verified/lib.rs(459,28-30)", "c1")));
    ExprStmt (AssignExpr (loc "verified/lib.rs(459,28-39)", Var (loc "verified/lib.rs(459,28-39)", "$_129"), Mutation, CastExpr (loc "verified/lib.rs(459,28-39)", ManifestTypeExpr (loc "verified/lib.rs(459,28-39)", Int (Unsigned, PtrRank)), Var (loc "verified/lib.rs(459,28-39)", "$_130"))));
    ExprStmt (AssignExpr (loc "verified/lib.rs(459,17-40)", Var (loc "verified/lib.rs(459,17-40)", "a"), Initialization, Operation (loc "verified/lib.rs(459,24-40)", Add, [Var (loc "verified/lib.rs(459,24-40)", "$_128"); Var (loc "verified/lib.rs(459,24-40)", "$_129")])));
    ExprStmt (AssignExpr (loc "verified/lib.rs(460,17-23)", Var (loc "verified/lib.rs(460,17-23)", "$_132"), Mutation, Var (loc "verified/lib.rs(460,17-23)", "v_base")));
    ExprStmt (AssignExpr (loc "verified/lib.rs(460,29-31)", Var (loc "verified/lib.rs(460,29-31)", "$_135"), Mutation, Var (loc "verified/lib.rs(460,29-31)", "c1")));
    ExprStmt (AssignExpr (loc "verified/lib.rs(460,28-31)", Var (loc "verified/lib.rs(460,28-31)", "$_134"), Mutation, Operation (loc "verified/lib.rs(460,28-31)", Not, [Var (loc "verified/lib.rs(460,28-31)", "$_135")])));
    ExprStmt (AssignExpr (loc "verified/lib.rs(460,28-40)", Var (loc "verified/lib.rs(460,28-40)", "$_133"), Mutation, CastExpr (loc "verified/lib.rs(460,28-40)", ManifestTypeExpr (loc "verified/lib.rs(460,28-40)", Int (Unsigned, PtrRank)), Var (loc "verified/lib.rs(460,28-40)", "$_134"))));
    ExprStmt (AssignExpr (loc "verified/lib.rs(460,17-41)", Var (loc "verified/lib.rs(460,17-41)", "b"), Initialization, Operation (loc "verified/lib.rs(460,24-41)", Add, [Var (loc "verified/lib.rs(460,24-41)", "$_132"); Var (loc "verified/lib.rs(460,24-41)", "$_133")])));
    ExprStmt (AssignExpr (loc "verified/lib.rs(461,17-23)", Var (loc "verified/lib.rs(461,17-23)", "$_137"), Mutation, Var (loc "verified/lib.rs(461,17-23)", "v_base")));
    ExprStmt (AssignExpr (loc "verified/lib.rs(461,32-34)", Var (loc "verified/lib.rs(461,32-34)", "$_140"), Mutation, Var (loc "verified/lib.rs(461,32-34)", "c2")));
    ExprStmt (AssignExpr (loc "verified/lib.rs(461,32-43)", Var (loc "verified/lib.rs(461,32-43)", "$_139"), Mutation, CastExpr (loc "verified/lib.rs(461,32-43)", ManifestTypeExpr (loc "verified/lib.rs(461,32-43)", Int (Unsigned, PtrRank)), Var (loc "verified/lib.rs(461,32-43)", "$_140"))));
    ExprStmt (AssignExpr (loc "verified/lib.rs(461,28-43)", Var (loc "verified/lib.rs(461,28-43)", "$_138"), Mutation, Operation (loc "verified/lib.rs(461,28-43)", Add, [CastExpr (loc "verified/lib.rs(461,28-29)", ManifestTypeExpr (loc "verified/lib.rs(461,28-29)", Int (Unsigned, PtrRank)), IntLit (loc "verified/lib.rs(461,28-29)", big_int_of_string "2", true, false, LLSuffix)); Var (loc "verified/lib.rs(461,28-43)", "$_139")])));
    ExprStmt (AssignExpr (loc "verified/lib.rs(461,17-44)", Var (loc "verified/lib.rs(461,17-44)", "c"), Initialization, Operation (loc "verified/lib.rs(461,24-44)", Add, [Var (loc "verified/lib.rs(461,24-44)", "$_137"); Var (loc "verified/lib.rs(461,24-44)", "$_138")])));
    ExprStmt (AssignExpr (loc "verified/lib.rs(462,17-23)", Var (loc "verified/lib.rs(462,17-23)", "$_142"), Mutation, Var (loc "verified/lib.rs(462,17-23)", "v_base")));
    ExprStmt (AssignExpr (loc "verified/lib.rs(462,34-36)", Var (loc "verified/lib.rs(462,34-36)", "$_146"), Mutation, Var (loc "verified/lib.rs(462,34-36)", "c2")));
    ExprStmt (AssignExpr (loc "verified/lib.rs(462,33-36)", Var (loc "verified/lib.rs(462,33-36)", "$_145"), Mutation, Operation (loc "verified/lib.rs(462,33-36)", Not, [Var (loc "verified/lib.rs(462,33-36)", "$_146")])));
    ExprStmt (AssignExpr (loc "verified/lib.rs(462,32-46)", Var (loc "verified/lib.rs(462,32-46)", "$_144"), Mutation, CastExpr (loc "verified/lib.rs(462,32-46)", ManifestTypeExpr (loc "verified/lib.rs(462,32-46)", Int (Unsigned, PtrRank)), Var (loc "verified/lib.rs(462,32-46)", "$_145"))));
    ExprStmt (AssignExpr (loc "verified/lib.rs(462,28-46)", Var (loc "verified/lib.rs(462,28-46)", "$_143"), Mutation, Operation (loc "verified/lib.rs(462,28-46)", Add, [CastExpr (loc "verified/lib.rs(462,28-29)", ManifestTypeExpr (loc "verified/lib.rs(462,28-29)", Int (Unsigned, PtrRank)), IntLit (loc "verified/lib.rs(462,28-29)", big_int_of_string "2", true, false, LLSuffix)); Var (loc "verified/lib.rs(462,28-46)", "$_144")])));
    ExprStmt (AssignExpr (loc "verified/lib.rs(462,17-47)", Var (loc "verified/lib.rs(462,17-47)", "d"), Initialization, Operation (loc "verified/lib.rs(462,24-47)", Add, [Var (loc "verified/lib.rs(462,24-47)", "$_142"); Var (loc "verified/lib.rs(462,24-47)", "$_143")])));
    PureStmt (loc "verified/lib.rs(463,9-464,1)", DeclStmt (loc "verified/lib.rs(463,13-16)", [(loc "verified/lib.rs(463,17-23)", None, "cmp3_k", Some (CallExpr (loc "verified/lib.rs(463,26-40)", "begin_lifetime", [], [], [], Static)), (ref (false), ref (None)))]));
    BlockStmt (loc "verified/lib.rs(465,9-466,1)", [
      TypeWithTypeidDecl (loc "verified/lib.rs(464,13-20)", "'cmp3", CallExpr (loc "verified/lib.rs(464,13-20)", "typeid_of_lft", [], [], [LitPat (Var (loc "verified/lib.rs(464,29-35)", "cmp3_k"))], Static))
    ], [
      ExprStmt (CallExpr (loc "verified/lib.rs(506,9-507,1)", "#strict_lft_binding_scope", [IdentTypeExpr (loc "verified/lib.rs(506,9-507,1)", None, "'cmp3")], [], [], Static));
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(504,18-25)", InferredTypeExpr (loc "verified/lib.rs(504,18-25)"), Mutable, IdentTypeExpr (loc "verified/lib.rs(504,18-25)", None, "F"))), "$_173", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [
        (loc "verified/lib.rs(316,1-579,2)", Some (StructTypeExpr (loc "verified/lib.rs(504,18-75)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(504,18-75)", InferredTypeExpr (loc "verified/lib.rs(504,18-75)"), Shared, IdentTypeExpr (loc "verified/lib.rs(504,18-75)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(504,18-75)", InferredTypeExpr (loc "verified/lib.rs(504,18-75)"), Shared, IdentTypeExpr (loc "verified/lib.rs(504,18-75)", None, "T"))])), "$_174", None, (ref (false), ref (None)))
      ]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(504,66-69)", InferredTypeExpr (loc "verified/lib.rs(504,66-69)"), Shared, IdentTypeExpr (loc "verified/lib.rs(504,66-69)", None, "T"))), "$_175", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", RustRefTypeExpr (loc "verified/lib.rs(504,66-69)", InferredTypeExpr (loc "verified/lib.rs(504,66-69)"), Shared, IdentTypeExpr (loc "verified/lib.rs(504,66-69)", None, "T")))), "$_176", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(504,71-74)", InferredTypeExpr (loc "verified/lib.rs(504,71-74)"), Shared, IdentTypeExpr (loc "verified/lib.rs(504,71-74)", None, "T"))), "$_177", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", RustRefTypeExpr (loc "verified/lib.rs(504,71-74)", InferredTypeExpr (loc "verified/lib.rs(504,71-74)"), Shared, IdentTypeExpr (loc "verified/lib.rs(504,71-74)", None, "T")))), "$_178", None, (ref (false), ref (None)))]);
      PureStmt (loc "verified/lib.rs(465,9-466,1)", ExprStmt (CallExpr (loc "verified/lib.rs(465,41-42)", "interior_pointer_limits", [IdentTypeExpr (loc "verified/lib.rs(465,39-40)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(465,42-48)", "v_base")); LitPat (IntLit (loc "verified/lib.rs(465,50-51)", big_int_of_string "4", true, false, NoLSuffix)); LitPat (CastExpr (loc "verified/lib.rs(465,56-58)", ManifestTypeExpr (loc "verified/lib.rs(465,59-64)", Int (Unsigned, PtrRank)), Var (loc "verified/lib.rs(465,53-55)", "c1")))], Static)));
      PureStmt (loc "verified/lib.rs(466,9-467,1)", ExprStmt (CallExpr (loc "verified/lib.rs(466,41-42)", "interior_pointer_limits", [IdentTypeExpr (loc "verified/lib.rs(466,39-40)", None, "T")], [], [
        LitPat (Var (loc "verified/lib.rs(466,42-48)", "v_base"));
        LitPat (IntLit (loc "verified/lib.rs(466,50-51)", big_int_of_string "4", true, false, NoLSuffix));
        LitPat (CastExpr (loc "verified/lib.rs(466,59-61)", ManifestTypeExpr (loc "verified/lib.rs(466,62-67)", Int (Unsigned, PtrRank)), Operation (loc "verified/lib.rs(466,54-55)", Not, [Var (loc "verified/lib.rs(466,55-57)", "c1")])))
      ], Static)));
      PureStmt (loc "verified/lib.rs(467,9-468,1)", ExprStmt (CallExpr (loc "verified/lib.rs(467,41-42)", "interior_pointer_limits", [IdentTypeExpr (loc "verified/lib.rs(467,39-40)", None, "T")], [], [
        LitPat (Var (loc "verified/lib.rs(467,42-48)", "v_base"));
        LitPat (IntLit (loc "verified/lib.rs(467,50-51)", big_int_of_string "4", true, false, NoLSuffix));
        LitPat (Operation (loc "verified/lib.rs(467,55-56)", Add, [IntLit (loc "verified/lib.rs(467,53-54)", big_int_of_string "2", true, false, NoLSuffix); CastExpr (loc "verified/lib.rs(467,60-62)", ManifestTypeExpr (loc "verified/lib.rs(467,63-68)", Int (Unsigned, PtrRank)), Var (loc "verified/lib.rs(467,57-59)", "c2"))]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(468,9-469,1)", ExprStmt (CallExpr (loc "verified/lib.rs(468,41-42)", "interior_pointer_limits", [IdentTypeExpr (loc "verified/lib.rs(468,39-40)", None, "T")], [], [
        LitPat (Var (loc "verified/lib.rs(468,42-48)", "v_base"));
        LitPat (IntLit (loc "verified/lib.rs(468,50-51)", big_int_of_string "4", true, false, NoLSuffix));
        LitPat (Operation (loc "verified/lib.rs(468,55-56)", Add, [
          IntLit (loc "verified/lib.rs(468,53-54)", big_int_of_string "2", true, false, NoLSuffix);
          CastExpr (loc "verified/lib.rs(468,62-64)", ManifestTypeExpr (loc "verified/lib.rs(468,65-70)", Int (Unsigned, PtrRank)), Operation (loc "verified/lib.rs(468,58-59)", Not, [Var (loc "verified/lib.rs(468,59-61)", "c2")]))
        ]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(469,9-470,1)", ExprStmt (CallExpr (loc "verified/lib.rs(469,37-38)", "split_selected_four", [IdentTypeExpr (loc "verified/lib.rs(469,35-36)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(469,38-44)", "v_base")); LitPat (Var (loc "verified/lib.rs(469,46-47)", "t")); LitPat (Var (loc "verified/lib.rs(469,49-51)", "c1")); LitPat (Var (loc "verified/lib.rs(469,53-55)", "c2"))], Static)));
      PureStmt (loc "verified/lib.rs(470,9-471,1)", ExprStmt (CallExpr (loc "verified/lib.rs(470,43-44)", "close_full_borrow_content", [IdentTypeExpr (loc "verified/lib.rs(470,41-42)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(470,44-45)", "t")); LitPat (Var (loc "verified/lib.rs(470,47-48)", "c"))], Static)));
      PureStmt (loc "verified/lib.rs(471,9-472,1)", ExprStmt (CallExpr (loc "verified/lib.rs(471,43-44)", "close_full_borrow_content", [IdentTypeExpr (loc "verified/lib.rs(471,41-42)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(471,44-45)", "t")); LitPat (Var (loc "verified/lib.rs(471,47-48)", "a"))], Static)));
      PureStmt (loc "verified/lib.rs(472,9-473,1)", ExprStmt (CallExpr (loc "verified/lib.rs(472,13-19)", "borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(472,20-26)", "cmp3_k"));
        LitPat (ExprCallExpr (loc "verified/lib.rs(472,51-52)", TypePredExpr (loc "verified/lib.rs(472,31-32)", IdentTypeExpr (loc "verified/lib.rs(472,29-30)", None, "T"), "full_borrow_content"), [LitPat (Var (loc "verified/lib.rs(472,52-53)", "t")); LitPat (Var (loc "verified/lib.rs(472,55-56)", "c"))]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(473,9-474,1)", ExprStmt (CallExpr (loc "verified/lib.rs(473,13-19)", "borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(473,20-26)", "cmp3_k"));
        LitPat (ExprCallExpr (loc "verified/lib.rs(473,51-52)", TypePredExpr (loc "verified/lib.rs(473,31-32)", IdentTypeExpr (loc "verified/lib.rs(473,29-30)", None, "T"), "full_borrow_content"), [LitPat (Var (loc "verified/lib.rs(473,52-53)", "t")); LitPat (Var (loc "verified/lib.rs(473,55-56)", "a"))]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(474,9-475,1)", ExprStmt (CallExpr (loc "verified/lib.rs(474,35-36)", "share_full_borrow", [IdentTypeExpr (loc "verified/lib.rs(474,33-34)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(474,36-42)", "cmp3_k")); LitPat (Var (loc "verified/lib.rs(474,44-45)", "t")); LitPat (Var (loc "verified/lib.rs(474,47-48)", "c"))], Static)));
      PureStmt (loc "verified/lib.rs(475,9-476,1)", ExprStmt (CallExpr (loc "verified/lib.rs(475,35-36)", "share_full_borrow", [IdentTypeExpr (loc "verified/lib.rs(475,33-34)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(475,36-42)", "cmp3_k")); LitPat (Var (loc "verified/lib.rs(475,44-45)", "t")); LitPat (Var (loc "verified/lib.rs(475,47-48)", "a"))], Static)));
      PureStmt (loc "verified/lib.rs(476,9-477,1)", DeclStmt (loc "verified/lib.rs(476,13-16)", [
        (loc "verified/lib.rs(476,17-26)", None, "left3_ref", Some (CallExpr (loc "verified/lib.rs(476,29-42)", "precreate_ref", [], [], [LitPat (Var (loc "verified/lib.rs(476,43-44)", "c"))], Static)), (ref (false), ref (None)))
      ]));
      PureStmt (loc "verified/lib.rs(477,9-478,1)", DeclStmt (loc "verified/lib.rs(477,13-16)", [
        (loc "verified/lib.rs(477,17-27)", None, "right3_ref", Some (CallExpr (loc "verified/lib.rs(477,30-43)", "precreate_ref", [], [], [LitPat (Var (loc "verified/lib.rs(477,44-45)", "a"))], Static)), (ref (false), ref (None)))
      ]));
      PureStmt (loc "verified/lib.rs(478,9-479,1)", ExprStmt (CallExpr (loc "verified/lib.rs(478,32-33)", "init_ref_share", [IdentTypeExpr (loc "verified/lib.rs(478,30-31)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(478,33-39)", "cmp3_k")); LitPat (Var (loc "verified/lib.rs(478,41-42)", "t")); LitPat (Var (loc "verified/lib.rs(478,44-53)", "left3_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(479,9-480,1)", ExprStmt (CallExpr (loc "verified/lib.rs(479,32-33)", "init_ref_share", [IdentTypeExpr (loc "verified/lib.rs(479,30-31)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(479,33-39)", "cmp3_k")); LitPat (Var (loc "verified/lib.rs(479,41-42)", "t")); LitPat (Var (loc "verified/lib.rs(479,44-54)", "right3_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(480,9-481,1)", ExprStmt (CallExpr (loc "verified/lib.rs(480,38-39)", "close_ref_own", [IdentTypeExpr (loc "verified/lib.rs(480,29-34)", None, "'cmp3"); IdentTypeExpr (loc "verified/lib.rs(480,36-37)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(480,39-48)", "left3_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(481,9-482,1)", ExprStmt (CallExpr (loc "verified/lib.rs(481,38-39)", "close_ref_own", [IdentTypeExpr (loc "verified/lib.rs(481,29-34)", None, "'cmp3"); IdentTypeExpr (loc "verified/lib.rs(481,36-37)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(481,39-49)", "right3_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(482,9-483,1)", Close (loc "verified/lib.rs(482,13-18)", None, "std_tuple_2__own", [RustRefTypeExpr (loc "verified/lib.rs(482,21-22)", IdentTypeExpr (loc "verified/lib.rs(482,21-22)", None, "'cmp3"), Shared, IdentTypeExpr (loc "verified/lib.rs(482,28-29)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(482,31-32)", IdentTypeExpr (loc "verified/lib.rs(482,31-32)", None, "'cmp3"), Shared, IdentTypeExpr (loc "verified/lib.rs(482,38-39)", None, "T"))], [], [
        LitPat (Var (loc "verified/lib.rs(482,46-47)", "t"));
        LitPat (CastExpr (loc "verified/lib.rs(482,49-61)", StructTypeExpr (loc "verified/lib.rs(482,49-61)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(482,64-65)", IdentTypeExpr (loc "verified/lib.rs(482,64-65)", None, "'cmp3"), Shared, IdentTypeExpr (loc "verified/lib.rs(482,71-72)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(482,74-75)", IdentTypeExpr (loc "verified/lib.rs(482,74-75)", None, "'cmp3"), Shared, IdentTypeExpr (loc "verified/lib.rs(482,81-82)", None, "T"))]), InitializerList (loc "verified/lib.rs(482,49-61)", [(Some ((loc "verified/lib.rs(482,86-87)", "0")), Var (loc "verified/lib.rs(482,89-98)", "left3_ref")); (Some ((loc "verified/lib.rs(482,100-101)", "1")), Var (loc "verified/lib.rs(482,103-113)", "right3_ref"))])))
      ], None));
      PureStmt (loc "verified/lib.rs(483,9-484,1)", ExprStmt (CallExpr (loc "verified/lib.rs(483,13-29)", "open_frac_borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(483,30-36)", "cmp3_k"));
        LitPat (CallExpr (loc "verified/lib.rs(483,38-54)", "ref_initialized_", [], [], [LitPat (Var (loc "verified/lib.rs(483,55-64)", "left3_ref"))], Static));
        LitPat (Operation (loc "verified/lib.rs(483,68-69)", Div, [IntLit (loc "verified/lib.rs(483,67-68)", big_int_of_string "1", true, false, NoLSuffix); IntLit (loc "verified/lib.rs(483,69-70)", big_int_of_string "4", true, false, NoLSuffix)]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(484,9-485,1)", Open (loc "verified/lib.rs(484,13-17)", None, "ref_initialized_", [IdentTypeExpr (loc "verified/lib.rs(484,54-55)", None, "T")], [LitPat (Var (loc "verified/lib.rs(484,57-66)", "left3_ref"))], [], Some (VarPat (loc "verified/lib.rs(484,20-34)", "left3_fraction"))));
      PureStmt (loc "verified/lib.rs(485,9-486,1)", ExprStmt (CallExpr (loc "verified/lib.rs(485,13-29)", "open_frac_borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(485,30-36)", "cmp3_k"));
        LitPat (CallExpr (loc "verified/lib.rs(485,38-54)", "ref_initialized_", [], [], [LitPat (Var (loc "verified/lib.rs(485,55-65)", "right3_ref"))], Static));
        LitPat (Operation (loc "verified/lib.rs(485,69-70)", Div, [IntLit (loc "verified/lib.rs(485,68-69)", big_int_of_string "1", true, false, NoLSuffix); IntLit (loc "verified/lib.rs(485,70-71)", big_int_of_string "4", true, false, NoLSuffix)]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(486,9-487,1)", Open (loc "verified/lib.rs(486,13-17)", None, "ref_initialized_", [IdentTypeExpr (loc "verified/lib.rs(486,55-56)", None, "T")], [LitPat (Var (loc "verified/lib.rs(486,58-68)", "right3_ref"))], [], Some (VarPat (loc "verified/lib.rs(486,20-35)", "right3_fraction"))));
      NoopStmt (loc "verified/lib.rs(487,1-503,14)");
      ExprStmt (AssignExpr (loc "verified/lib.rs(504,18-25)", Var (loc "verified/lib.rs(504,18-25)", "$_173"), Mutation, AddressOf (loc "verified/lib.rs(504,18-25)", Deref (loc "verified/lib.rs(504,18-25)", Var (loc "verified/lib.rs(504,18-25)", "is_less")))));
      ExprStmt (AssignExpr (loc "verified/lib.rs(504,66-69)", Var (loc "verified/lib.rs(504,66-69)", "$_176"), Initialization, CallExpr (loc "verified/lib.rs(504,66-69)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(504,66-69)", "create_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(504,66-69)", Deref (loc "verified/lib.rs(504,66-69)", Var (loc "verified/lib.rs(504,66-69)", "c"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(504,66-69)", Var (loc "verified/lib.rs(504,66-69)", "$_175"), Mutation, CallExpr (loc "verified/lib.rs(504,66-69)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(504,66-69)", "reborrow_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(504,66-69)", Deref (loc "verified/lib.rs(504,66-69)", Var (loc "verified/lib.rs(504,66-69)", "$_176"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(504,71-74)", Var (loc "verified/lib.rs(504,71-74)", "$_178"), Initialization, CallExpr (loc "verified/lib.rs(504,71-74)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(504,71-74)", "create_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(504,71-74)", Deref (loc "verified/lib.rs(504,71-74)", Var (loc "verified/lib.rs(504,71-74)", "a"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(504,71-74)", Var (loc "verified/lib.rs(504,71-74)", "$_177"), Mutation, CallExpr (loc "verified/lib.rs(504,71-74)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(504,71-74)", "reborrow_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(504,71-74)", Deref (loc "verified/lib.rs(504,71-74)", Var (loc "verified/lib.rs(504,71-74)", "$_178"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(504,18-75)", Select (loc "verified/lib.rs(504,18-75)", Var (loc "verified/lib.rs(504,18-75)", "$_174"), "0"), Mutation, Var (loc "verified/lib.rs(504,18-75)", "$_175")));
      ExprStmt (AssignExpr (loc "verified/lib.rs(504,18-75)", Select (loc "verified/lib.rs(504,18-75)", Var (loc "verified/lib.rs(504,18-75)", "$_174"), "1"), Mutation, Var (loc "verified/lib.rs(504,18-75)", "$_177")));
      ExprStmt (CallExpr (loc "verified/lib.rs(504,18-75)", "#register_type_projection_equality", [
        ProjectionTypeExpr (loc "verified/lib.rs(504,18-75)", IdentTypeExpr (loc "verified/lib.rs(504,31-32)", None, "F"), "std::ops::FnOnce", [
          StructTypeExpr (loc "verified/lib.rs(504,34-35)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(504,35-36)", IdentTypeExpr (loc "verified/lib.rs(504,35-36)", None, "'cmp3"), Shared, IdentTypeExpr (loc "verified/lib.rs(504,42-43)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(504,45-46)", IdentTypeExpr (loc "verified/lib.rs(504,45-46)", None, "'cmp3"), Shared, IdentTypeExpr (loc "verified/lib.rs(504,52-53)", None, "T"))])
        ], "Output");
        ManifestTypeExpr (loc "verified/lib.rs(504,18-75)", Bool)
      ], [], [], Static));
      SwitchStmt (loc "verified/lib.rs(504,18-75)", CallExpr (loc "verified/lib.rs(504,18-75)", "std::ops::FnMut::call_mut", [
        IdentTypeExpr (loc "verified/lib.rs(504,31-32)", None, "F");
        StructTypeExpr (loc "verified/lib.rs(504,34-35)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(504,35-36)", IdentTypeExpr (loc "verified/lib.rs(504,35-36)", None, "'cmp3"), Shared, IdentTypeExpr (loc "verified/lib.rs(504,42-43)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(504,45-46)", IdentTypeExpr (loc "verified/lib.rs(504,45-46)", None, "'cmp3"), Shared, IdentTypeExpr (loc "verified/lib.rs(504,52-53)", None, "T"))]);
        IdentTypeExpr (loc "verified/lib.rs(504,56-61)", None, "'cmp3")
      ], [], [LitPat (Var (loc "verified/lib.rs(504,18-75)", "$_173")); LitPat (Var (loc "verified/lib.rs(504,18-75)", "$_174"))], Static), [
        SwitchStmtClause (loc "verified/lib.rs(504,18-75)", CallExpr (loc "verified/lib.rs(504,18-75)", "returning", [], [], [LitPat (Var (loc "verified/lib.rs(504,18-75)", "__result"))], Static), [ExprStmt (AssignExpr (loc "verified/lib.rs(504,18-75)", Var (loc "verified/lib.rs(504,18-75)", "c3"), Initialization, Var (loc "verified/lib.rs(504,18-75)", "__result")))]);
        SwitchStmtClause (loc "verified/lib.rs(504,18-75)", CallExpr (loc "verified/lib.rs(504,18-75)", "unwinding", [], [], [], Static), [
          PureStmt (loc "verified/lib.rs(489,15-20)", Close (loc "verified/lib.rs(489,15-20)", None, "comparison_debt", [IdentTypeExpr (loc "verified/lib.rs(489,39-40)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(489,42-43)", "t")); LitPat (Var (loc "verified/lib.rs(489,45-51)", "cmp3_k")); LitPat (Var (loc "verified/lib.rs(489,53-54)", "c")); LitPat (Var (loc "verified/lib.rs(489,56-57)", "a")); LitPat (Var (loc "verified/lib.rs(489,59-68)", "left3_ref")); LitPat (Var (loc "verified/lib.rs(489,70-80)", "right3_ref")); LitPat (Var (loc "verified/lib.rs(489,82-96)", "left3_fraction")); LitPat (Var (loc "verified/lib.rs(489,98-113)", "right3_fraction"))], None));
          GotoStmt (loc "verified/lib.rs(504,18-75)", "#native_c4_direct_unwind_3")
        ])
      ]);
      PureStmt (loc "verified/lib.rs(505,9-506,1)", Close (loc "verified/lib.rs(505,13-18)", None, "comparison_debt", [IdentTypeExpr (loc "verified/lib.rs(505,37-38)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(505,40-41)", "t")); LitPat (Var (loc "verified/lib.rs(505,43-49)", "cmp3_k")); LitPat (Var (loc "verified/lib.rs(505,51-52)", "c")); LitPat (Var (loc "verified/lib.rs(505,54-55)", "a")); LitPat (Var (loc "verified/lib.rs(505,57-66)", "left3_ref")); LitPat (Var (loc "verified/lib.rs(505,68-78)", "right3_ref")); LitPat (Var (loc "verified/lib.rs(505,80-94)", "left3_fraction")); LitPat (Var (loc "verified/lib.rs(505,96-111)", "right3_fraction"))], None))
    ], loc "verified/lib.rs(506,9-507,1)", ref ([]));
    NoopStmt (loc "verified/lib.rs(506,9-507,1)");
    PureStmt (loc "verified/lib.rs(507,9-508,1)", ExprStmt (CallExpr (loc "verified/lib.rs(507,30-31)", "recover_pair", [IdentTypeExpr (loc "verified/lib.rs(507,28-29)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(507,31-32)", "c")); LitPat (Var (loc "verified/lib.rs(507,34-35)", "a"))], Static)));
    PureStmt (loc "verified/lib.rs(508,9-509,1)", ExprStmt (CallExpr (loc "verified/lib.rs(508,36-37)", "join_selected_four", [IdentTypeExpr (loc "verified/lib.rs(508,34-35)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(508,37-43)", "v_base")); LitPat (Var (loc "verified/lib.rs(508,45-46)", "t")); LitPat (Var (loc "verified/lib.rs(508,48-50)", "c1")); LitPat (Var (loc "verified/lib.rs(508,52-54)", "c2"))], Static)));
    PureStmt (loc "verified/lib.rs(509,9-510,1)", Assert (loc "verified/lib.rs(509,13-19)", PointsTo (loc "verified/lib.rs(509,32-35)", ReadArray (loc "verified/lib.rs(509,26-27)", Var (loc "verified/lib.rs(509,20-26)", "v_base"), SliceExpr (loc "verified/lib.rs(509,27-29)", None, Some (LitPat (IntLit (loc "verified/lib.rs(509,29-30)", big_int_of_string "4", true, false, NoLSuffix))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(509,37-51)", "first_current3"))));
    PureStmt (loc "verified/lib.rs(510,9-511,1)", ExprStmt (CallExpr (loc "verified/lib.rs(510,28-29)", "array_join", [IdentTypeExpr (loc "verified/lib.rs(510,26-27)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(510,29-35)", "v_base"))], Static)));
    PureStmt (loc "verified/lib.rs(511,9-512,1)", ExprStmt (CallExpr (loc "verified/lib.rs(511,13-27)", "foreach_append", [], [], [
      LitPat (Var (loc "verified/lib.rs(511,28-42)", "first_current3"));
      LitPat (CallExpr (loc "verified/lib.rs(511,44-48)", "drop", [], [], [LitPat (IntLit (loc "verified/lib.rs(511,49-50)", big_int_of_string "4", true, false, NoLSuffix)); LitPat (Var (loc "verified/lib.rs(511,52-67)", "source_current2"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(512,9-513,1)", Assert (loc "verified/lib.rs(512,13-19)", PointsTo (loc "verified/lib.rs(512,34-37)", ReadArray (loc "verified/lib.rs(512,26-27)", Var (loc "verified/lib.rs(512,20-26)", "v_base"), SliceExpr (loc "verified/lib.rs(512,27-29)", None, Some (LitPat (Var (loc "verified/lib.rs(512,29-32)", "len"))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(512,39-54)", "source_current3"))));
    PureStmt (loc "verified/lib.rs(513,9-514,1)", Assert (loc "verified/lib.rs(513,13-19)", CallExpr (loc "verified/lib.rs(513,20-27)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(513,28-43)", "source_current3"));
      LitPat (CallExpr (loc "verified/lib.rs(513,53-54)", "own", [IdentTypeExpr (loc "verified/lib.rs(513,51-52)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(513,54-55)", "t"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(514,9-515,1)", Assert (loc "verified/lib.rs(514,13-19)", PointsTo (loc "verified/lib.rs(514,43-46)", ReadArray (loc "verified/lib.rs(514,27-28)", Var (loc "verified/lib.rs(514,20-27)", "mu_base"), SliceExpr (loc "verified/lib.rs(514,28-30)", None, Some (LitPat (Var (loc "verified/lib.rs(514,30-41)", "scratch_len"))))), "RegularPointsTo", LitPat (Var (loc "verified/lib.rs(514,47-53)", "mu_all")))));
    PureStmt (loc "verified/lib.rs(515,9-516,1)", Assert (loc "verified/lib.rs(515,13-19)", CallExpr (loc "verified/lib.rs(515,20-27)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(515,28-34)", "mu_all"));
      LitPat (CallExpr (loc "verified/lib.rs(515,67-68)", "own", [
        ConstructedTypeExpr (loc "verified/lib.rs(515,42-63)", "std::mem::MaybeUninit", [IdentTypeExpr (loc "verified/lib.rs(515,64-65)", None, "T")])
      ], [], [LitPat (Var (loc "verified/lib.rs(515,68-69)", "t"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(516,9-517,1)", Assert (loc "verified/lib.rs(516,13-19)", PointsTo (loc "verified/lib.rs(516,29-32)", Deref (loc "verified/lib.rs(516,20-21)", Var (loc "verified/lib.rs(516,21-28)", "is_less")), "RegularPointsTo", VarPat (loc "verified/lib.rs(516,34-47)", "less_current3"))));
    PureStmt (loc "verified/lib.rs(517,9-518,1)", Assert (loc "verified/lib.rs(517,13-19)", ExprCallExpr (loc "verified/lib.rs(517,27-28)", TypePredExpr (loc "verified/lib.rs(517,23-24)", IdentTypeExpr (loc "verified/lib.rs(517,21-22)", None, "F"), "own"), [LitPat (Var (loc "verified/lib.rs(517,28-29)", "t")); LitPat (Var (loc "verified/lib.rs(517,31-44)", "less_current3"))])));
    PureStmt (loc "verified/lib.rs(518,9-519,1)", ExprStmt (CallExpr (loc "verified/lib.rs(518,29-30)", "array_split", [IdentTypeExpr (loc "verified/lib.rs(518,27-28)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(518,30-36)", "v_base")); LitPat (IntLit (loc "verified/lib.rs(518,38-39)", big_int_of_string "4", true, false, NoLSuffix))], Static)));
    PureStmt (loc "verified/lib.rs(519,9-520,1)", ExprStmt (CallExpr (loc "verified/lib.rs(519,13-26)", "foreach_split", [], [], [
      LitPat (Var (loc "verified/lib.rs(519,27-42)", "source_current3"));
      LitPat (CallExpr (loc "verified/lib.rs(519,52-53)", "own", [IdentTypeExpr (loc "verified/lib.rs(519,50-51)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(519,53-54)", "t"))], Static));
      LitPat (IntLit (loc "verified/lib.rs(519,57-58)", big_int_of_string "4", true, false, NoLSuffix))
    ], Static)));
    PureStmt (loc "verified/lib.rs(520,9-521,1)", DeclStmt (loc "verified/lib.rs(520,13-16)", [(loc "verified/lib.rs(520,17-23)", None, "cmp4_k", Some (CallExpr (loc "verified/lib.rs(520,26-40)", "begin_lifetime", [], [], [], Static)), (ref (false), ref (None)))]));
    BlockStmt (loc "verified/lib.rs(522,9-523,1)", [
      TypeWithTypeidDecl (loc "verified/lib.rs(521,13-20)", "'cmp4", CallExpr (loc "verified/lib.rs(521,13-20)", "typeid_of_lft", [], [], [LitPat (Var (loc "verified/lib.rs(521,29-35)", "cmp4_k"))], Static))
    ], [
      ExprStmt (CallExpr (loc "verified/lib.rs(563,9-564,1)", "#strict_lft_binding_scope", [IdentTypeExpr (loc "verified/lib.rs(563,9-564,1)", None, "'cmp4")], [], [], Static));
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(561,18-25)", InferredTypeExpr (loc "verified/lib.rs(561,18-25)"), Mutable, IdentTypeExpr (loc "verified/lib.rs(561,18-25)", None, "F"))), "$_220", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [
        (loc "verified/lib.rs(316,1-579,2)", Some (StructTypeExpr (loc "verified/lib.rs(561,18-75)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(561,18-75)", InferredTypeExpr (loc "verified/lib.rs(561,18-75)"), Shared, IdentTypeExpr (loc "verified/lib.rs(561,18-75)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(561,18-75)", InferredTypeExpr (loc "verified/lib.rs(561,18-75)"), Shared, IdentTypeExpr (loc "verified/lib.rs(561,18-75)", None, "T"))])), "$_221", None, (ref (false), ref (None)))
      ]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(561,66-69)", InferredTypeExpr (loc "verified/lib.rs(561,66-69)"), Shared, IdentTypeExpr (loc "verified/lib.rs(561,66-69)", None, "T"))), "$_222", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", RustRefTypeExpr (loc "verified/lib.rs(561,66-69)", InferredTypeExpr (loc "verified/lib.rs(561,66-69)"), Shared, IdentTypeExpr (loc "verified/lib.rs(561,66-69)", None, "T")))), "$_223", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(561,71-74)", InferredTypeExpr (loc "verified/lib.rs(561,71-74)"), Shared, IdentTypeExpr (loc "verified/lib.rs(561,71-74)", None, "T"))), "$_224", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(316,1-579,2)", [(loc "verified/lib.rs(316,1-579,2)", Some (ConstTypeExpr (loc "verified/lib.rs(316,1-579,2)", RustRefTypeExpr (loc "verified/lib.rs(561,71-74)", InferredTypeExpr (loc "verified/lib.rs(561,71-74)"), Shared, IdentTypeExpr (loc "verified/lib.rs(561,71-74)", None, "T")))), "$_225", None, (ref (false), ref (None)))]);
      PureStmt (loc "verified/lib.rs(522,9-523,1)", ExprStmt (CallExpr (loc "verified/lib.rs(522,41-42)", "interior_pointer_limits", [IdentTypeExpr (loc "verified/lib.rs(522,39-40)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(522,42-48)", "v_base")); LitPat (IntLit (loc "verified/lib.rs(522,50-51)", big_int_of_string "4", true, false, NoLSuffix)); LitPat (CastExpr (loc "verified/lib.rs(522,56-58)", ManifestTypeExpr (loc "verified/lib.rs(522,59-64)", Int (Unsigned, PtrRank)), Var (loc "verified/lib.rs(522,53-55)", "c1")))], Static)));
      PureStmt (loc "verified/lib.rs(523,9-524,1)", ExprStmt (CallExpr (loc "verified/lib.rs(523,41-42)", "interior_pointer_limits", [IdentTypeExpr (loc "verified/lib.rs(523,39-40)", None, "T")], [], [
        LitPat (Var (loc "verified/lib.rs(523,42-48)", "v_base"));
        LitPat (IntLit (loc "verified/lib.rs(523,50-51)", big_int_of_string "4", true, false, NoLSuffix));
        LitPat (CastExpr (loc "verified/lib.rs(523,59-61)", ManifestTypeExpr (loc "verified/lib.rs(523,62-67)", Int (Unsigned, PtrRank)), Operation (loc "verified/lib.rs(523,54-55)", Not, [Var (loc "verified/lib.rs(523,55-57)", "c1")])))
      ], Static)));
      PureStmt (loc "verified/lib.rs(524,9-525,1)", ExprStmt (CallExpr (loc "verified/lib.rs(524,41-42)", "interior_pointer_limits", [IdentTypeExpr (loc "verified/lib.rs(524,39-40)", None, "T")], [], [
        LitPat (Var (loc "verified/lib.rs(524,42-48)", "v_base"));
        LitPat (IntLit (loc "verified/lib.rs(524,50-51)", big_int_of_string "4", true, false, NoLSuffix));
        LitPat (Operation (loc "verified/lib.rs(524,55-56)", Add, [IntLit (loc "verified/lib.rs(524,53-54)", big_int_of_string "2", true, false, NoLSuffix); CastExpr (loc "verified/lib.rs(524,60-62)", ManifestTypeExpr (loc "verified/lib.rs(524,63-68)", Int (Unsigned, PtrRank)), Var (loc "verified/lib.rs(524,57-59)", "c2"))]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(525,9-526,1)", ExprStmt (CallExpr (loc "verified/lib.rs(525,41-42)", "interior_pointer_limits", [IdentTypeExpr (loc "verified/lib.rs(525,39-40)", None, "T")], [], [
        LitPat (Var (loc "verified/lib.rs(525,42-48)", "v_base"));
        LitPat (IntLit (loc "verified/lib.rs(525,50-51)", big_int_of_string "4", true, false, NoLSuffix));
        LitPat (Operation (loc "verified/lib.rs(525,55-56)", Add, [
          IntLit (loc "verified/lib.rs(525,53-54)", big_int_of_string "2", true, false, NoLSuffix);
          CastExpr (loc "verified/lib.rs(525,62-64)", ManifestTypeExpr (loc "verified/lib.rs(525,65-70)", Int (Unsigned, PtrRank)), Operation (loc "verified/lib.rs(525,58-59)", Not, [Var (loc "verified/lib.rs(525,59-61)", "c2")]))
        ]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(526,9-527,1)", ExprStmt (CallExpr (loc "verified/lib.rs(526,37-38)", "split_selected_four", [IdentTypeExpr (loc "verified/lib.rs(526,35-36)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(526,38-44)", "v_base")); LitPat (Var (loc "verified/lib.rs(526,46-47)", "t")); LitPat (Var (loc "verified/lib.rs(526,49-51)", "c1")); LitPat (Var (loc "verified/lib.rs(526,53-55)", "c2"))], Static)));
      PureStmt (loc "verified/lib.rs(527,9-528,1)", ExprStmt (CallExpr (loc "verified/lib.rs(527,43-44)", "close_full_borrow_content", [IdentTypeExpr (loc "verified/lib.rs(527,41-42)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(527,44-45)", "t")); LitPat (Var (loc "verified/lib.rs(527,47-48)", "d"))], Static)));
      PureStmt (loc "verified/lib.rs(528,9-529,1)", ExprStmt (CallExpr (loc "verified/lib.rs(528,43-44)", "close_full_borrow_content", [IdentTypeExpr (loc "verified/lib.rs(528,41-42)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(528,44-45)", "t")); LitPat (Var (loc "verified/lib.rs(528,47-48)", "b"))], Static)));
      PureStmt (loc "verified/lib.rs(529,9-530,1)", ExprStmt (CallExpr (loc "verified/lib.rs(529,13-19)", "borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(529,20-26)", "cmp4_k"));
        LitPat (ExprCallExpr (loc "verified/lib.rs(529,51-52)", TypePredExpr (loc "verified/lib.rs(529,31-32)", IdentTypeExpr (loc "verified/lib.rs(529,29-30)", None, "T"), "full_borrow_content"), [LitPat (Var (loc "verified/lib.rs(529,52-53)", "t")); LitPat (Var (loc "verified/lib.rs(529,55-56)", "d"))]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(530,9-531,1)", ExprStmt (CallExpr (loc "verified/lib.rs(530,13-19)", "borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(530,20-26)", "cmp4_k"));
        LitPat (ExprCallExpr (loc "verified/lib.rs(530,51-52)", TypePredExpr (loc "verified/lib.rs(530,31-32)", IdentTypeExpr (loc "verified/lib.rs(530,29-30)", None, "T"), "full_borrow_content"), [LitPat (Var (loc "verified/lib.rs(530,52-53)", "t")); LitPat (Var (loc "verified/lib.rs(530,55-56)", "b"))]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(531,9-532,1)", ExprStmt (CallExpr (loc "verified/lib.rs(531,35-36)", "share_full_borrow", [IdentTypeExpr (loc "verified/lib.rs(531,33-34)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(531,36-42)", "cmp4_k")); LitPat (Var (loc "verified/lib.rs(531,44-45)", "t")); LitPat (Var (loc "verified/lib.rs(531,47-48)", "d"))], Static)));
      PureStmt (loc "verified/lib.rs(532,9-533,1)", ExprStmt (CallExpr (loc "verified/lib.rs(532,35-36)", "share_full_borrow", [IdentTypeExpr (loc "verified/lib.rs(532,33-34)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(532,36-42)", "cmp4_k")); LitPat (Var (loc "verified/lib.rs(532,44-45)", "t")); LitPat (Var (loc "verified/lib.rs(532,47-48)", "b"))], Static)));
      PureStmt (loc "verified/lib.rs(533,9-534,1)", DeclStmt (loc "verified/lib.rs(533,13-16)", [
        (loc "verified/lib.rs(533,17-26)", None, "left4_ref", Some (CallExpr (loc "verified/lib.rs(533,29-42)", "precreate_ref", [], [], [LitPat (Var (loc "verified/lib.rs(533,43-44)", "d"))], Static)), (ref (false), ref (None)))
      ]));
      PureStmt (loc "verified/lib.rs(534,9-535,1)", DeclStmt (loc "verified/lib.rs(534,13-16)", [
        (loc "verified/lib.rs(534,17-27)", None, "right4_ref", Some (CallExpr (loc "verified/lib.rs(534,30-43)", "precreate_ref", [], [], [LitPat (Var (loc "verified/lib.rs(534,44-45)", "b"))], Static)), (ref (false), ref (None)))
      ]));
      PureStmt (loc "verified/lib.rs(535,9-536,1)", ExprStmt (CallExpr (loc "verified/lib.rs(535,32-33)", "init_ref_share", [IdentTypeExpr (loc "verified/lib.rs(535,30-31)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(535,33-39)", "cmp4_k")); LitPat (Var (loc "verified/lib.rs(535,41-42)", "t")); LitPat (Var (loc "verified/lib.rs(535,44-53)", "left4_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(536,9-537,1)", ExprStmt (CallExpr (loc "verified/lib.rs(536,32-33)", "init_ref_share", [IdentTypeExpr (loc "verified/lib.rs(536,30-31)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(536,33-39)", "cmp4_k")); LitPat (Var (loc "verified/lib.rs(536,41-42)", "t")); LitPat (Var (loc "verified/lib.rs(536,44-54)", "right4_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(537,9-538,1)", ExprStmt (CallExpr (loc "verified/lib.rs(537,38-39)", "close_ref_own", [IdentTypeExpr (loc "verified/lib.rs(537,29-34)", None, "'cmp4"); IdentTypeExpr (loc "verified/lib.rs(537,36-37)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(537,39-48)", "left4_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(538,9-539,1)", ExprStmt (CallExpr (loc "verified/lib.rs(538,38-39)", "close_ref_own", [IdentTypeExpr (loc "verified/lib.rs(538,29-34)", None, "'cmp4"); IdentTypeExpr (loc "verified/lib.rs(538,36-37)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(538,39-49)", "right4_ref"))], Static)));
      PureStmt (loc "verified/lib.rs(539,9-540,1)", Close (loc "verified/lib.rs(539,13-18)", None, "std_tuple_2__own", [RustRefTypeExpr (loc "verified/lib.rs(539,21-22)", IdentTypeExpr (loc "verified/lib.rs(539,21-22)", None, "'cmp4"), Shared, IdentTypeExpr (loc "verified/lib.rs(539,28-29)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(539,31-32)", IdentTypeExpr (loc "verified/lib.rs(539,31-32)", None, "'cmp4"), Shared, IdentTypeExpr (loc "verified/lib.rs(539,38-39)", None, "T"))], [], [
        LitPat (Var (loc "verified/lib.rs(539,46-47)", "t"));
        LitPat (CastExpr (loc "verified/lib.rs(539,49-61)", StructTypeExpr (loc "verified/lib.rs(539,49-61)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(539,64-65)", IdentTypeExpr (loc "verified/lib.rs(539,64-65)", None, "'cmp4"), Shared, IdentTypeExpr (loc "verified/lib.rs(539,71-72)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(539,74-75)", IdentTypeExpr (loc "verified/lib.rs(539,74-75)", None, "'cmp4"), Shared, IdentTypeExpr (loc "verified/lib.rs(539,81-82)", None, "T"))]), InitializerList (loc "verified/lib.rs(539,49-61)", [(Some ((loc "verified/lib.rs(539,86-87)", "0")), Var (loc "verified/lib.rs(539,89-98)", "left4_ref")); (Some ((loc "verified/lib.rs(539,100-101)", "1")), Var (loc "verified/lib.rs(539,103-113)", "right4_ref"))])))
      ], None));
      PureStmt (loc "verified/lib.rs(540,9-541,1)", ExprStmt (CallExpr (loc "verified/lib.rs(540,13-29)", "open_frac_borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(540,30-36)", "cmp4_k"));
        LitPat (CallExpr (loc "verified/lib.rs(540,38-54)", "ref_initialized_", [], [], [LitPat (Var (loc "verified/lib.rs(540,55-64)", "left4_ref"))], Static));
        LitPat (Operation (loc "verified/lib.rs(540,68-69)", Div, [IntLit (loc "verified/lib.rs(540,67-68)", big_int_of_string "1", true, false, NoLSuffix); IntLit (loc "verified/lib.rs(540,69-70)", big_int_of_string "4", true, false, NoLSuffix)]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(541,9-542,1)", Open (loc "verified/lib.rs(541,13-17)", None, "ref_initialized_", [IdentTypeExpr (loc "verified/lib.rs(541,54-55)", None, "T")], [LitPat (Var (loc "verified/lib.rs(541,57-66)", "left4_ref"))], [], Some (VarPat (loc "verified/lib.rs(541,20-34)", "left4_fraction"))));
      PureStmt (loc "verified/lib.rs(542,9-543,1)", ExprStmt (CallExpr (loc "verified/lib.rs(542,13-29)", "open_frac_borrow", [], [], [
        LitPat (Var (loc "verified/lib.rs(542,30-36)", "cmp4_k"));
        LitPat (CallExpr (loc "verified/lib.rs(542,38-54)", "ref_initialized_", [], [], [LitPat (Var (loc "verified/lib.rs(542,55-65)", "right4_ref"))], Static));
        LitPat (Operation (loc "verified/lib.rs(542,69-70)", Div, [IntLit (loc "verified/lib.rs(542,68-69)", big_int_of_string "1", true, false, NoLSuffix); IntLit (loc "verified/lib.rs(542,70-71)", big_int_of_string "4", true, false, NoLSuffix)]))
      ], Static)));
      PureStmt (loc "verified/lib.rs(543,9-544,1)", Open (loc "verified/lib.rs(543,13-17)", None, "ref_initialized_", [IdentTypeExpr (loc "verified/lib.rs(543,55-56)", None, "T")], [LitPat (Var (loc "verified/lib.rs(543,58-68)", "right4_ref"))], [], Some (VarPat (loc "verified/lib.rs(543,20-35)", "right4_fraction"))));
      NoopStmt (loc "verified/lib.rs(544,1-560,14)");
      ExprStmt (AssignExpr (loc "verified/lib.rs(561,18-25)", Var (loc "verified/lib.rs(561,18-25)", "$_220"), Mutation, AddressOf (loc "verified/lib.rs(561,18-25)", Deref (loc "verified/lib.rs(561,18-25)", Var (loc "verified/lib.rs(561,18-25)", "is_less")))));
      ExprStmt (AssignExpr (loc "verified/lib.rs(561,66-69)", Var (loc "verified/lib.rs(561,66-69)", "$_223"), Initialization, CallExpr (loc "verified/lib.rs(561,66-69)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(561,66-69)", "create_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(561,66-69)", Deref (loc "verified/lib.rs(561,66-69)", Var (loc "verified/lib.rs(561,66-69)", "d"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(561,66-69)", Var (loc "verified/lib.rs(561,66-69)", "$_222"), Mutation, CallExpr (loc "verified/lib.rs(561,66-69)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(561,66-69)", "reborrow_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(561,66-69)", Deref (loc "verified/lib.rs(561,66-69)", Var (loc "verified/lib.rs(561,66-69)", "$_223"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(561,71-74)", Var (loc "verified/lib.rs(561,71-74)", "$_225"), Initialization, CallExpr (loc "verified/lib.rs(561,71-74)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(561,71-74)", "create_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(561,71-74)", Deref (loc "verified/lib.rs(561,71-74)", Var (loc "verified/lib.rs(561,71-74)", "b"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(561,71-74)", Var (loc "verified/lib.rs(561,71-74)", "$_224"), Mutation, CallExpr (loc "verified/lib.rs(561,71-74)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(561,71-74)", "reborrow_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(561,71-74)", Deref (loc "verified/lib.rs(561,71-74)", Var (loc "verified/lib.rs(561,71-74)", "$_225"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(561,18-75)", Select (loc "verified/lib.rs(561,18-75)", Var (loc "verified/lib.rs(561,18-75)", "$_221"), "0"), Mutation, Var (loc "verified/lib.rs(561,18-75)", "$_222")));
      ExprStmt (AssignExpr (loc "verified/lib.rs(561,18-75)", Select (loc "verified/lib.rs(561,18-75)", Var (loc "verified/lib.rs(561,18-75)", "$_221"), "1"), Mutation, Var (loc "verified/lib.rs(561,18-75)", "$_224")));
      ExprStmt (CallExpr (loc "verified/lib.rs(561,18-75)", "#register_type_projection_equality", [
        ProjectionTypeExpr (loc "verified/lib.rs(561,18-75)", IdentTypeExpr (loc "verified/lib.rs(561,31-32)", None, "F"), "std::ops::FnOnce", [
          StructTypeExpr (loc "verified/lib.rs(561,34-35)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(561,35-36)", IdentTypeExpr (loc "verified/lib.rs(561,35-36)", None, "'cmp4"), Shared, IdentTypeExpr (loc "verified/lib.rs(561,42-43)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(561,45-46)", IdentTypeExpr (loc "verified/lib.rs(561,45-46)", None, "'cmp4"), Shared, IdentTypeExpr (loc "verified/lib.rs(561,52-53)", None, "T"))])
        ], "Output");
        ManifestTypeExpr (loc "verified/lib.rs(561,18-75)", Bool)
      ], [], [], Static));
      SwitchStmt (loc "verified/lib.rs(561,18-75)", CallExpr (loc "verified/lib.rs(561,18-75)", "std::ops::FnMut::call_mut", [
        IdentTypeExpr (loc "verified/lib.rs(561,31-32)", None, "F");
        StructTypeExpr (loc "verified/lib.rs(561,34-35)", Some ("std_tuple_2_"), None, [], [RustRefTypeExpr (loc "verified/lib.rs(561,35-36)", IdentTypeExpr (loc "verified/lib.rs(561,35-36)", None, "'cmp4"), Shared, IdentTypeExpr (loc "verified/lib.rs(561,42-43)", None, "T")); RustRefTypeExpr (loc "verified/lib.rs(561,45-46)", IdentTypeExpr (loc "verified/lib.rs(561,45-46)", None, "'cmp4"), Shared, IdentTypeExpr (loc "verified/lib.rs(561,52-53)", None, "T"))]);
        IdentTypeExpr (loc "verified/lib.rs(561,56-61)", None, "'cmp4")
      ], [], [LitPat (Var (loc "verified/lib.rs(561,18-75)", "$_220")); LitPat (Var (loc "verified/lib.rs(561,18-75)", "$_221"))], Static), [
        SwitchStmtClause (loc "verified/lib.rs(561,18-75)", CallExpr (loc "verified/lib.rs(561,18-75)", "returning", [], [], [LitPat (Var (loc "verified/lib.rs(561,18-75)", "__result"))], Static), [ExprStmt (AssignExpr (loc "verified/lib.rs(561,18-75)", Var (loc "verified/lib.rs(561,18-75)", "c4"), Initialization, Var (loc "verified/lib.rs(561,18-75)", "__result")))]);
        SwitchStmtClause (loc "verified/lib.rs(561,18-75)", CallExpr (loc "verified/lib.rs(561,18-75)", "unwinding", [], [], [], Static), [
          PureStmt (loc "verified/lib.rs(546,15-20)", Close (loc "verified/lib.rs(546,15-20)", None, "comparison_debt", [IdentTypeExpr (loc "verified/lib.rs(546,39-40)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(546,42-43)", "t")); LitPat (Var (loc "verified/lib.rs(546,45-51)", "cmp4_k")); LitPat (Var (loc "verified/lib.rs(546,53-54)", "d")); LitPat (Var (loc "verified/lib.rs(546,56-57)", "b")); LitPat (Var (loc "verified/lib.rs(546,59-68)", "left4_ref")); LitPat (Var (loc "verified/lib.rs(546,70-80)", "right4_ref")); LitPat (Var (loc "verified/lib.rs(546,82-96)", "left4_fraction")); LitPat (Var (loc "verified/lib.rs(546,98-113)", "right4_fraction"))], None));
          GotoStmt (loc "verified/lib.rs(561,18-75)", "#native_c4_direct_unwind_4")
        ])
      ]);
      PureStmt (loc "verified/lib.rs(562,9-563,1)", Close (loc "verified/lib.rs(562,13-18)", None, "comparison_debt", [IdentTypeExpr (loc "verified/lib.rs(562,37-38)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(562,40-41)", "t")); LitPat (Var (loc "verified/lib.rs(562,43-49)", "cmp4_k")); LitPat (Var (loc "verified/lib.rs(562,51-52)", "d")); LitPat (Var (loc "verified/lib.rs(562,54-55)", "b")); LitPat (Var (loc "verified/lib.rs(562,57-66)", "left4_ref")); LitPat (Var (loc "verified/lib.rs(562,68-78)", "right4_ref")); LitPat (Var (loc "verified/lib.rs(562,80-94)", "left4_fraction")); LitPat (Var (loc "verified/lib.rs(562,96-111)", "right4_fraction"))], None))
    ], loc "verified/lib.rs(563,9-564,1)", ref ([]));
    NoopStmt (loc "verified/lib.rs(563,9-564,1)");
    PureStmt (loc "verified/lib.rs(564,9-565,1)", ExprStmt (CallExpr (loc "verified/lib.rs(564,30-31)", "recover_pair", [IdentTypeExpr (loc "verified/lib.rs(564,28-29)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(564,31-32)", "d")); LitPat (Var (loc "verified/lib.rs(564,34-35)", "b"))], Static)));
    PureStmt (loc "verified/lib.rs(565,9-566,1)", ExprStmt (CallExpr (loc "verified/lib.rs(565,36-37)", "join_selected_four", [IdentTypeExpr (loc "verified/lib.rs(565,34-35)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(565,37-43)", "v_base")); LitPat (Var (loc "verified/lib.rs(565,45-46)", "t")); LitPat (Var (loc "verified/lib.rs(565,48-50)", "c1")); LitPat (Var (loc "verified/lib.rs(565,52-54)", "c2"))], Static)));
    PureStmt (loc "verified/lib.rs(566,9-567,1)", Assert (loc "verified/lib.rs(566,13-19)", PointsTo (loc "verified/lib.rs(566,32-35)", ReadArray (loc "verified/lib.rs(566,26-27)", Var (loc "verified/lib.rs(566,20-26)", "v_base"), SliceExpr (loc "verified/lib.rs(566,27-29)", None, Some (LitPat (IntLit (loc "verified/lib.rs(566,29-30)", big_int_of_string "4", true, false, NoLSuffix))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(566,37-51)", "first_current4"))));
    PureStmt (loc "verified/lib.rs(567,9-568,1)", ExprStmt (CallExpr (loc "verified/lib.rs(567,28-29)", "array_join", [IdentTypeExpr (loc "verified/lib.rs(567,26-27)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(567,29-35)", "v_base"))], Static)));
    PureStmt (loc "verified/lib.rs(568,9-569,1)", ExprStmt (CallExpr (loc "verified/lib.rs(568,13-27)", "foreach_append", [], [], [
      LitPat (Var (loc "verified/lib.rs(568,28-42)", "first_current4"));
      LitPat (CallExpr (loc "verified/lib.rs(568,44-48)", "drop", [], [], [LitPat (IntLit (loc "verified/lib.rs(568,49-50)", big_int_of_string "4", true, false, NoLSuffix)); LitPat (Var (loc "verified/lib.rs(568,52-67)", "source_current3"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(569,9-570,1)", Assert (loc "verified/lib.rs(569,13-19)", PointsTo (loc "verified/lib.rs(569,34-37)", ReadArray (loc "verified/lib.rs(569,26-27)", Var (loc "verified/lib.rs(569,20-26)", "v_base"), SliceExpr (loc "verified/lib.rs(569,27-29)", None, Some (LitPat (Var (loc "verified/lib.rs(569,29-32)", "len"))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(569,39-54)", "source_current4"))));
    PureStmt (loc "verified/lib.rs(570,9-571,1)", Assert (loc "verified/lib.rs(570,13-19)", CallExpr (loc "verified/lib.rs(570,20-27)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(570,28-43)", "source_current4"));
      LitPat (CallExpr (loc "verified/lib.rs(570,53-54)", "own", [IdentTypeExpr (loc "verified/lib.rs(570,51-52)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(570,54-55)", "t"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(571,9-572,1)", Assert (loc "verified/lib.rs(571,13-19)", PointsTo (loc "verified/lib.rs(571,43-46)", ReadArray (loc "verified/lib.rs(571,27-28)", Var (loc "verified/lib.rs(571,20-27)", "mu_base"), SliceExpr (loc "verified/lib.rs(571,28-30)", None, Some (LitPat (Var (loc "verified/lib.rs(571,30-41)", "scratch_len"))))), "RegularPointsTo", LitPat (Var (loc "verified/lib.rs(571,47-53)", "mu_all")))));
    PureStmt (loc "verified/lib.rs(572,9-573,1)", Assert (loc "verified/lib.rs(572,13-19)", CallExpr (loc "verified/lib.rs(572,20-27)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(572,28-34)", "mu_all"));
      LitPat (CallExpr (loc "verified/lib.rs(572,67-68)", "own", [
        ConstructedTypeExpr (loc "verified/lib.rs(572,42-63)", "std::mem::MaybeUninit", [IdentTypeExpr (loc "verified/lib.rs(572,64-65)", None, "T")])
      ], [], [LitPat (Var (loc "verified/lib.rs(572,68-69)", "t"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(573,9-574,1)", Assert (loc "verified/lib.rs(573,13-19)", PointsTo (loc "verified/lib.rs(573,29-32)", Deref (loc "verified/lib.rs(573,20-21)", Var (loc "verified/lib.rs(573,21-28)", "is_less")), "RegularPointsTo", VarPat (loc "verified/lib.rs(573,34-47)", "less_current4"))));
    PureStmt (loc "verified/lib.rs(574,9-575,1)", Assert (loc "verified/lib.rs(574,13-19)", ExprCallExpr (loc "verified/lib.rs(574,27-28)", TypePredExpr (loc "verified/lib.rs(574,23-24)", IdentTypeExpr (loc "verified/lib.rs(574,21-22)", None, "F"), "own"), [LitPat (Var (loc "verified/lib.rs(574,28-29)", "t")); LitPat (Var (loc "verified/lib.rs(574,31-44)", "less_current4"))])));
    PureStmt (loc "verified/lib.rs(575,9-576,1)", Leak (loc "verified/lib.rs(575,13-17)", CallExpr (loc "verified/lib.rs(575,34-35)", "type_interp", [IdentTypeExpr (loc "verified/lib.rs(575,32-33)", None, "T")], [], [], Static)));
    PureStmt (loc "verified/lib.rs(576,9-577,1)", Leak (loc "verified/lib.rs(576,13-17)", CallExpr (loc "verified/lib.rs(576,34-35)", "type_interp", [IdentTypeExpr (loc "verified/lib.rs(576,32-33)", None, "F")], [], [], Static)));
    GotoStmt (loc "verified/lib.rs(577,9-40)", "189");
    LabelStmt (loc "verified/lib.rs(387,22-93)", "#native_c4_direct_unwind_1");
    PureStmt (loc "verified/lib.rs(373,36-37)", ExprStmt (CallExpr (loc "verified/lib.rs(373,36-37)", "recover_pair", [IdentTypeExpr (loc "verified/lib.rs(373,34-35)", None, "T")], [], [
      LitPat (Operation (loc "verified/lib.rs(373,44-45)", Add, [Var (loc "verified/lib.rs(373,37-43)", "v_base"); IntLit (loc "verified/lib.rs(373,46-47)", big_int_of_string "1", true, false, NoLSuffix)]));
      LitPat (Var (loc "verified/lib.rs(373,49-55)", "v_base"))
    ], Static)));
    PureStmt (loc "verified/lib.rs(374,45-46)", ExprStmt (CallExpr (loc "verified/lib.rs(374,45-46)", "join_four_owned_cells", [IdentTypeExpr (loc "verified/lib.rs(374,43-44)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(374,46-52)", "v_base")); LitPat (Var (loc "verified/lib.rs(374,54-55)", "t"))], Static)));
    PureStmt (loc "verified/lib.rs(375,19-25)", Assert (loc "verified/lib.rs(375,19-25)", PointsTo (loc "verified/lib.rs(375,38-41)", ReadArray (loc "verified/lib.rs(375,32-33)", Var (loc "verified/lib.rs(375,26-32)", "v_base"), SliceExpr (loc "verified/lib.rs(375,33-35)", None, Some (LitPat (IntLit (loc "verified/lib.rs(375,35-36)", big_int_of_string "4", true, false, NoLSuffix))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(375,43-56)", "first_current"))));
    PureStmt (loc "verified/lib.rs(376,34-35)", ExprStmt (CallExpr (loc "verified/lib.rs(376,34-35)", "array_join", [IdentTypeExpr (loc "verified/lib.rs(376,32-33)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(376,35-41)", "v_base"))], Static)));
    PureStmt (loc "verified/lib.rs(377,19-33)", ExprStmt (CallExpr (loc "verified/lib.rs(377,19-33)", "foreach_append", [], [], [
      LitPat (Var (loc "verified/lib.rs(377,34-47)", "first_current"));
      LitPat (CallExpr (loc "verified/lib.rs(377,49-53)", "drop", [], [], [LitPat (IntLit (loc "verified/lib.rs(377,54-55)", big_int_of_string "4", true, false, NoLSuffix)); LitPat (Var (loc "verified/lib.rs(377,57-67)", "source_all"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(378,19-25)", Assert (loc "verified/lib.rs(378,19-25)", PointsTo (loc "verified/lib.rs(378,40-43)", ReadArray (loc "verified/lib.rs(378,32-33)", Var (loc "verified/lib.rs(378,26-32)", "v_base"), SliceExpr (loc "verified/lib.rs(378,33-35)", None, Some (LitPat (Var (loc "verified/lib.rs(378,35-38)", "len"))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(378,45-59)", "source_current"))));
    PureStmt (loc "verified/lib.rs(379,19-25)", Assert (loc "verified/lib.rs(379,19-25)", CallExpr (loc "verified/lib.rs(379,26-33)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(379,34-48)", "source_current"));
      LitPat (CallExpr (loc "verified/lib.rs(379,58-59)", "own", [IdentTypeExpr (loc "verified/lib.rs(379,56-57)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(379,59-60)", "t"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(380,19-25)", Assert (loc "verified/lib.rs(380,19-25)", PointsTo (loc "verified/lib.rs(380,49-52)", ReadArray (loc "verified/lib.rs(380,33-34)", Var (loc "verified/lib.rs(380,26-33)", "mu_base"), SliceExpr (loc "verified/lib.rs(380,34-36)", None, Some (LitPat (Var (loc "verified/lib.rs(380,36-47)", "scratch_len"))))), "RegularPointsTo", LitPat (Var (loc "verified/lib.rs(380,53-59)", "mu_all")))));
    PureStmt (loc "verified/lib.rs(381,19-25)", Assert (loc "verified/lib.rs(381,19-25)", CallExpr (loc "verified/lib.rs(381,26-33)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(381,34-40)", "mu_all"));
      LitPat (CallExpr (loc "verified/lib.rs(381,73-74)", "own", [
        ConstructedTypeExpr (loc "verified/lib.rs(381,48-69)", "std::mem::MaybeUninit", [IdentTypeExpr (loc "verified/lib.rs(381,70-71)", None, "T")])
      ], [], [LitPat (Var (loc "verified/lib.rs(381,74-75)", "t"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(382,19-25)", Assert (loc "verified/lib.rs(382,19-25)", PointsTo (loc "verified/lib.rs(382,35-38)", Deref (loc "verified/lib.rs(382,26-27)", Var (loc "verified/lib.rs(382,27-34)", "is_less")), "RegularPointsTo", VarPat (loc "verified/lib.rs(382,40-52)", "less_current"))));
    PureStmt (loc "verified/lib.rs(383,19-25)", Assert (loc "verified/lib.rs(383,19-25)", ExprCallExpr (loc "verified/lib.rs(383,33-34)", TypePredExpr (loc "verified/lib.rs(383,29-30)", IdentTypeExpr (loc "verified/lib.rs(383,27-28)", None, "F"), "own"), [LitPat (Var (loc "verified/lib.rs(383,34-35)", "t")); LitPat (Var (loc "verified/lib.rs(383,37-49)", "less_current"))])));
    PureStmt (loc "verified/lib.rs(384,19-23)", Leak (loc "verified/lib.rs(384,19-23)", CallExpr (loc "verified/lib.rs(384,40-41)", "type_interp", [IdentTypeExpr (loc "verified/lib.rs(384,38-39)", None, "T")], [], [], Static)));
    PureStmt (loc "verified/lib.rs(385,19-23)", Leak (loc "verified/lib.rs(385,19-23)", CallExpr (loc "verified/lib.rs(385,40-41)", "type_interp", [IdentTypeExpr (loc "verified/lib.rs(385,38-39)", None, "F")], [], [], Static)));
    ReturnStmt (loc "verified/lib.rs(387,22-93)", Some (CallExpr (loc "verified/lib.rs(387,22-93)", "unwinding", [], [], [], Static)));
    LabelStmt (loc "verified/lib.rs(442,18-99)", "#native_c4_direct_unwind_2");
    PureStmt (loc "verified/lib.rs(428,32-33)", ExprStmt (CallExpr (loc "verified/lib.rs(428,32-33)", "recover_pair", [IdentTypeExpr (loc "verified/lib.rs(428,30-31)", None, "T")], [], [
      LitPat (Operation (loc "verified/lib.rs(428,40-41)", Add, [Var (loc "verified/lib.rs(428,33-39)", "v_base"); IntLit (loc "verified/lib.rs(428,42-43)", big_int_of_string "3", true, false, NoLSuffix)]));
      LitPat (Operation (loc "verified/lib.rs(428,52-53)", Add, [Var (loc "verified/lib.rs(428,45-51)", "v_base"); IntLit (loc "verified/lib.rs(428,54-55)", big_int_of_string "2", true, false, NoLSuffix)]))
    ], Static)));
    PureStmt (loc "verified/lib.rs(429,41-42)", ExprStmt (CallExpr (loc "verified/lib.rs(429,41-42)", "join_four_owned_cells", [IdentTypeExpr (loc "verified/lib.rs(429,39-40)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(429,42-48)", "v_base")); LitPat (Var (loc "verified/lib.rs(429,50-51)", "t"))], Static)));
    PureStmt (loc "verified/lib.rs(430,15-21)", Assert (loc "verified/lib.rs(430,15-21)", PointsTo (loc "verified/lib.rs(430,34-37)", ReadArray (loc "verified/lib.rs(430,28-29)", Var (loc "verified/lib.rs(430,22-28)", "v_base"), SliceExpr (loc "verified/lib.rs(430,29-31)", None, Some (LitPat (IntLit (loc "verified/lib.rs(430,31-32)", big_int_of_string "4", true, false, NoLSuffix))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(430,39-53)", "first_current2"))));
    PureStmt (loc "verified/lib.rs(431,30-31)", ExprStmt (CallExpr (loc "verified/lib.rs(431,30-31)", "array_join", [IdentTypeExpr (loc "verified/lib.rs(431,28-29)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(431,31-37)", "v_base"))], Static)));
    PureStmt (loc "verified/lib.rs(432,15-29)", ExprStmt (CallExpr (loc "verified/lib.rs(432,15-29)", "foreach_append", [], [], [
      LitPat (Var (loc "verified/lib.rs(432,30-44)", "first_current2"));
      LitPat (CallExpr (loc "verified/lib.rs(432,46-50)", "drop", [], [], [LitPat (IntLit (loc "verified/lib.rs(432,51-52)", big_int_of_string "4", true, false, NoLSuffix)); LitPat (Var (loc "verified/lib.rs(432,54-68)", "source_current"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(433,15-21)", Assert (loc "verified/lib.rs(433,15-21)", PointsTo (loc "verified/lib.rs(433,36-39)", ReadArray (loc "verified/lib.rs(433,28-29)", Var (loc "verified/lib.rs(433,22-28)", "v_base"), SliceExpr (loc "verified/lib.rs(433,29-31)", None, Some (LitPat (Var (loc "verified/lib.rs(433,31-34)", "len"))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(433,41-56)", "source_current2"))));
    PureStmt (loc "verified/lib.rs(434,15-21)", Assert (loc "verified/lib.rs(434,15-21)", CallExpr (loc "verified/lib.rs(434,22-29)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(434,30-45)", "source_current2"));
      LitPat (CallExpr (loc "verified/lib.rs(434,55-56)", "own", [IdentTypeExpr (loc "verified/lib.rs(434,53-54)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(434,56-57)", "t"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(435,15-21)", Assert (loc "verified/lib.rs(435,15-21)", PointsTo (loc "verified/lib.rs(435,45-48)", ReadArray (loc "verified/lib.rs(435,29-30)", Var (loc "verified/lib.rs(435,22-29)", "mu_base"), SliceExpr (loc "verified/lib.rs(435,30-32)", None, Some (LitPat (Var (loc "verified/lib.rs(435,32-43)", "scratch_len"))))), "RegularPointsTo", LitPat (Var (loc "verified/lib.rs(435,49-55)", "mu_all")))));
    PureStmt (loc "verified/lib.rs(436,15-21)", Assert (loc "verified/lib.rs(436,15-21)", CallExpr (loc "verified/lib.rs(436,22-29)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(436,30-36)", "mu_all"));
      LitPat (CallExpr (loc "verified/lib.rs(436,69-70)", "own", [
        ConstructedTypeExpr (loc "verified/lib.rs(436,44-65)", "std::mem::MaybeUninit", [IdentTypeExpr (loc "verified/lib.rs(436,66-67)", None, "T")])
      ], [], [LitPat (Var (loc "verified/lib.rs(436,70-71)", "t"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(437,15-21)", Assert (loc "verified/lib.rs(437,15-21)", PointsTo (loc "verified/lib.rs(437,31-34)", Deref (loc "verified/lib.rs(437,22-23)", Var (loc "verified/lib.rs(437,23-30)", "is_less")), "RegularPointsTo", VarPat (loc "verified/lib.rs(437,36-49)", "less_current2"))));
    PureStmt (loc "verified/lib.rs(438,15-21)", Assert (loc "verified/lib.rs(438,15-21)", ExprCallExpr (loc "verified/lib.rs(438,29-30)", TypePredExpr (loc "verified/lib.rs(438,25-26)", IdentTypeExpr (loc "verified/lib.rs(438,23-24)", None, "F"), "own"), [LitPat (Var (loc "verified/lib.rs(438,30-31)", "t")); LitPat (Var (loc "verified/lib.rs(438,33-46)", "less_current2"))])));
    PureStmt (loc "verified/lib.rs(439,15-19)", Leak (loc "verified/lib.rs(439,15-19)", CallExpr (loc "verified/lib.rs(439,36-37)", "type_interp", [IdentTypeExpr (loc "verified/lib.rs(439,34-35)", None, "T")], [], [], Static)));
    PureStmt (loc "verified/lib.rs(440,15-19)", Leak (loc "verified/lib.rs(440,15-19)", CallExpr (loc "verified/lib.rs(440,36-37)", "type_interp", [IdentTypeExpr (loc "verified/lib.rs(440,34-35)", None, "F")], [], [], Static)));
    ReturnStmt (loc "verified/lib.rs(442,18-99)", Some (CallExpr (loc "verified/lib.rs(442,18-99)", "unwinding", [], [], [], Static)));
    LabelStmt (loc "verified/lib.rs(504,18-75)", "#native_c4_direct_unwind_3");
    PureStmt (loc "verified/lib.rs(490,32-33)", ExprStmt (CallExpr (loc "verified/lib.rs(490,32-33)", "recover_pair", [IdentTypeExpr (loc "verified/lib.rs(490,30-31)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(490,33-34)", "c")); LitPat (Var (loc "verified/lib.rs(490,36-37)", "a"))], Static)));
    PureStmt (loc "verified/lib.rs(491,38-39)", ExprStmt (CallExpr (loc "verified/lib.rs(491,38-39)", "join_selected_four", [IdentTypeExpr (loc "verified/lib.rs(491,36-37)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(491,39-45)", "v_base")); LitPat (Var (loc "verified/lib.rs(491,47-48)", "t")); LitPat (Var (loc "verified/lib.rs(491,50-52)", "c1")); LitPat (Var (loc "verified/lib.rs(491,54-56)", "c2"))], Static)));
    PureStmt (loc "verified/lib.rs(492,15-21)", Assert (loc "verified/lib.rs(492,15-21)", PointsTo (loc "verified/lib.rs(492,34-37)", ReadArray (loc "verified/lib.rs(492,28-29)", Var (loc "verified/lib.rs(492,22-28)", "v_base"), SliceExpr (loc "verified/lib.rs(492,29-31)", None, Some (LitPat (IntLit (loc "verified/lib.rs(492,31-32)", big_int_of_string "4", true, false, NoLSuffix))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(492,39-53)", "first_current3"))));
    PureStmt (loc "verified/lib.rs(493,30-31)", ExprStmt (CallExpr (loc "verified/lib.rs(493,30-31)", "array_join", [IdentTypeExpr (loc "verified/lib.rs(493,28-29)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(493,31-37)", "v_base"))], Static)));
    PureStmt (loc "verified/lib.rs(494,15-29)", ExprStmt (CallExpr (loc "verified/lib.rs(494,15-29)", "foreach_append", [], [], [
      LitPat (Var (loc "verified/lib.rs(494,30-44)", "first_current3"));
      LitPat (CallExpr (loc "verified/lib.rs(494,46-50)", "drop", [], [], [LitPat (IntLit (loc "verified/lib.rs(494,51-52)", big_int_of_string "4", true, false, NoLSuffix)); LitPat (Var (loc "verified/lib.rs(494,54-69)", "source_current2"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(495,15-21)", Assert (loc "verified/lib.rs(495,15-21)", PointsTo (loc "verified/lib.rs(495,36-39)", ReadArray (loc "verified/lib.rs(495,28-29)", Var (loc "verified/lib.rs(495,22-28)", "v_base"), SliceExpr (loc "verified/lib.rs(495,29-31)", None, Some (LitPat (Var (loc "verified/lib.rs(495,31-34)", "len"))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(495,41-56)", "source_current3"))));
    PureStmt (loc "verified/lib.rs(496,15-21)", Assert (loc "verified/lib.rs(496,15-21)", CallExpr (loc "verified/lib.rs(496,22-29)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(496,30-45)", "source_current3"));
      LitPat (CallExpr (loc "verified/lib.rs(496,55-56)", "own", [IdentTypeExpr (loc "verified/lib.rs(496,53-54)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(496,56-57)", "t"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(497,15-21)", Assert (loc "verified/lib.rs(497,15-21)", PointsTo (loc "verified/lib.rs(497,45-48)", ReadArray (loc "verified/lib.rs(497,29-30)", Var (loc "verified/lib.rs(497,22-29)", "mu_base"), SliceExpr (loc "verified/lib.rs(497,30-32)", None, Some (LitPat (Var (loc "verified/lib.rs(497,32-43)", "scratch_len"))))), "RegularPointsTo", LitPat (Var (loc "verified/lib.rs(497,49-55)", "mu_all")))));
    PureStmt (loc "verified/lib.rs(498,15-21)", Assert (loc "verified/lib.rs(498,15-21)", CallExpr (loc "verified/lib.rs(498,22-29)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(498,30-36)", "mu_all"));
      LitPat (CallExpr (loc "verified/lib.rs(498,69-70)", "own", [
        ConstructedTypeExpr (loc "verified/lib.rs(498,44-65)", "std::mem::MaybeUninit", [IdentTypeExpr (loc "verified/lib.rs(498,66-67)", None, "T")])
      ], [], [LitPat (Var (loc "verified/lib.rs(498,70-71)", "t"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(499,15-21)", Assert (loc "verified/lib.rs(499,15-21)", PointsTo (loc "verified/lib.rs(499,31-34)", Deref (loc "verified/lib.rs(499,22-23)", Var (loc "verified/lib.rs(499,23-30)", "is_less")), "RegularPointsTo", VarPat (loc "verified/lib.rs(499,36-49)", "less_current3"))));
    PureStmt (loc "verified/lib.rs(500,15-21)", Assert (loc "verified/lib.rs(500,15-21)", ExprCallExpr (loc "verified/lib.rs(500,29-30)", TypePredExpr (loc "verified/lib.rs(500,25-26)", IdentTypeExpr (loc "verified/lib.rs(500,23-24)", None, "F"), "own"), [LitPat (Var (loc "verified/lib.rs(500,30-31)", "t")); LitPat (Var (loc "verified/lib.rs(500,33-46)", "less_current3"))])));
    PureStmt (loc "verified/lib.rs(501,15-19)", Leak (loc "verified/lib.rs(501,15-19)", CallExpr (loc "verified/lib.rs(501,36-37)", "type_interp", [IdentTypeExpr (loc "verified/lib.rs(501,34-35)", None, "T")], [], [], Static)));
    PureStmt (loc "verified/lib.rs(502,15-19)", Leak (loc "verified/lib.rs(502,15-19)", CallExpr (loc "verified/lib.rs(502,36-37)", "type_interp", [IdentTypeExpr (loc "verified/lib.rs(502,34-35)", None, "F")], [], [], Static)));
    ReturnStmt (loc "verified/lib.rs(504,18-75)", Some (CallExpr (loc "verified/lib.rs(504,18-75)", "unwinding", [], [], [], Static)));
    LabelStmt (loc "verified/lib.rs(561,18-75)", "#native_c4_direct_unwind_4");
    PureStmt (loc "verified/lib.rs(547,32-33)", ExprStmt (CallExpr (loc "verified/lib.rs(547,32-33)", "recover_pair", [IdentTypeExpr (loc "verified/lib.rs(547,30-31)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(547,33-34)", "d")); LitPat (Var (loc "verified/lib.rs(547,36-37)", "b"))], Static)));
    PureStmt (loc "verified/lib.rs(548,38-39)", ExprStmt (CallExpr (loc "verified/lib.rs(548,38-39)", "join_selected_four", [IdentTypeExpr (loc "verified/lib.rs(548,36-37)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(548,39-45)", "v_base")); LitPat (Var (loc "verified/lib.rs(548,47-48)", "t")); LitPat (Var (loc "verified/lib.rs(548,50-52)", "c1")); LitPat (Var (loc "verified/lib.rs(548,54-56)", "c2"))], Static)));
    PureStmt (loc "verified/lib.rs(549,15-21)", Assert (loc "verified/lib.rs(549,15-21)", PointsTo (loc "verified/lib.rs(549,34-37)", ReadArray (loc "verified/lib.rs(549,28-29)", Var (loc "verified/lib.rs(549,22-28)", "v_base"), SliceExpr (loc "verified/lib.rs(549,29-31)", None, Some (LitPat (IntLit (loc "verified/lib.rs(549,31-32)", big_int_of_string "4", true, false, NoLSuffix))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(549,39-53)", "first_current4"))));
    PureStmt (loc "verified/lib.rs(550,30-31)", ExprStmt (CallExpr (loc "verified/lib.rs(550,30-31)", "array_join", [IdentTypeExpr (loc "verified/lib.rs(550,28-29)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(550,31-37)", "v_base"))], Static)));
    PureStmt (loc "verified/lib.rs(551,15-29)", ExprStmt (CallExpr (loc "verified/lib.rs(551,15-29)", "foreach_append", [], [], [
      LitPat (Var (loc "verified/lib.rs(551,30-44)", "first_current4"));
      LitPat (CallExpr (loc "verified/lib.rs(551,46-50)", "drop", [], [], [LitPat (IntLit (loc "verified/lib.rs(551,51-52)", big_int_of_string "4", true, false, NoLSuffix)); LitPat (Var (loc "verified/lib.rs(551,54-69)", "source_current3"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(552,15-21)", Assert (loc "verified/lib.rs(552,15-21)", PointsTo (loc "verified/lib.rs(552,36-39)", ReadArray (loc "verified/lib.rs(552,28-29)", Var (loc "verified/lib.rs(552,22-28)", "v_base"), SliceExpr (loc "verified/lib.rs(552,29-31)", None, Some (LitPat (Var (loc "verified/lib.rs(552,31-34)", "len"))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(552,41-56)", "source_current4"))));
    PureStmt (loc "verified/lib.rs(553,15-21)", Assert (loc "verified/lib.rs(553,15-21)", CallExpr (loc "verified/lib.rs(553,22-29)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(553,30-45)", "source_current4"));
      LitPat (CallExpr (loc "verified/lib.rs(553,55-56)", "own", [IdentTypeExpr (loc "verified/lib.rs(553,53-54)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(553,56-57)", "t"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(554,15-21)", Assert (loc "verified/lib.rs(554,15-21)", PointsTo (loc "verified/lib.rs(554,45-48)", ReadArray (loc "verified/lib.rs(554,29-30)", Var (loc "verified/lib.rs(554,22-29)", "mu_base"), SliceExpr (loc "verified/lib.rs(554,30-32)", None, Some (LitPat (Var (loc "verified/lib.rs(554,32-43)", "scratch_len"))))), "RegularPointsTo", LitPat (Var (loc "verified/lib.rs(554,49-55)", "mu_all")))));
    PureStmt (loc "verified/lib.rs(555,15-21)", Assert (loc "verified/lib.rs(555,15-21)", CallExpr (loc "verified/lib.rs(555,22-29)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(555,30-36)", "mu_all"));
      LitPat (CallExpr (loc "verified/lib.rs(555,69-70)", "own", [
        ConstructedTypeExpr (loc "verified/lib.rs(555,44-65)", "std::mem::MaybeUninit", [IdentTypeExpr (loc "verified/lib.rs(555,66-67)", None, "T")])
      ], [], [LitPat (Var (loc "verified/lib.rs(555,70-71)", "t"))], Static))
    ], Static)));
    PureStmt (loc "verified/lib.rs(556,15-21)", Assert (loc "verified/lib.rs(556,15-21)", PointsTo (loc "verified/lib.rs(556,31-34)", Deref (loc "verified/lib.rs(556,22-23)", Var (loc "verified/lib.rs(556,23-30)", "is_less")), "RegularPointsTo", VarPat (loc "verified/lib.rs(556,36-49)", "less_current4"))));
    PureStmt (loc "verified/lib.rs(557,15-21)", Assert (loc "verified/lib.rs(557,15-21)", ExprCallExpr (loc "verified/lib.rs(557,29-30)", TypePredExpr (loc "verified/lib.rs(557,25-26)", IdentTypeExpr (loc "verified/lib.rs(557,23-24)", None, "F"), "own"), [LitPat (Var (loc "verified/lib.rs(557,30-31)", "t")); LitPat (Var (loc "verified/lib.rs(557,33-46)", "less_current4"))])));
    PureStmt (loc "verified/lib.rs(558,15-19)", Leak (loc "verified/lib.rs(558,15-19)", CallExpr (loc "verified/lib.rs(558,36-37)", "type_interp", [IdentTypeExpr (loc "verified/lib.rs(558,34-35)", None, "T")], [], [], Static)));
    PureStmt (loc "verified/lib.rs(559,15-19)", Leak (loc "verified/lib.rs(559,15-19)", CallExpr (loc "verified/lib.rs(559,36-37)", "type_interp", [IdentTypeExpr (loc "verified/lib.rs(559,34-35)", None, "F")], [], [], Static)));
    ReturnStmt (loc "verified/lib.rs(561,18-75)", Some (CallExpr (loc "verified/lib.rs(561,18-75)", "unwinding", [], [], [], Static)))
  ], loc "verified/lib.rs(577,9-10)", ref ([]));
  LabelStmt (loc "verified/lib.rs(330,5-578,6)", "189");
  GotoStmt (loc "verified/lib.rs(330,5-578,6)", "190");
  LabelStmt (loc "verified/lib.rs(579,2)", "190");
  GotoStmt (loc "verified/lib.rs(579,2)", "191");
  LabelStmt (loc "verified/lib.rs(579,2)", "3");
  GotoStmt (loc "verified/lib.rs(579,2)", "191");
  LabelStmt (loc "verified/lib.rs(579,2)", "191");
  ReturnStmt (loc "verified/lib.rs(579,2)", Some (CallExpr (loc "verified/lib.rs(579,2)", "returning", [], [], [LitPat (Var (loc "verified/lib.rs(579,2)", "$_0"))], Static)))
], loc "verified/lib.rs(579,1-2)")), false, [])