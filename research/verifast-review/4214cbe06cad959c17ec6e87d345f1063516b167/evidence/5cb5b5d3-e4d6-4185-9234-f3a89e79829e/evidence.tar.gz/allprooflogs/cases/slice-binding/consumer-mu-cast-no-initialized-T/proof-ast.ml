[
  PackageDecl (loc "<dummy location>", "", [], [
    Func (loc "verified/lib.rs(10,1-19,2)", Regular, [("T", (true)); ("'__18", (false)); ("'__19", (false))], Some (ConstructedTypeExpr (loc "verified/lib.rs(10,81)", "fn_outcome", [ManifestTypeExpr (loc "verified/lib.rs(10,81)", StructType ("std_tuple_0_", []))])), "native_slice_pointer_consumer", [
      (ConstTypeExpr (loc "verified/lib.rs(10,37-38)", RustRefTypeExpr (loc "verified/lib.rs(10,37-38)", IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "'__18"), Mutable, SliceTypeExpr (loc "verified/lib.rs(10,37-38)", IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")))), "v");
      (ConstTypeExpr (loc "verified/lib.rs(10,50-57)", RustRefTypeExpr (loc "verified/lib.rs(10,50-57)", IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "'__19"), Mutable, SliceTypeExpr (loc "verified/lib.rs(10,50-57)", StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])))), "scratch")
    ], false, (None, None), Some ((Sep (loc "verified/lib.rs(10,1-81)", Sep (loc "verified/lib.rs(10,1-81)", CallExpr (loc "verified/lib.rs(10,1-81)", "thread_token", [], [], [VarPat (loc "verified/lib.rs(10,1-81)", "_t")], Static), Operation (loc "verified/lib.rs(10,1-81)", Eq, [Var (loc "verified/lib.rs(10,1-81)", "_t"); Var (loc "verified/lib.rs(10,1-81)", "currentThread")])), Sep (loc "verified/lib.rs(10,37-38)", Sep (loc "verified/lib.rs(10,37-38)", CallExpr (loc "verified/lib.rs(10,37-38)", "array", [IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")], [], [
      LitPat (CastExpr (loc "verified/lib.rs(10,37-38)", PtrTypeExpr (loc "verified/lib.rs(10,37-38)", IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")), CallExpr (loc "verified/lib.rs(10,37-38)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(10,37-38)", ManifestTypeExpr (loc "verified/lib.rs(10,37-38)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(10,37-38)", "v")))], Static)));
      LitPat (CallExpr (loc "verified/lib.rs(10,37-38)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(10,37-38)", "v"))], Static));
      VarPat (loc "verified/lib.rs(10,37-38)", "_v0_v")
    ], Static), CallExpr (loc "verified/lib.rs(10,37-38)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(10,37-38)", "_v0_v"));
      LitPat (CallExpr (loc "verified/lib.rs(10,37-38)", "own", [IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(10,37-38)", "_t"))], Static))
    ], Static)), Sep (loc "verified/lib.rs(10,50-57)", Sep (loc "verified/lib.rs(10,50-57)", CallExpr (loc "verified/lib.rs(10,50-57)", "array", [
      StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])
    ], [], [
      LitPat (CastExpr (loc "verified/lib.rs(10,50-57)", PtrTypeExpr (loc "verified/lib.rs(10,50-57)", StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])), CallExpr (loc "verified/lib.rs(10,50-57)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(10,50-57)", ManifestTypeExpr (loc "verified/lib.rs(10,50-57)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(10,50-57)", "scratch")))], Static)));
      LitPat (CallExpr (loc "verified/lib.rs(10,50-57)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(10,50-57)", "scratch"))], Static));
      VarPat (loc "verified/lib.rs(10,50-57)", "_v0_scratch")
    ], Static), CallExpr (loc "verified/lib.rs(10,50-57)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(10,50-57)", "_v0_scratch"));
      LitPat (CallExpr (loc "verified/lib.rs(10,50-57)", "own", [
        StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])
      ], [], [LitPat (Var (loc "verified/lib.rs(10,50-57)", "_t"))], Static))
    ], Static)), Sep (loc "verified/lib.rs(10,1-81)", CoefAsn (loc "verified/lib.rs(10,1-81)", VarPat (loc "verified/lib.rs(10,1-81)", "_q___18"), CallExpr (loc "verified/lib.rs(10,1-81)", "lifetime_token", [], [], [
      LitPat (CallExpr (loc "verified/lib.rs(10,1-81)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(10,1-81)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(10,1-81)", None, "'__18"))))], Static))
    ], Static)), CoefAsn (loc "verified/lib.rs(10,1-81)", VarPat (loc "verified/lib.rs(10,1-81)", "_q___19"), CallExpr (loc "verified/lib.rs(10,1-81)", "lifetime_token", [], [], [
      LitPat (CallExpr (loc "verified/lib.rs(10,1-81)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(10,1-81)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(10,1-81)", None, "'__19"))))], Static))
    ], Static)))))), ("outcome", SwitchExpr (loc "verified/lib.rs(10,1-81)", Var (loc "verified/lib.rs(10,1-81)", "outcome"), [
      SwitchExprClause (loc "verified/lib.rs(10,1-81)", "returning", ["result"], Sep (loc "verified/lib.rs(10,1-81)", CallExpr (loc "verified/lib.rs(10,1-81)", "thread_token", [], [], [LitPat (Var (loc "verified/lib.rs(10,1-81)", "_t"))], Static), Sep (loc "verified/lib.rs(10,1-81)", CoefAsn (loc "verified/lib.rs(10,1-81)", LitPat (Var (loc "verified/lib.rs(10,1-81)", "_q___18")), CallExpr (loc "verified/lib.rs(10,1-81)", "lifetime_token", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(10,1-81)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(10,1-81)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(10,1-81)", None, "'__18"))))], Static))
      ], Static)), Sep (loc "verified/lib.rs(10,1-81)", CoefAsn (loc "verified/lib.rs(10,1-81)", LitPat (Var (loc "verified/lib.rs(10,1-81)", "_q___19")), CallExpr (loc "verified/lib.rs(10,1-81)", "lifetime_token", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(10,1-81)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(10,1-81)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(10,1-81)", None, "'__19"))))], Static))
      ], Static)), Sep (loc "verified/lib.rs(10,37-38)", Sep (loc "verified/lib.rs(10,37-38)", CallExpr (loc "verified/lib.rs(10,37-38)", "array", [IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")], [], [
        LitPat (CastExpr (loc "verified/lib.rs(10,37-38)", PtrTypeExpr (loc "verified/lib.rs(10,37-38)", IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")), CallExpr (loc "verified/lib.rs(10,37-38)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(10,37-38)", ManifestTypeExpr (loc "verified/lib.rs(10,37-38)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(10,37-38)", "v")))], Static)));
        LitPat (CallExpr (loc "verified/lib.rs(10,37-38)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(10,37-38)", "v"))], Static));
        VarPat (loc "verified/lib.rs(10,37-38)", "_v1_v")
      ], Static), CallExpr (loc "verified/lib.rs(10,37-38)", "foreach", [], [], [
        LitPat (Var (loc "verified/lib.rs(10,37-38)", "_v1_v"));
        LitPat (CallExpr (loc "verified/lib.rs(10,37-38)", "own", [IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(10,37-38)", "_t"))], Static))
      ], Static)), Sep (loc "verified/lib.rs(10,50-57)", Sep (loc "verified/lib.rs(10,50-57)", CallExpr (loc "verified/lib.rs(10,50-57)", "array", [
        StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])
      ], [], [
        LitPat (CastExpr (loc "verified/lib.rs(10,50-57)", PtrTypeExpr (loc "verified/lib.rs(10,50-57)", StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])), CallExpr (loc "verified/lib.rs(10,50-57)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(10,50-57)", ManifestTypeExpr (loc "verified/lib.rs(10,50-57)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(10,50-57)", "scratch")))], Static)));
        LitPat (CallExpr (loc "verified/lib.rs(10,50-57)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(10,50-57)", "scratch"))], Static));
        VarPat (loc "verified/lib.rs(10,50-57)", "_v1_scratch")
      ], Static), CallExpr (loc "verified/lib.rs(10,50-57)", "foreach", [], [], [
        LitPat (Var (loc "verified/lib.rs(10,50-57)", "_v1_scratch"));
        LitPat (CallExpr (loc "verified/lib.rs(10,50-57)", "own", [
          StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])
        ], [], [LitPat (Var (loc "verified/lib.rs(10,50-57)", "_t"))], Static))
      ], Static)), True (loc "verified/lib.rs(10,81)")))))));
      SwitchExprClause (loc "verified/lib.rs(10,1-81)", "unwinding", [], Sep (loc "verified/lib.rs(10,1-81)", CallExpr (loc "verified/lib.rs(10,1-81)", "thread_token", [], [], [LitPat (Var (loc "verified/lib.rs(10,1-81)", "_t"))], Static), Sep (loc "verified/lib.rs(10,1-81)", CoefAsn (loc "verified/lib.rs(10,1-81)", LitPat (Var (loc "verified/lib.rs(10,1-81)", "_q___18")), CallExpr (loc "verified/lib.rs(10,1-81)", "lifetime_token", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(10,1-81)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(10,1-81)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(10,1-81)", None, "'__18"))))], Static))
      ], Static)), Sep (loc "verified/lib.rs(10,1-81)", CoefAsn (loc "verified/lib.rs(10,1-81)", LitPat (Var (loc "verified/lib.rs(10,1-81)", "_q___19")), CallExpr (loc "verified/lib.rs(10,1-81)", "lifetime_token", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(10,1-81)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(10,1-81)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(10,1-81)", None, "'__19"))))], Static))
      ], Static)), Sep (loc "verified/lib.rs(10,37-38)", Sep (loc "verified/lib.rs(10,37-38)", CallExpr (loc "verified/lib.rs(10,37-38)", "array", [IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")], [], [
        LitPat (CastExpr (loc "verified/lib.rs(10,37-38)", PtrTypeExpr (loc "verified/lib.rs(10,37-38)", IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")), CallExpr (loc "verified/lib.rs(10,37-38)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(10,37-38)", ManifestTypeExpr (loc "verified/lib.rs(10,37-38)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(10,37-38)", "v")))], Static)));
        LitPat (CallExpr (loc "verified/lib.rs(10,37-38)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(10,37-38)", "v"))], Static));
        VarPat (loc "verified/lib.rs(10,37-38)", "_v1_v")
      ], Static), CallExpr (loc "verified/lib.rs(10,37-38)", "foreach", [], [], [
        LitPat (Var (loc "verified/lib.rs(10,37-38)", "_v1_v"));
        LitPat (CallExpr (loc "verified/lib.rs(10,37-38)", "own", [IdentTypeExpr (loc "verified/lib.rs(10,37-38)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(10,37-38)", "_t"))], Static))
      ], Static)), Sep (loc "verified/lib.rs(10,50-57)", Sep (loc "verified/lib.rs(10,50-57)", CallExpr (loc "verified/lib.rs(10,50-57)", "array", [
        StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])
      ], [], [
        LitPat (CastExpr (loc "verified/lib.rs(10,50-57)", PtrTypeExpr (loc "verified/lib.rs(10,50-57)", StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])), CallExpr (loc "verified/lib.rs(10,50-57)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(10,50-57)", ManifestTypeExpr (loc "verified/lib.rs(10,50-57)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(10,50-57)", "scratch")))], Static)));
        LitPat (CallExpr (loc "verified/lib.rs(10,50-57)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(10,50-57)", "scratch"))], Static));
        VarPat (loc "verified/lib.rs(10,50-57)", "_v1_scratch")
      ], Static), CallExpr (loc "verified/lib.rs(10,50-57)", "foreach", [], [], [
        LitPat (Var (loc "verified/lib.rs(10,50-57)", "_v1_scratch"));
        LitPat (CallExpr (loc "verified/lib.rs(10,50-57)", "own", [
          StructTypeExpr (loc "verified/lib.rs(10,50-57)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,50-57)", None, "T")])
        ], [], [LitPat (Var (loc "verified/lib.rs(10,50-57)", "_t"))], Static))
      ], Static)), EmpAsn (loc "verified/lib.rs(10,1-81)")))))))
    ], None)))), false, Some (([
      DeclStmt (loc "verified/lib.rs(10,1-19,2)", [(loc "verified/lib.rs(10,1-19,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(10,81)", StructType ("std_tuple_0_", []))), "$_0", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(10,1-19,2)", [(loc "verified/lib.rs(10,1-19,2)", Some (ConstTypeExpr (loc "verified/lib.rs(10,1-19,2)", PtrTypeExpr (loc "verified/lib.rs(11,9-16)", IdentTypeExpr (loc "verified/lib.rs(11,9-16)", None, "T")))), "_v_base", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(10,1-19,2)", [(loc "verified/lib.rs(10,1-19,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(11,19-20)", InferredTypeExpr (loc "verified/lib.rs(11,19-20)"), Mutable, SliceTypeExpr (loc "verified/lib.rs(11,19-20)", IdentTypeExpr (loc "verified/lib.rs(11,19-20)", None, "T")))), "$_4", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(10,1-19,2)", [(loc "verified/lib.rs(10,1-19,2)", Some (ConstTypeExpr (loc "verified/lib.rs(10,1-19,2)", PtrTypeExpr (loc "verified/lib.rs(12,9-21)", IdentTypeExpr (loc "verified/lib.rs(12,9-21)", None, "T")))), "scratch_base", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(10,1-19,2)", [(loc "verified/lib.rs(10,1-19,2)", Some (PtrTypeExpr (loc "verified/lib.rs(12,24-54)", IdentTypeExpr (loc "verified/lib.rs(12,24-54)", None, "T"))), "$_6", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(10,1-19,2)", [
        (loc "verified/lib.rs(10,1-19,2)", Some (PtrTypeExpr (loc "verified/lib.rs(12,24-44)", StructTypeExpr (loc "verified/lib.rs(12,24-44)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(12,24-44)", None, "T")]))), "$_7", None, (ref (false), ref (None)))
      ]);
      DeclStmt (loc "verified/lib.rs(10,1-19,2)", [
        (loc "verified/lib.rs(10,1-19,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(12,24-31)", InferredTypeExpr (loc "verified/lib.rs(12,24-31)"), Mutable, SliceTypeExpr (loc "verified/lib.rs(12,24-31)", StructTypeExpr (loc "verified/lib.rs(12,24-31)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(12,24-31)", None, "T")])))), "$_8", None, (ref (false), ref (None)))
      ]);
      DeclStmt (loc "verified/lib.rs(10,1-19,2)", [(loc "verified/lib.rs(10,1-19,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(13,8-26)", Bool)), "$_9", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(10,1-19,2)", [(loc "verified/lib.rs(10,1-19,2)", Some (ManifestTypeExpr (loc "verified/lib.rs(13,8-21)", Int (Unsigned, PtrRank))), "$_10", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(10,1-19,2)", [
        (loc "verified/lib.rs(10,1-19,2)", Some (RustRefTypeExpr (loc "verified/lib.rs(13,8-15)", InferredTypeExpr (loc "verified/lib.rs(13,8-15)"), Shared, SliceTypeExpr (loc "verified/lib.rs(13,8-15)", StructTypeExpr (loc "verified/lib.rs(13,8-15)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(13,8-15)", None, "T")])))), "$_11", None, (ref (false), ref (None)))
      ]);
      DeclStmt (loc "verified/lib.rs(10,1-19,2)", [(loc "verified/lib.rs(10,1-19,2)", Some (ConstTypeExpr (loc "verified/lib.rs(10,1-19,2)", ManifestTypeExpr (loc "verified/lib.rs(14,9-40)", StructType ("std_tuple_0_", [])))), "$_12", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(10,1-19,2)", [(loc "verified/lib.rs(10,1-19,2)", Some (ConstTypeExpr (loc "verified/lib.rs(10,1-19,2)", ManifestTypeExpr (loc "verified/lib.rs(15,9-40)", StructType ("std_tuple_0_", [])))), "$_13", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(10,1-19,2)", [(loc "verified/lib.rs(10,1-19,2)", Some (ConstTypeExpr (loc "verified/lib.rs(10,1-19,2)", ManifestTypeExpr (loc "verified/lib.rs(16,9-40)", StructType ("std_tuple_0_", [])))), "$_14", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(10,1-19,2)", [(loc "verified/lib.rs(10,1-19,2)", Some (ConstTypeExpr (loc "verified/lib.rs(10,1-19,2)", ManifestTypeExpr (loc "verified/lib.rs(17,9-40)", StructType ("std_tuple_0_", [])))), "$_15", None, (ref (false), ref (None)))]);
      LabelStmt (loc "verified/lib.rs(11,19-20)", "0");
      ExprStmt (AssignExpr (loc "verified/lib.rs(11,19-20)", Var (loc "verified/lib.rs(11,19-20)", "$_4"), Mutation, AddressOf (loc "verified/lib.rs(11,19-20)", Deref (loc "verified/lib.rs(11,19-20)", Var (loc "verified/lib.rs(11,19-20)", "v")))));
      ExprStmt (AssignExpr (loc "verified/lib.rs(11,19-33)", Var (loc "verified/lib.rs(11,19-33)", "_v_base"), Initialization, CastExpr (loc "verified/lib.rs(11,21-33)", PtrTypeExpr (loc "verified/lib.rs(11,21-33)", IdentTypeExpr (loc "verified/lib.rs(11,19-33)", None, "T")), Var (loc "verified/lib.rs(11,21-33)", "$_4"))));
      ExprStmt (AssignExpr (loc "verified/lib.rs(12,24-31)", Var (loc "verified/lib.rs(12,24-31)", "$_8"), Mutation, AddressOf (loc "verified/lib.rs(12,24-31)", Deref (loc "verified/lib.rs(12,24-31)", Var (loc "verified/lib.rs(12,24-31)", "scratch")))));
      ExprStmt (AssignExpr (loc "verified/lib.rs(12,24-44)", Var (loc "verified/lib.rs(12,24-44)", "$_7"), Mutation, CastExpr (loc "verified/lib.rs(12,32-44)", PtrTypeExpr (loc "verified/lib.rs(12,32-44)", StructTypeExpr (loc "verified/lib.rs(12,24-44)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(12,24-44)", None, "T")])), Var (loc "verified/lib.rs(12,32-44)", "$_8"))));
      ExprStmt (AssignExpr (loc "verified/lib.rs(12,24-54)", Var (loc "verified/lib.rs(12,24-54)", "$_6"), Mutation, CastExpr (loc "verified/lib.rs(12,24-54)", PtrTypeExpr (loc "verified/lib.rs(12,24-54)", IdentTypeExpr (loc "verified/lib.rs(12,24-54)", None, "T")), Var (loc "verified/lib.rs(12,24-54)", "$_7"))));
      ExprStmt (AssignExpr (loc "verified/lib.rs(12,24-54)", Var (loc "verified/lib.rs(12,24-54)", "scratch_base"), Initialization, Var (loc "verified/lib.rs(12,24-54)", "$_6")));
      ExprStmt (AssignExpr (loc "verified/lib.rs(13,8-15)", Var (loc "verified/lib.rs(13,8-15)", "$_11"), Mutation, CallExpr (loc "verified/lib.rs(13,8-15)", "fn_outcome_result", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(13,8-15)", "create_slice_ref", [], [], [LitPat (AddressOf (loc "verified/lib.rs(13,8-15)", Deref (loc "verified/lib.rs(13,8-15)", Var (loc "verified/lib.rs(13,8-15)", "scratch"))))], Static))
      ], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(13,8-21)", Var (loc "verified/lib.rs(13,8-21)", "$_10"), Mutation, CallExpr (loc "verified/lib.rs(13,16-21)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(13,16-21)", "$_11"))], Static)));
      ExprStmt (AssignExpr (loc "verified/lib.rs(13,8-26)", Var (loc "verified/lib.rs(13,8-26)", "$_9"), Mutation, Operation (loc "verified/lib.rs(13,8-26)", Ge, [Var (loc "verified/lib.rs(13,8-26)", "$_10"); CastExpr (loc "verified/lib.rs(13,25-26)", ManifestTypeExpr (loc "verified/lib.rs(13,25-26)", Int (Unsigned, PtrRank)), IntLit (loc "verified/lib.rs(13,25-26)", big_int_of_string "1", true, false, LLSuffix))])));
      IfStmt (loc "verified/lib.rs(13,8-26)", Var (loc "verified/lib.rs(13,8-26)", "$_9"), [GotoStmt (loc "verified/lib.rs(13,8-26)", "4")], [GotoStmt (loc "verified/lib.rs(13,8-26)", "9")]);
      LabelStmt (loc "verified/lib.rs(13,5-18,6)", "9");
      GotoStmt (loc "verified/lib.rs(13,5-18,6)", "10");
      LabelStmt (loc "verified/lib.rs(14,9-15,1)", "4");
      PureStmt (loc "verified/lib.rs(14,9-15,1)", DeclStmt (loc "verified/lib.rs(14,13-16)", [
        (loc "verified/lib.rs(14,17-24)", None, "mu_base", Some (CastExpr (loc "verified/lib.rs(14,70-72)", PtrTypeExpr (loc "verified/lib.rs(14,73-74)", ConstructedTypeExpr (loc "verified/lib.rs(14,74-95)", "std::mem::MaybeUninit", [IdentTypeExpr (loc "verified/lib.rs(14,96-97)", None, "T")])), CallExpr (loc "verified/lib.rs(14,27-49)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(14,58-60)", IdentTypeExpr (loc "verified/lib.rs(14,61-68)", None, "pointer"), Var (loc "verified/lib.rs(14,50-57)", "scratch")))], Static))), (ref (false), ref (None)))
      ]));
      PureStmt (loc "verified/lib.rs(15,9-16,1)", Assert (loc "verified/lib.rs(15,13-19)", PointsTo (loc "verified/lib.rs(15,48-51)", ReadArray (loc "verified/lib.rs(15,27-28)", Var (loc "verified/lib.rs(15,20-27)", "mu_base"), SliceExpr (loc "verified/lib.rs(15,28-30)", None, Some (LitPat (CallExpr (loc "verified/lib.rs(15,30-37)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(15,38-45)", "scratch"))], Static))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(15,53-63)", "mu_current"))));
      PureStmt (loc "verified/lib.rs(16,9-17,1)", Assert (loc "verified/lib.rs(16,13-19)", CallExpr (loc "verified/lib.rs(16,20-27)", "foreach", [], [], [
        LitPat (Var (loc "verified/lib.rs(16,28-38)", "mu_current"));
        LitPat (CallExpr (loc "verified/lib.rs(16,71-72)", "own", [
          ConstructedTypeExpr (loc "verified/lib.rs(16,46-67)", "std::mem::MaybeUninit", [IdentTypeExpr (loc "verified/lib.rs(16,68-69)", None, "T")])
        ], [], [LitPat (Var (loc "verified/lib.rs(16,72-85)", "currentThread"))], Static))
      ], Static)));
      PureStmt (loc "verified/lib.rs(17,9-18,1)", Assert (loc "verified/lib.rs(17,13-19)", PointsTo (loc "verified/lib.rs(17,38-41)", ReadArray (loc "verified/lib.rs(17,32-33)", Var (loc "verified/lib.rs(17,20-32)", "scratch_base"), SliceExpr (loc "verified/lib.rs(17,33-35)", None, Some (LitPat (IntLit (loc "verified/lib.rs(17,35-36)", big_int_of_string "1", true, false, NoLSuffix))))), "RegularPointsTo", VarPat (loc "verified/lib.rs(17,43-61)", "initialized_values"))));
      GotoStmt (loc "verified/lib.rs(13,5-18,6)", "10");
      LabelStmt (loc "verified/lib.rs(19,2)", "10");
      ReturnStmt (loc "verified/lib.rs(19,2)", Some (CallExpr (loc "verified/lib.rs(19,2)", "returning", [], [], [LitPat (Var (loc "verified/lib.rs(19,2)", "$_0"))], Static)))
    ], loc "verified/lib.rs(19,1-2)")), false, [])
  ])
]