[
  PackageDecl (loc "<dummy location>", "", [], [
    Func (loc "verified/lib.rs(10,1-12,2)", Regular, [("T", (true)); ("'__18", (false))], Some (ConstructedTypeExpr (loc "verified/lib.rs(10,70-89)", "fn_outcome", [
      PtrTypeExpr (loc "verified/lib.rs(10,70-89)", StructTypeExpr (loc "verified/lib.rs(10,70-89)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,70-89)", None, "T")]))
    ])), "canonical_slice_as_mut_ptr_mu", [
      (ConstTypeExpr (loc "verified/lib.rs(10,37-42)", RustRefTypeExpr (loc "verified/lib.rs(10,37-42)", IdentTypeExpr (loc "verified/lib.rs(10,37-42)", None, "'__18"), Mutable, SliceTypeExpr (loc "verified/lib.rs(10,37-42)", StructTypeExpr (loc "verified/lib.rs(10,37-42)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,37-42)", None, "T")])))), "slice")
    ], false, (None, None), Some ((Sep (loc "verified/lib.rs(10,1-89)", Sep (loc "verified/lib.rs(10,1-89)", CallExpr (loc "verified/lib.rs(10,1-89)", "thread_token", [], [], [VarPat (loc "verified/lib.rs(10,1-89)", "_t")], Static), Operation (loc "verified/lib.rs(10,1-89)", Eq, [Var (loc "verified/lib.rs(10,1-89)", "_t"); Var (loc "verified/lib.rs(10,1-89)", "currentThread")])), Sep (loc "verified/lib.rs(10,37-42)", Sep (loc "verified/lib.rs(10,37-42)", CallExpr (loc "verified/lib.rs(10,37-42)", "array", [
      StructTypeExpr (loc "verified/lib.rs(10,37-42)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,37-42)", None, "T")])
    ], [], [
      LitPat (CastExpr (loc "verified/lib.rs(10,37-42)", PtrTypeExpr (loc "verified/lib.rs(10,37-42)", StructTypeExpr (loc "verified/lib.rs(10,37-42)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,37-42)", None, "T")])), CallExpr (loc "verified/lib.rs(10,37-42)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(10,37-42)", ManifestTypeExpr (loc "verified/lib.rs(10,37-42)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(10,37-42)", "slice")))], Static)));
      LitPat (CallExpr (loc "verified/lib.rs(10,37-42)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(10,37-42)", "slice"))], Static));
      VarPat (loc "verified/lib.rs(10,37-42)", "_v0_slice")
    ], Static), CallExpr (loc "verified/lib.rs(10,37-42)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(10,37-42)", "_v0_slice"));
      LitPat (CallExpr (loc "verified/lib.rs(10,37-42)", "own", [
        StructTypeExpr (loc "verified/lib.rs(10,37-42)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,37-42)", None, "T")])
      ], [], [LitPat (Var (loc "verified/lib.rs(10,37-42)", "_t"))], Static))
    ], Static)), CoefAsn (loc "verified/lib.rs(10,1-89)", VarPat (loc "verified/lib.rs(10,1-89)", "_q___18"), CallExpr (loc "verified/lib.rs(10,1-89)", "lifetime_token", [], [], [
      LitPat (CallExpr (loc "verified/lib.rs(10,1-89)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(10,1-89)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(10,1-89)", None, "'__18"))))], Static))
    ], Static)))), ("outcome", SwitchExpr (loc "verified/lib.rs(10,1-89)", Var (loc "verified/lib.rs(10,1-89)", "outcome"), [
      SwitchExprClause (loc "verified/lib.rs(10,1-89)", "returning", ["result"], Sep (loc "verified/lib.rs(10,1-89)", CallExpr (loc "verified/lib.rs(10,1-89)", "thread_token", [], [], [LitPat (Var (loc "verified/lib.rs(10,1-89)", "_t"))], Static), Sep (loc "verified/lib.rs(10,1-89)", CoefAsn (loc "verified/lib.rs(10,1-89)", LitPat (Var (loc "verified/lib.rs(10,1-89)", "_q___18")), CallExpr (loc "verified/lib.rs(10,1-89)", "lifetime_token", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(10,1-89)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(10,1-89)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(10,1-89)", None, "'__18"))))], Static))
      ], Static)), Sep (loc "verified/lib.rs(10,37-42)", Sep (loc "verified/lib.rs(10,37-42)", CallExpr (loc "verified/lib.rs(10,37-42)", "array", [
        StructTypeExpr (loc "verified/lib.rs(10,37-42)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,37-42)", None, "T")])
      ], [], [
        LitPat (CastExpr (loc "verified/lib.rs(10,37-42)", PtrTypeExpr (loc "verified/lib.rs(10,37-42)", StructTypeExpr (loc "verified/lib.rs(10,37-42)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,37-42)", None, "T")])), CallExpr (loc "verified/lib.rs(10,37-42)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(10,37-42)", ManifestTypeExpr (loc "verified/lib.rs(10,37-42)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(10,37-42)", "slice")))], Static)));
        LitPat (CallExpr (loc "verified/lib.rs(10,37-42)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(10,37-42)", "slice"))], Static));
        VarPat (loc "verified/lib.rs(10,37-42)", "_v1_slice")
      ], Static), CallExpr (loc "verified/lib.rs(10,37-42)", "foreach", [], [], [
        LitPat (Var (loc "verified/lib.rs(10,37-42)", "_v1_slice"));
        LitPat (CallExpr (loc "verified/lib.rs(10,37-42)", "own", [
          StructTypeExpr (loc "verified/lib.rs(10,37-42)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,37-42)", None, "T")])
        ], [], [LitPat (Var (loc "verified/lib.rs(10,37-42)", "_t"))], Static))
      ], Static)), True (loc "verified/lib.rs(10,70-89)")))));
      SwitchExprClause (loc "verified/lib.rs(10,1-89)", "unwinding", [], Sep (loc "verified/lib.rs(10,1-89)", CallExpr (loc "verified/lib.rs(10,1-89)", "thread_token", [], [], [LitPat (Var (loc "verified/lib.rs(10,1-89)", "_t"))], Static), Sep (loc "verified/lib.rs(10,1-89)", CoefAsn (loc "verified/lib.rs(10,1-89)", LitPat (Var (loc "verified/lib.rs(10,1-89)", "_q___18")), CallExpr (loc "verified/lib.rs(10,1-89)", "lifetime_token", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(10,1-89)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(10,1-89)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(10,1-89)", None, "'__18"))))], Static))
      ], Static)), Sep (loc "verified/lib.rs(10,37-42)", Sep (loc "verified/lib.rs(10,37-42)", CallExpr (loc "verified/lib.rs(10,37-42)", "array", [
        StructTypeExpr (loc "verified/lib.rs(10,37-42)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,37-42)", None, "T")])
      ], [], [
        LitPat (CastExpr (loc "verified/lib.rs(10,37-42)", PtrTypeExpr (loc "verified/lib.rs(10,37-42)", StructTypeExpr (loc "verified/lib.rs(10,37-42)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,37-42)", None, "T")])), CallExpr (loc "verified/lib.rs(10,37-42)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(10,37-42)", ManifestTypeExpr (loc "verified/lib.rs(10,37-42)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(10,37-42)", "slice")))], Static)));
        LitPat (CallExpr (loc "verified/lib.rs(10,37-42)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(10,37-42)", "slice"))], Static));
        VarPat (loc "verified/lib.rs(10,37-42)", "_v1_slice")
      ], Static), CallExpr (loc "verified/lib.rs(10,37-42)", "foreach", [], [], [
        LitPat (Var (loc "verified/lib.rs(10,37-42)", "_v1_slice"));
        LitPat (CallExpr (loc "verified/lib.rs(10,37-42)", "own", [
          StructTypeExpr (loc "verified/lib.rs(10,37-42)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,37-42)", None, "T")])
        ], [], [LitPat (Var (loc "verified/lib.rs(10,37-42)", "_t"))], Static))
      ], Static)), EmpAsn (loc "verified/lib.rs(10,1-89)")))))
    ], None)))), false, Some (([
      DeclStmt (loc "verified/lib.rs(10,1-12,2)", [
        (loc "verified/lib.rs(10,1-12,2)", Some (PtrTypeExpr (loc "verified/lib.rs(10,70-89)", StructTypeExpr (loc "verified/lib.rs(10,70-89)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(10,70-89)", None, "T")]))), "$_0", None, (ref (false), ref (None)))
      ]);
      DeclStmt (loc "verified/lib.rs(10,1-12,2)", [
        (loc "verified/lib.rs(10,1-12,2)", Some (PtrTypeExpr (loc "verified/lib.rs(11,5-58)", StructTypeExpr (loc "verified/lib.rs(11,5-58)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(11,5-58)", None, "T")]))), "$_2", None, (ref (false), ref (None)))
      ]);
      DeclStmt (loc "verified/lib.rs(10,1-12,2)", [
        (loc "verified/lib.rs(10,1-12,2)", Some (PtrTypeExpr (loc "verified/lib.rs(11,5-35)", SliceTypeExpr (loc "verified/lib.rs(11,5-35)", StructTypeExpr (loc "verified/lib.rs(11,5-35)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(11,5-35)", None, "T")])))), "$_3", None, (ref (false), ref (None)))
      ]);
      DeclStmt (loc "verified/lib.rs(10,1-12,2)", [
        (loc "verified/lib.rs(10,1-12,2)", Some (PtrTypeExpr (loc "verified/lib.rs(11,5-35)", SliceTypeExpr (loc "verified/lib.rs(11,5-35)", StructTypeExpr (loc "verified/lib.rs(11,5-35)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(11,5-35)", None, "T")])))), "$_4", None, (ref (false), ref (None)))
      ]);
      LabelStmt (loc "verified/lib.rs(11,5-10)", "0");
      ExprStmt (AssignExpr (loc "verified/lib.rs(11,5-10)", Var (loc "verified/lib.rs(11,5-10)", "$_4"), Mutation, AddressOf (loc "verified/lib.rs(11,5-10)", Deref (loc "verified/lib.rs(11,5-10)", Var (loc "verified/lib.rs(11,5-10)", "slice")))));
      ExprStmt (AssignExpr (loc "verified/lib.rs(11,5-35)", Var (loc "verified/lib.rs(11,5-35)", "$_3"), Mutation, Var (loc "verified/lib.rs(11,5-35)", "$_4")));
      ExprStmt (AssignExpr (loc "verified/lib.rs(11,5-58)", Var (loc "verified/lib.rs(11,5-58)", "$_2"), Mutation, CastExpr (loc "verified/lib.rs(11,5-58)", PtrTypeExpr (loc "verified/lib.rs(11,5-58)", StructTypeExpr (loc "verified/lib.rs(11,5-58)", Some ("std::mem::MaybeUninit"), None, [], [IdentTypeExpr (loc "verified/lib.rs(11,5-58)", None, "T")])), Var (loc "verified/lib.rs(11,5-58)", "$_3"))));
      ExprStmt (AssignExpr (loc "verified/lib.rs(11,5-58)", Var (loc "verified/lib.rs(11,5-58)", "$_0"), Mutation, Var (loc "verified/lib.rs(11,5-58)", "$_2")));
      ReturnStmt (loc "verified/lib.rs(12,2)", Some (CallExpr (loc "verified/lib.rs(12,2)", "returning", [], [], [LitPat (Var (loc "verified/lib.rs(12,2)", "$_0"))], Static)))
    ], loc "verified/lib.rs(12,1-2)")), false, [])
  ])
]