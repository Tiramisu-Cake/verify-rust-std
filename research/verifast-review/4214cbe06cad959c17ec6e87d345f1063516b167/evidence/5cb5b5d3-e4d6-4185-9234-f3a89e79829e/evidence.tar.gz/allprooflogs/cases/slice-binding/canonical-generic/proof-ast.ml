[
  PackageDecl (loc "<dummy location>", "", [], [
    Func (loc "verified/lib.rs(10,1-12,2)", Regular, [("T", (true)); ("'__18", (false))], Some (ConstructedTypeExpr (loc "verified/lib.rs(10,54-60)", "fn_outcome", [PtrTypeExpr (loc "verified/lib.rs(10,54-60)", IdentTypeExpr (loc "verified/lib.rs(10,54-60)", None, "T"))])), "canonical_slice_as_mut_ptr", [(ConstTypeExpr (loc "verified/lib.rs(10,34-39)", RustRefTypeExpr (loc "verified/lib.rs(10,34-39)", IdentTypeExpr (loc "verified/lib.rs(10,34-39)", None, "'__18"), Mutable, SliceTypeExpr (loc "verified/lib.rs(10,34-39)", IdentTypeExpr (loc "verified/lib.rs(10,34-39)", None, "T")))), "slice")], false, (None, None), Some ((Sep (loc "verified/lib.rs(10,1-60)", Sep (loc "verified/lib.rs(10,1-60)", CallExpr (loc "verified/lib.rs(10,1-60)", "thread_token", [], [], [VarPat (loc "verified/lib.rs(10,1-60)", "_t")], Static), Operation (loc "verified/lib.rs(10,1-60)", Eq, [Var (loc "verified/lib.rs(10,1-60)", "_t"); Var (loc "verified/lib.rs(10,1-60)", "currentThread")])), Sep (loc "verified/lib.rs(10,34-39)", Sep (loc "verified/lib.rs(10,34-39)", CallExpr (loc "verified/lib.rs(10,34-39)", "array", [IdentTypeExpr (loc "verified/lib.rs(10,34-39)", None, "T")], [], [
      LitPat (CastExpr (loc "verified/lib.rs(10,34-39)", PtrTypeExpr (loc "verified/lib.rs(10,34-39)", IdentTypeExpr (loc "verified/lib.rs(10,34-39)", None, "T")), CallExpr (loc "verified/lib.rs(10,34-39)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(10,34-39)", ManifestTypeExpr (loc "verified/lib.rs(10,34-39)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(10,34-39)", "slice")))], Static)));
      LitPat (CallExpr (loc "verified/lib.rs(10,34-39)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(10,34-39)", "slice"))], Static));
      VarPat (loc "verified/lib.rs(10,34-39)", "_v0_slice")
    ], Static), CallExpr (loc "verified/lib.rs(10,34-39)", "foreach", [], [], [
      LitPat (Var (loc "verified/lib.rs(10,34-39)", "_v0_slice"));
      LitPat (CallExpr (loc "verified/lib.rs(10,34-39)", "own", [IdentTypeExpr (loc "verified/lib.rs(10,34-39)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(10,34-39)", "_t"))], Static))
    ], Static)), CoefAsn (loc "verified/lib.rs(10,1-60)", VarPat (loc "verified/lib.rs(10,1-60)", "_q___18"), CallExpr (loc "verified/lib.rs(10,1-60)", "lifetime_token", [], [], [
      LitPat (CallExpr (loc "verified/lib.rs(10,1-60)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(10,1-60)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(10,1-60)", None, "'__18"))))], Static))
    ], Static)))), ("outcome", SwitchExpr (loc "verified/lib.rs(10,1-60)", Var (loc "verified/lib.rs(10,1-60)", "outcome"), [
      SwitchExprClause (loc "verified/lib.rs(10,1-60)", "returning", ["result"], Sep (loc "verified/lib.rs(10,1-60)", CallExpr (loc "verified/lib.rs(10,1-60)", "thread_token", [], [], [LitPat (Var (loc "verified/lib.rs(10,1-60)", "_t"))], Static), Sep (loc "verified/lib.rs(10,1-60)", CoefAsn (loc "verified/lib.rs(10,1-60)", LitPat (Var (loc "verified/lib.rs(10,1-60)", "_q___18")), CallExpr (loc "verified/lib.rs(10,1-60)", "lifetime_token", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(10,1-60)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(10,1-60)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(10,1-60)", None, "'__18"))))], Static))
      ], Static)), Sep (loc "verified/lib.rs(10,34-39)", Sep (loc "verified/lib.rs(10,34-39)", CallExpr (loc "verified/lib.rs(10,34-39)", "array", [IdentTypeExpr (loc "verified/lib.rs(10,34-39)", None, "T")], [], [
        LitPat (CastExpr (loc "verified/lib.rs(10,34-39)", PtrTypeExpr (loc "verified/lib.rs(10,34-39)", IdentTypeExpr (loc "verified/lib.rs(10,34-39)", None, "T")), CallExpr (loc "verified/lib.rs(10,34-39)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(10,34-39)", ManifestTypeExpr (loc "verified/lib.rs(10,34-39)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(10,34-39)", "slice")))], Static)));
        LitPat (CallExpr (loc "verified/lib.rs(10,34-39)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(10,34-39)", "slice"))], Static));
        VarPat (loc "verified/lib.rs(10,34-39)", "_v1_slice")
      ], Static), CallExpr (loc "verified/lib.rs(10,34-39)", "foreach", [], [], [
        LitPat (Var (loc "verified/lib.rs(10,34-39)", "_v1_slice"));
        LitPat (CallExpr (loc "verified/lib.rs(10,34-39)", "own", [IdentTypeExpr (loc "verified/lib.rs(10,34-39)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(10,34-39)", "_t"))], Static))
      ], Static)), True (loc "verified/lib.rs(10,54-60)")))));
      SwitchExprClause (loc "verified/lib.rs(10,1-60)", "unwinding", [], Sep (loc "verified/lib.rs(10,1-60)", CallExpr (loc "verified/lib.rs(10,1-60)", "thread_token", [], [], [LitPat (Var (loc "verified/lib.rs(10,1-60)", "_t"))], Static), Sep (loc "verified/lib.rs(10,1-60)", CoefAsn (loc "verified/lib.rs(10,1-60)", LitPat (Var (loc "verified/lib.rs(10,1-60)", "_q___18")), CallExpr (loc "verified/lib.rs(10,1-60)", "lifetime_token", [], [], [
        LitPat (CallExpr (loc "verified/lib.rs(10,1-60)", "lft_of", [], [], [LitPat (Typeid (loc "verified/lib.rs(10,1-60)", TypeExpr (IdentTypeExpr (loc "verified/lib.rs(10,1-60)", None, "'__18"))))], Static))
      ], Static)), Sep (loc "verified/lib.rs(10,34-39)", Sep (loc "verified/lib.rs(10,34-39)", CallExpr (loc "verified/lib.rs(10,34-39)", "array", [IdentTypeExpr (loc "verified/lib.rs(10,34-39)", None, "T")], [], [
        LitPat (CastExpr (loc "verified/lib.rs(10,34-39)", PtrTypeExpr (loc "verified/lib.rs(10,34-39)", IdentTypeExpr (loc "verified/lib.rs(10,34-39)", None, "T")), CallExpr (loc "verified/lib.rs(10,34-39)", "strip_pointer_metadata", [], [], [LitPat (CastExpr (loc "verified/lib.rs(10,34-39)", ManifestTypeExpr (loc "verified/lib.rs(10,34-39)", InductiveType ("pointer", [])), Var (loc "verified/lib.rs(10,34-39)", "slice")))], Static)));
        LitPat (CallExpr (loc "verified/lib.rs(10,34-39)", "ptr_len", [], [], [LitPat (Var (loc "verified/lib.rs(10,34-39)", "slice"))], Static));
        VarPat (loc "verified/lib.rs(10,34-39)", "_v1_slice")
      ], Static), CallExpr (loc "verified/lib.rs(10,34-39)", "foreach", [], [], [
        LitPat (Var (loc "verified/lib.rs(10,34-39)", "_v1_slice"));
        LitPat (CallExpr (loc "verified/lib.rs(10,34-39)", "own", [IdentTypeExpr (loc "verified/lib.rs(10,34-39)", None, "T")], [], [LitPat (Var (loc "verified/lib.rs(10,34-39)", "_t"))], Static))
      ], Static)), EmpAsn (loc "verified/lib.rs(10,1-60)")))))
    ], None)))), false, Some (([
      DeclStmt (loc "verified/lib.rs(10,1-12,2)", [(loc "verified/lib.rs(10,1-12,2)", Some (PtrTypeExpr (loc "verified/lib.rs(10,54-60)", IdentTypeExpr (loc "verified/lib.rs(10,54-60)", None, "T"))), "$_0", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(10,1-12,2)", [(loc "verified/lib.rs(10,1-12,2)", Some (PtrTypeExpr (loc "verified/lib.rs(11,5-32)", IdentTypeExpr (loc "verified/lib.rs(11,5-32)", None, "T"))), "$_2", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(10,1-12,2)", [(loc "verified/lib.rs(10,1-12,2)", Some (PtrTypeExpr (loc "verified/lib.rs(11,5-22)", SliceTypeExpr (loc "verified/lib.rs(11,5-22)", IdentTypeExpr (loc "verified/lib.rs(11,5-22)", None, "T")))), "$_3", None, (ref (false), ref (None)))]);
      DeclStmt (loc "verified/lib.rs(10,1-12,2)", [(loc "verified/lib.rs(10,1-12,2)", Some (PtrTypeExpr (loc "verified/lib.rs(11,5-22)", SliceTypeExpr (loc "verified/lib.rs(11,5-22)", IdentTypeExpr (loc "verified/lib.rs(11,5-22)", None, "T")))), "$_4", None, (ref (false), ref (None)))]);
      LabelStmt (loc "verified/lib.rs(11,5-10)", "0");
      ExprStmt (AssignExpr (loc "verified/lib.rs(11,5-10)", Var (loc "verified/lib.rs(11,5-10)", "$_4"), Mutation, AddressOf (loc "verified/lib.rs(11,5-10)", Deref (loc "verified/lib.rs(11,5-10)", Var (loc "verified/lib.rs(11,5-10)", "slice")))));
      ExprStmt (AssignExpr (loc "verified/lib.rs(11,5-22)", Var (loc "verified/lib.rs(11,5-22)", "$_3"), Mutation, Var (loc "verified/lib.rs(11,5-22)", "$_4")));
      ExprStmt (AssignExpr (loc "verified/lib.rs(11,5-32)", Var (loc "verified/lib.rs(11,5-32)", "$_2"), Mutation, CastExpr (loc "verified/lib.rs(11,5-32)", PtrTypeExpr (loc "verified/lib.rs(11,5-32)", IdentTypeExpr (loc "verified/lib.rs(11,5-32)", None, "T")), Var (loc "verified/lib.rs(11,5-32)", "$_3"))));
      ExprStmt (AssignExpr (loc "verified/lib.rs(11,5-32)", Var (loc "verified/lib.rs(11,5-32)", "$_0"), Mutation, Var (loc "verified/lib.rs(11,5-32)", "$_2")));
      ReturnStmt (loc "verified/lib.rs(12,2)", Some (CallExpr (loc "verified/lib.rs(12,2)", "returning", [], [], [LitPat (Var (loc "verified/lib.rs(12,2)", "$_0"))], Static)))
    ], loc "verified/lib.rs(12,1-2)")), false, [])
  ])
]