#![feature(core_intrinsics, transmute_neo, sized_type_properties)]
#![allow(internal_features)]
#![feature(transparent_unions)]

use std::mem::MaybeUninit;
use std::mem::{SizedTypeProperties, transmute_neo};
use std::mem::ManuallyDrop;
use std::{intrinsics, mem};

mod sort4_certified_maybeuninit {
    use std::mem::ManuallyDrop;
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

    pub fn sort4_checked_maybeuninit_new<Element>(val: *const Element) -> MaybeUninit<*const Element>
    {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }
}

pub fn sort4_checked_as_mut_ptr<Element>(storage: &mut std::mem::MaybeUninit<*const Element>) -> *mut *const Element

{
        // `MaybeUninit` and `ManuallyDrop` are both `repr(transparent)` so we can cast the pointer.
        storage as *mut _ as *mut *const Element
    }

pub unsafe fn sort4_checked_pointer_drop<Element>(slot: *mut *const Element)

{
        // SAFETY: the caller must uphold the safety contract for `drop_in_place`.
        unsafe { std::ptr::drop_in_place(slot) }
    }

pub unsafe fn sort4_checked_generic_drop<T>(slot: *mut T)

{
        // SAFETY: the caller must uphold the safety contract for `drop_in_place`.
        unsafe { std::ptr::drop_in_place(slot) }
    }


pub unsafe fn checked_transmute_neo_pointer<Element>(src: MaybeUninit<*const Element>) -> *const Element
{
    const { assert!(<MaybeUninit<*const Element> as SizedTypeProperties>::SIZE == <*const Element as SizedTypeProperties>::SIZE) };

    // SAFETY: the const-assert just checked that they're the same size,
    // and any other safety invariants need to be upheld by the caller.
    unsafe { intrinsics::transmute_unchecked(src) }
}

pub unsafe fn checked_assume_init_pointer<Element>(storage: MaybeUninit<*const Element>) -> *const Element
{
        // SAFETY: the caller must guarantee that `self` is initialized.
        // This also means that `self` must be a `value` variant.
        unsafe {
            intrinsics::assert_inhabited::<*const Element>();
            // We do this via a transmute instead of `ManuallyDrop::into_inner` so that there's
            // no trace of `ManuallyDrop` in Miri's error messages here.
            transmute_neo(storage)
        }
    }

pub unsafe fn checked_forget_owned<T>(t: T)
{
    let _ = ManuallyDrop::new(t);
}

pub fn select_unpredictable<Element>(
    condition: bool,
    true_val: *const Element,
    false_val: *const Element,
) -> *const Element
{
    // FIXME(https://github.com/rust-lang/unsafe-code-guidelines/issues/245):
    // Change this to use ManuallyDrop instead.
    let mut true_val = MaybeUninit::new(true_val);
    let mut false_val = MaybeUninit::new(false_val);

    struct DropOnPanic<T> {
        // Invariant: valid pointer and points to an initialized value that is not further used,
        // i.e. it can be dropped by this guard.
        inner: *mut T,
    }

    impl<T> Drop for DropOnPanic<T> {
        fn drop(&mut self) {
            // SAFETY: Must be guaranteed on construction of local type `DropOnPanic`.
            unsafe { self.inner.drop_in_place() }
        }
    }

    let true_ptr = true_val.as_mut_ptr();
    let false_ptr = false_val.as_mut_ptr();

    // SAFETY: The value that is not selected is dropped, and the selected one
    // is returned. This is necessary because the intrinsic doesn't drop the
    // value that is  not selected.
    unsafe {
        // Extract the selected value first, ensure it is dropped as well if dropping the unselected
        // value panics. We construct a temporary by-pointer guard around the selected value while
        // dropping the unselected value. Arguments overlap here, so we can not use mutable
        // reference for these arguments.
        let guard = crate::intrinsics::select_unpredictable(condition, true_ptr, false_ptr);
        let drop = crate::intrinsics::select_unpredictable(condition, false_ptr, true_ptr);

        // SAFETY: both pointers are well-aligned and point to initialized values inside a
        // `MaybeUninit` each. In both possible values for `condition` the pointer `guard` and
        // `drop` do not alias (even though the two argument pairs we have selected from did alias
        // each other).
        let guard = DropOnPanic { inner: guard };
        drop.drop_in_place();
        crate::mem::forget(guard);

        // Note that it is important to use the values here. Reading from the pointer we got makes
        // LLVM forget the !unpredictable annotation sometimes (in tests, integer sized values in
        // particular seemed to confuse it, also observed in llvm/llvm-project #82340).
        crate::intrinsics::select_unpredictable(condition, true_val, false_val).assume_init()
    }
}
