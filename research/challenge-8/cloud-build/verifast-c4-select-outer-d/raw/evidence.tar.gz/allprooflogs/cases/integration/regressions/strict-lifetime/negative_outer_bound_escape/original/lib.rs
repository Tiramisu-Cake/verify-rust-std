#![no_std]
#![allow(dead_code)]

// Source template for physical, one-case VeriFast fixtures. The runner strips
// the CASE delimiters and sends each selected source separately to the readonly
// compiler-MIR exporter, decoder, and verifier. This combined template is never
// a verifier input.

// Adapted from the independently hosted callback_positive source; its
// complete predicate/lemma are included so this case is isolated.


pub unsafe fn negative_outer_bound_escape<T, F: FnMut(&T, &T) -> bool>(
    left: *const T,
    right: *const T,
    is_less: &mut F,
) -> bool
{
    let mut result: bool;
    {
                let answer = is_less(&*left, &*right);
        result = answer;
    };
    result
}
