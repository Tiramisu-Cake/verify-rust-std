#![feature(core_intrinsics)]
#![allow(internal_features)]
#![feature(transparent_unions)]

use std::mem::MaybeUninit;
use std::{intrinsics, mem};

mod sort4_certified_maybeuninit {
    use std::mem::ManuallyDrop;
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

    pub fn sort4_checked_maybeuninit_new<Element>(val: *const Element) -> MaybeUninit<*const Element>
/*@
req thread_token(?t) &*& t == currentThread;
@*/
/*@
ens thread_token(t) &*& std::mem::MaybeUninit::inner(result) == some(val) &*& std::mem::MaybeUninit_pointer_own::<Element>()(t, result);
@*/
/*@
on_unwind_ens false;
@*/
    {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }
}

pub fn sort4_checked_as_mut_ptr<Element>(storage: &mut std::mem::MaybeUninit<*const Element>) -> *mut *const Element

/*@
req thread_token(?t) &*& t == currentThread &*& *storage |-> ?value &*& std::mem::MaybeUninit_pointer_own::<Element>()(t, value);
@*/
/*@
ens thread_token(t) &*& *storage |-> value &*& std::mem::MaybeUninit_pointer_own::<Element>()(t, value) &*& (result as pointer) == (storage as pointer);
@*/
/*@
on_unwind_ens false;
@*/
{
        // `MaybeUninit` and `ManuallyDrop` are both `repr(transparent)` so we can cast the pointer.
        storage as *mut _ as *mut *const Element
    }

pub unsafe fn sort4_checked_pointer_drop<Element>(slot: *mut *const Element)

/*@
req thread_token(?t) &*& t == currentThread &*& *slot |-> ?value;
@*/
/*@
ens thread_token(t) &*& *slot |-> value;
@*/
/*@
on_unwind_ens false;
@*/
{
        // SAFETY: the caller must uphold the safety contract for `drop_in_place`.
        unsafe { std::ptr::drop_in_place(slot) }
    }

pub unsafe fn sort4_checked_generic_drop<T>(slot: *mut T)

/*@
req thread_token(?t) &*& t == currentThread &*& *slot |-> ?value &*& <T>.own(t, value);
@*/
/*@
ens thread_token(t) &*& *slot |-> _;
@*/
/*@
on_unwind_ens thread_token(t) &*& *slot |-> _;
@*/
{
        // SAFETY: the caller must uphold the safety contract for `drop_in_place`.
        unsafe { std::ptr::drop_in_place(slot) }
    }


pub fn select_unpredictable<Element>(
    condition: bool,
    true_val: *const Element,
    false_val: *const Element,
) -> *const Element
/*@
req thread_token(?t) &*& t == currentThread;
@*//*@
ens thread_token(t) &*& (result as pointer) ==
        (if condition { true_val as pointer } else { false_val as pointer }) &*& raw_ptr_own::<Element>()(t, result);
@*//*@ on_unwind_ens false; @*/
/*@
safety_proof {
    let outcome = call();
    open raw_ptr_own::<Element>()(_t, fn_outcome_result(outcome));
}
@*/
{
    // FIXME(https://github.com/rust-lang/unsafe-code-guidelines/issues/245):
    // Change this to use ManuallyDrop instead.
    let mut true_val = MaybeUninit::new(true_val);
    let mut false_val = MaybeUninit::new(false_val);

    struct DropOnPanic<T> {
        // Invariant: valid pointer and points to an initialized value that is not further used,
        // i.e. it can be dropped by this guard.
        inner: *mut T,
    }

    impl<T> Drop for DropOnPanic<T> {
        fn drop(&mut self) {
            // SAFETY: Must be guaranteed on construction of local type `DropOnPanic`.
            //@ open <select_unpredictable::DropOnPanic<T>>.full_borrow_content(_t, self)();
            //@ open <select_unpredictable::DropOnPanic<T>>.own(_t, ?g);
            unsafe { self.inner.drop_in_place() }
        }
    }

    let true_ptr = true_val.as_mut_ptr();
    let false_ptr = false_val.as_mut_ptr();
    /*@ std::mem::open_MaybeUninit::<*Element>(true_ptr as *std::mem::MaybeUninit<*Element>); @*/
    /*@ std::mem::open_MaybeUninit::<*Element>(false_ptr as *std::mem::MaybeUninit<*Element>); @*/
    /*@ assert *true_ptr |-> ?true_payload; @*/
    /*@ assert *false_ptr |-> ?false_payload; @*/

    // SAFETY: The value that is not selected is dropped, and the selected one
    // is returned. This is necessary because the intrinsic doesn't drop the
    // value that is  not selected.
    unsafe {
        // Extract the selected value first, ensure it is dropped as well if dropping the unselected
        // value panics. We construct a temporary by-pointer guard around the selected value while
        // dropping the unselected value. Arguments overlap here, so we can not use mutable
        // reference for these arguments.
        let guard = crate::intrinsics::select_unpredictable(condition, true_ptr, false_ptr);
        let drop = crate::intrinsics::select_unpredictable(condition, false_ptr, true_ptr);

        // SAFETY: both pointers are well-aligned and point to initialized values inside a
        // `MaybeUninit` each. In both possible values for `condition` the pointer `guard` and
        // `drop` do not alias (even though the two argument pairs we have selected from did alias
        // each other).
        let guard = DropOnPanic { inner: guard };
        /*@ if (condition) {
                 close raw_ptr_own::<Element>()(t, true_payload);
                 close <select_unpredictable::DropOnPanic<*Element>>.own(t, select_unpredictable::DropOnPanic::<*Element> { inner: guard });
             } else {
                 close raw_ptr_own::<Element>()(t, false_payload);
                 close <select_unpredictable::DropOnPanic<*Element>>.own(t, select_unpredictable::DropOnPanic::<*Element> { inner: guard });
             } @*/
        drop.drop_in_place();
        /*@ if (condition) {
                 std::mem::close_MaybeUninit::<*Element>(false_ptr as *std::mem::MaybeUninit<*Element>);
             } else {
                 std::mem::close_MaybeUninit::<*Element>(true_ptr as *std::mem::MaybeUninit<*Element>);
             } @*/
        /*@ open <select_unpredictable::DropOnPanic<*Element>>.own(t, guard); @*/
        /*@ assert *guard.inner |-> ?selected_payload; @*/
        /*@ open raw_ptr_own::<Element>()(t, selected_payload); @*/
        crate::mem::forget(guard);
        /*@ if (condition) {
                 std::mem::close_MaybeUninit::<*Element>(true_ptr as *std::mem::MaybeUninit<*Element>);
             } else {
                 std::mem::close_MaybeUninit::<*Element>(false_ptr as *std::mem::MaybeUninit<*Element>);
             } @*/

        // Note that it is important to use the values here. Reading from the pointer we got makes
        // LLVM forget the !unpredictable annotation sometimes (in tests, integer sized values in
        // particular seemed to confuse it, also observed in llvm/llvm-project #82340).
        crate::intrinsics::select_unpredictable(condition, true_val, false_val).assume_init()
    }
}
/*@
pred<T> <select_unpredictable::DropOnPanic<T>>.own(t, g) =
    *g.inner |-> ?payload &*& <T>.own(t, payload);
@*/
