pub fn sort4_checked_as_mut_ptr<Element>(storage: &mut std::mem::MaybeUninit<*const Element>) -> *mut *const Element




{
        // `MaybeUninit` and `ManuallyDrop` are both `repr(transparent)` so we can cast the pointer.
        storage as *mut _ as *mut *const Element
    }

pub unsafe fn sort4_as_mut_ptr_unknown_probe<Element>(storage: &mut std::mem::MaybeUninit<*const Element>, frame: *const u8) -> *mut *const Element




{
    let result = sort4_checked_as_mut_ptr(storage);
    result
}
