pub fn sort4_checked_as_mut_ptr<Element>(storage: &mut std::mem::MaybeUninit<*const Element>) -> *mut *const Element

/*@
req thread_token(?t) &*& t == currentThread &*& *storage |-> ?value &*& std::mem::MaybeUninit_pointer_own::<Element>()(t, value);
@*/
/*@
ens thread_token(t) &*& *storage |-> value &*& std::mem::MaybeUninit_pointer_own::<Element>()(t, value) &*& (result as pointer) == (storage as pointer);
@*/
/*@
on_unwind_ens false;
@*/
{
        // `MaybeUninit` and `ManuallyDrop` are both `repr(transparent)` so we can cast the pointer.
        storage as *mut _ as *mut *const Element
    }

pub unsafe fn sort4_as_mut_ptr_unknown_probe<Element>(storage: &mut std::mem::MaybeUninit<*const Element>, frame: *const u8) -> *mut *const Element

/*@
req thread_token(?t) &*& t == currentThread &*& *storage |-> ?value &*& std::mem::MaybeUninit_pointer_own::<Element>()(t, value) &*& [?f](*frame |-> ?frame_value);
@*/
/*@
// TARGET_POSTCONDITION
ens thread_token(t) &*& *storage |-> value &*& std::mem::MaybeUninit_pointer_own::<Element>()(t, value) &*& [f](*frame |-> frame_value) &*& (result as pointer) == (storage as pointer);
@*/
/*@
on_unwind_ens false;
@*/
{
    let result = sort4_checked_as_mut_ptr(storage);
    result
}
