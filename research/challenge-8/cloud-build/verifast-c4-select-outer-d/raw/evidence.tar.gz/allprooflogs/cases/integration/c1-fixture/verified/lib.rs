#![feature(const_trait_impl)]
#![allow(internal_features)]

use std::{hint, ptr};

/*@
lem interior_pointer_limits<T>(base: *T, count: usize, index: usize)
    req [?f]base[..count] |-> ?xs &*& 1 <= count &*& 0 <= index &*& index <= count;
    ens [f]base[..count] |-> xs &*& pointer_within_limits(base + index) == true;
{
    open array(base, count, xs);
    points_to_limits(base);
    close [f]array(base, count, xs);
    note(0 <= std::mem::size_of::<T>());
    array_inv::<T>();
    mul_mono_l(0, index, std::mem::size_of::<T>());
    mul_mono_l(index, count, std::mem::size_of::<T>());
    note(pointer_within_limits(base));
    note(pointer_within_limits(base + count));
}
@*/
/*@
lem split_four_owned_cells<T>(base: *T, t: thread_id_t)
    req base[..4] |-> ?xs &*& foreach(xs, own::<T>(t));
    ens *base |-> ?first &*& <T>.own(t, first) &*&
        *(base + 1) |-> ?second &*& <T>.own(t, second) &*&
        *(base + 2) |-> ?third &*& <T>.own(t, third) &*&
        *(base + 3) |-> ?fourth &*& <T>.own(t, fourth) &*&
        xs == cons(first, cons(second, cons(third, cons(fourth, nil))));
{
    open array(base, 4, xs);
    assert xs == cons(?first0, ?rest0);
    open foreach(xs, own::<T>(t));
    open own::<T>(t)(first0);
    open array(base + 1, 3, rest0);
    assert rest0 == cons(?second0, ?tail0);
    open foreach(rest0, own::<T>(t));
    open own::<T>(t)(second0);
    open array(base + 2, 2, tail0);
    assert tail0 == cons(?third0, ?rest1);
    open foreach(tail0, own::<T>(t));
    open own::<T>(t)(third0);
    open array(base + 3, 1, rest1);
    assert rest1 == cons(?fourth0, ?empty0);
    open foreach(rest1, own::<T>(t));
    open own::<T>(t)(fourth0);
    open array(base + 4, 0, empty0);
    open foreach(empty0, own::<T>(t));
}
@*/
/*@
pred comparison_debt<T>(
    t: thread_id_t, k: lifetime_t, left: *T, right: *T,
    left_ref: *T, right_ref: *T, left_fraction: real, right_fraction: real) =
    [left_fraction]ref_initialized::<T>(left_ref) &*&
    close_frac_borrow_token(
        left_fraction, ref_initialized_::<T>(left_ref), 1/4, k) &*&
    [right_fraction]ref_initialized::<T>(right_ref) &*&
    close_frac_borrow_token(
        right_fraction, ref_initialized_::<T>(right_ref), 1/4, k) &*&
    borrow_end_token(k, <T>.full_borrow_content(t, left)) &*&
    borrow_end_token(k, <T>.full_borrow_content(t, right));
@*/
/*@
lem recover_pair<T>(left: *T, right: *T)
    nonghost_callers_only
    req thread_token(?t) &*& type_interp::<T>() &*&
        comparison_debt::<T>(
            t, ?k, left, right, ?left_ref, ?right_ref,
            ?left_fraction, ?right_fraction) &*&
        [1/2]lifetime_token(k);
    ens thread_token(t) &*& type_interp::<T>() &*&
        *left |-> ?left_after &*& <T>.own(t, left_after) &*&
        *right |-> ?right_after &*& <T>.own(t, right_after);
{
    open comparison_debt::<T>(
        t, k, left, right, left_ref, right_ref, left_fraction, right_fraction);
    close [left_fraction]ref_initialized_::<T>(left_ref)();
    close_frac_borrow(left_fraction, ref_initialized_::<T>(left_ref));
    close [right_fraction]ref_initialized_::<T>(right_ref)();
    close_frac_borrow(right_fraction, ref_initialized_::<T>(right_ref));
    merge_fractions lifetime_token(k);
    end_lifetime(k);
    borrow_end(k, <T>.full_borrow_content(t, left));
    open_full_borrow_content::<T>(t, left);
    borrow_end(k, <T>.full_borrow_content(t, right));
    open_full_borrow_content::<T>(t, right);
}
@*/
/*@
lem join_four_owned_cells<T>(base: *T, t: thread_id_t)
    req *base |-> ?first &*& <T>.own(t, first) &*&
        *(base + 1) |-> ?second &*& <T>.own(t, second) &*&
        *(base + 2) |-> ?third &*& <T>.own(t, third) &*&
        *(base + 3) |-> ?fourth &*& <T>.own(t, fourth);
    ens base[..4] |-> cons(first, cons(second, cons(third, cons(fourth, nil)))) &*&
        foreach(cons(first, cons(second, cons(third, cons(fourth, nil)))),
            own::<T>(t));
{
    points_to_limits(base);
    points_to_limits(base + 1);
    points_to_limits(base + 2);
    points_to_limits(base + 3);
    note(pointer_within_limits(base));
    note(pointer_within_limits(base + 1));
    note(pointer_within_limits(base + 2));
    note(pointer_within_limits(base + 3));
    note(pointer_within_limits(base + 4));
    close own::<T>(t)(first);
    close own::<T>(t)(second);
    close own::<T>(t)(third);
    close own::<T>(t)(fourth);
    close foreach(nil, own::<T>(t));
    close foreach(cons(fourth, nil), own::<T>(t));
    close foreach(cons(third, cons(fourth, nil)), own::<T>(t));
    close foreach(cons(second, cons(third, cons(fourth, nil))), own::<T>(t));
    close foreach(cons(first, cons(second, cons(third, cons(fourth, nil)))),
        own::<T>(t));
    close array(base + 4, 0, nil);
    close array(base + 3, 1, cons(fourth, nil));
    close array(base + 2, 2, cons(third, cons(fourth, nil)));
    close array(base + 1, 3, cons(second, cons(third, cons(fourth, nil))));
    close array(base, 4, cons(first, cons(second, cons(third, cons(fourth, nil)))));
}
@*/
pub unsafe fn sort4_stable<T, F: FnMut(&T, &T) -> bool>(
    v_base: *const T,
    dst: *mut T,
    is_less: &mut F,
) /*@
req thread_token(?t) &*& t == currentThread &*&
    type_interp::<T>() &*& type_interp::<F>() &*&
    0 < std::mem::size_of::<T>() &*&
    v_base[..4] |-> ?source_before &*&
    foreach(source_before, own::<T>(t)) &*&
    array_::<T>(dst, 4, ?destination_before) &*&
    *is_less |-> ?less_before &*& <F>.own(t, less_before);
@*/
/*@
ens thread_token(t) &*& type_interp::<T>() &*& type_interp::<F>() &*&
    v_base[..4] |-> ?source_after &*&
    foreach(source_after, own::<T>(t)) &*&
    array_::<T>(dst, 4, ?destination_after) &*&
    *is_less |-> ?less_after &*& <F>.own(t, less_after);
@*/
/*@
on_unwind_ens thread_token(t) &*& type_interp::<T>() &*& type_interp::<F>() &*&
    v_base[..4] |-> ?source_after &*&
    foreach(source_after, own::<T>(t)) &*&
    array_::<T>(dst, 4, ?destination_after) &*&
    *is_less |-> ?less_after &*& <F>.own(t, less_after);
@*/
{
    // By limiting select to picking pointers, we are guaranteed good cmov code-gen
    // regardless of type T's size. Further this only does 5 instead of 6
    // comparisons compared to a stable transposition 4 element sorting-network,
    // and always copies each element exactly once.

    // SAFETY: all pointers have offset at most 3 from v_base and dst, and are
    // thus in-bounds by the precondition.
    //@ let cmp_k = begin_lifetime();
    unsafe {
/*@ let_lft 'cmp = cmp_k; @*/
        // Stably create two pairs a <= b and c <= d.
        //@ interior_pointer_limits::<T>(v_base, 4, 1);
        //@ split_four_owned_cells::<T>(v_base, t);
        //@ close_full_borrow_content::<T>(t, v_base + 1);
        //@ close_full_borrow_content::<T>(t, v_base);
        //@ borrow(cmp_k, <T>.full_borrow_content(t, v_base + 1));
        //@ borrow(cmp_k, <T>.full_borrow_content(t, v_base));
        //@ share_full_borrow::<T>(cmp_k, t, v_base + 1);
        //@ share_full_borrow::<T>(cmp_k, t, v_base);
        //@ let left_ref = precreate_ref(v_base + 1);
        //@ let right_ref = precreate_ref(v_base);
        //@ init_ref_share::<T>(cmp_k, t, left_ref);
        //@ init_ref_share::<T>(cmp_k, t, right_ref);
        //@ close_ref_own::<'cmp, T>(left_ref);
        //@ close_ref_own::<'cmp, T>(right_ref);
        //@ close <(&'cmp T, &'cmp T)>.own(t, std_tuple_2_::<&'cmp T, &'cmp T> { 0: left_ref, 1: right_ref });
        //@ open_frac_borrow(cmp_k, ref_initialized_(left_ref), 1/4);
        //@ open [?left_fraction]ref_initialized_::<T>(left_ref)();
        //@ open_frac_borrow(cmp_k, ref_initialized_(right_ref), 1/4);
        //@ open [?right_fraction]ref_initialized_::<T>(right_ref)();
/*@ {
            __vf_sort4_first_unwind();
            { close comparison_debt::<T>(t, cmp_k, v_base + 1, v_base, left_ref, right_ref, left_fraction, right_fraction); }
            { recover_pair::<T>(v_base + 1, v_base); }
            { join_four_owned_cells::<T>(v_base, t); }
        } @*/
        let c1 = is_less/*@::<F, (&'cmp T, &'cmp T), 'cmp>@*/(&*v_base.add(1), &*v_base);
        //@ close comparison_debt::<T>(t, cmp_k, v_base + 1, v_base, left_ref, right_ref, left_fraction, right_fraction);
        //@ end_lft_binding::<'cmp>();
        //@ recover_pair::<T>(v_base + 1, v_base);
        //@ join_four_owned_cells::<T>(v_base, t);
        let c2 = is_less(&*v_base.add(3), &*v_base.add(2));
        let a = v_base.add(c1 as usize);
        let b = v_base.add(!c1 as usize);
        let c = v_base.add(2 + c2 as usize);
        let d = v_base.add(2 + (!c2 as usize));

        // Compare (a, c) and (b, d) to identify max/min. We're left with two
        // unknown elements, but because we are a stable sort we must know which
        // one is leftmost and which one is rightmost.
        // c3, c4 | min max unknown_left unknown_right
        //  0,  0 |  a   d    b         c
        //  0,  1 |  a   b    c         d
        //  1,  0 |  c   d    a         b
        //  1,  1 |  c   b    a         d
        let c3 = is_less(&*c, &*a);
        let c4 = is_less(&*d, &*b);
        let min = hint::select_unpredictable(c3, c, a);
        let max = hint::select_unpredictable(c4, b, d);
        let unknown_left = hint::select_unpredictable(c3, a, hint::select_unpredictable(c4, c, b));
        let unknown_right = hint::select_unpredictable(c4, d, hint::select_unpredictable(c3, b, c));

        // Sort the last two unknown elements.
        let c5 = is_less(&*unknown_right, &*unknown_left);
        let lo = hint::select_unpredictable(c5, unknown_right, unknown_left);
        let hi = hint::select_unpredictable(c5, unknown_left, unknown_right);

        ptr::copy_nonoverlapping(min, dst, 1);
        ptr::copy_nonoverlapping(lo, dst.add(1), 1);
        ptr::copy_nonoverlapping(hi, dst.add(2), 1);
        ptr::copy_nonoverlapping(max, dst.add(3), 1);
    }
}