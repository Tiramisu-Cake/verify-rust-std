pub unsafe fn pointer_value_cannot_own_pointee<T>(p: *const T) -> *const T
{
    p
}
