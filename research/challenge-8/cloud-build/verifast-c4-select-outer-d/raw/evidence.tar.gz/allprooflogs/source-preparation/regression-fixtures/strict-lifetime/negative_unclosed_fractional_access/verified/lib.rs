#![no_std]
#![allow(dead_code)]

// Source template for physical, one-case VeriFast fixtures. The runner strips
// the CASE delimiters and sends each selected source separately to the readonly
// compiler-MIR exporter, decoder, and verifier. This combined template is never
// a verifier input.

/*@
pred_ctor payload()(;) = true;
@*/
pub unsafe fn negative_unclosed_fractional_access()
/*@ req true; @*/ /*@ ens true; @*/ {
    //@ let cmp_k = begin_lifetime();
    {
        /*@ let_lft 'cmp = cmp_k; @*/
        //@ close payload()();
        //@ borrow(cmp_k, payload());
        //@ full_borrow_into_frac(cmp_k, payload());
        //@ open_frac_borrow(cmp_k, payload(), 1/2);
        //@ end_lft_binding::<'cmp>();
        //@ assert lifetime_token(cmp_k);
    }
}
