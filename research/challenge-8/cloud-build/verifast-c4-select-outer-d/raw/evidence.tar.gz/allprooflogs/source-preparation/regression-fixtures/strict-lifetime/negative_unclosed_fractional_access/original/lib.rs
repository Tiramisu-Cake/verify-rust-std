#![no_std]
#![allow(dead_code)]

// Source template for physical, one-case VeriFast fixtures. The runner strips
// the CASE delimiters and sends each selected source separately to the readonly
// compiler-MIR exporter, decoder, and verifier. This combined template is never
// a verifier input.

pub unsafe fn negative_unclosed_fractional_access()
  {
    {
    }
}
