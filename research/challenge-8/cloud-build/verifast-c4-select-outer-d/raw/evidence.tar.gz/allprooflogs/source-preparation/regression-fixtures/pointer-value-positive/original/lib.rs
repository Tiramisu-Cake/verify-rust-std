pub unsafe fn pointer_value_identity<T>(p: *const T) -> *const T
{
    p
}
