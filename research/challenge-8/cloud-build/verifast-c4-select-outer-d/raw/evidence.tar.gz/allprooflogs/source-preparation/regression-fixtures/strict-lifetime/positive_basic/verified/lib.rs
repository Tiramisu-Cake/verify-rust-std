#![no_std]
#![allow(dead_code)]

// Source template for physical, one-case VeriFast fixtures. The runner strips
// the CASE delimiters and sends each selected source separately to the readonly
// compiler-MIR exporter, decoder, and verifier. This combined template is never
// a verifier input.

pub unsafe fn positive_basic() /*@ req true; @*/ /*@ ens true; @*/ {
    //@ let cmp_k = begin_lifetime();
    {
        /*@ let_lft 'cmp = cmp_k; @*/
        //@ end_lft_binding::<'cmp>();
        //@ assert lifetime_token(cmp_k);
        //@ end_lifetime(cmp_k);
    }
}
