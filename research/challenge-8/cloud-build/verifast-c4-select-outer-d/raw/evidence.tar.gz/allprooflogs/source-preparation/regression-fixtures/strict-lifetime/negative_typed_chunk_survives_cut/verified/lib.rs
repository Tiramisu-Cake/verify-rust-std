#![no_std]
#![allow(dead_code)]

// Source template for physical, one-case VeriFast fixtures. The runner strips
// the CASE delimiters and sends each selected source separately to the readonly
// compiler-MIR exporter, decoder, and verifier. This combined template is never
// a verifier input.

/*@
pred live<'a, T>() = true;
@*/
pub unsafe fn negative_typed_chunk_survives_cut<T>()
/*@ req true; @*/ /*@ ens true; @*/ {
    //@ let cmp_k = begin_lifetime();
    {
        /*@ let_lft 'cmp = cmp_k; @*/
        //@ close live::<'cmp, T>();
        //@ end_lft_binding::<'cmp>();
    }
}
