// A slice of MaybeUninit<u8> does not grant permission to read an initialized u8.
// The expected failure is at the dereference, after `as_mut_ptr` has succeeded.
fn read_uninitialized(s: &mut [std::mem::MaybeUninit<u8>]) {
    if s.len() > 0 {
        let mu = s.as_mut_ptr();
        //@ open array(mu, ?n, ?values);
        let p = mu as *mut u8;
        let _b = unsafe { *p }; // Requires initialized-u8 ownership.
    }
}
